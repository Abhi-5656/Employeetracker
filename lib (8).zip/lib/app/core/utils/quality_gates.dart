// lib/app/core/utils/quality_gates.dart
import 'dart:math';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;
import 'brightness_estimator.dart';
import 'threshold_policy.dart';

class QualityResult {
  final bool pass;
  final List<String> reasons;
  final Lighting lighting;
  final double meanLuma;
  final double sobelEnergy;
  final double yaw, roll, pitchApprox;
  final double? normalizedVerticalOffset; // <-- ADD THIS LINE

  QualityResult({
    required this.pass,
    required this.reasons,
    required this.lighting,
    required this.meanLuma,
    required this.sobelEnergy,
    required this.yaw,
    required this.roll,
    required this.pitchApprox,
    this.normalizedVerticalOffset, // <-- ADD THIS LINE
  });
}

class QualityGates {
  /// Returns QualityResult. Uses:
  /// - ROI center gate (central 60% box)
  /// - |yaw|,|pitch|,|roll| <= 15°
  /// - blur (Sobel) >= policy.blurMin
  static QualityResult evaluate({
    required Face face,
    required img.Image fullImage,
    required img.Image faceCrop,
    double roiFrac = 0.60,
  }) {
    final bb = face.boundingBox;

    // --- START CHANGED BLOCK (Landmark-based centering) ---
    final le = face.landmarks[FaceLandmarkType.leftEye]?.position;
    final re = face.landmarks[FaceLandmarkType.rightEye]?.position;
    final nose = face.landmarks[FaceLandmarkType.noseBase]?.position;

    double landmarkCx = bb.left + bb.width / 2; // Fallback X to bbox center
    double landmarkCy = bb.top + bb.height / 2; // Fallback Y to bbox center

    if (le != null && re != null) {
      landmarkCx = (le.x + re.x) / 2; // Horizontal center is midpoint of eyes
      landmarkCy = (le.y + re.y) / 2; // Vertical center is eye line
    } else if (nose != null) {
      // If eyes are not detected, use nose and bias slightly upward
      landmarkCy = nose.y - (bb.height * 0.15); // Approximate eye-level from nose base
    }
    // --- END CHANGED BLOCK ---

    final roiW = fullImage.width * roiFrac;
    // --- START CHANGED BLOCK (Adjusted Vertical ROI calculation) ---
    // Make the target ROI slightly shorter vertically and shift it down
    // This allows for natural head position with headroom above eyes.
    final double adjustedRoiHeightFactor = 0.75; // e.g., target ROI height is 75% of horizontal width
    final double verticalShiftFactor = 0.05;    // e.g., shift the entire ROI window down by 5% of full image height

    final roiH = fullImage.height * roiFrac * adjustedRoiHeightFactor;
    final roiLeft = (fullImage.width - roiW) / 2;
    final roiTop  = (fullImage.height - roiH) / 2 + (fullImage.height * verticalShiftFactor);
    // --- END CHANGED BLOCK ---

    // --- START CHANGED BLOCK (Inclusion of Tolerance for ROI Check) ---
    // Instead of strict equality to roiLeft/Top, allow a small tolerance.
    // This makes the centering check more forgiving.
    final double horizontalTolerance = fullImage.width * 0.05; // 5% of image width
    final double verticalTolerance = fullImage.height * 0.08;  // 8% of image height

    final bool horizInRoi = (landmarkCx >= roiLeft - horizontalTolerance && landmarkCx <= (roiLeft + roiW) + horizontalTolerance);
    final bool vertInRoi = (landmarkCy >= roiTop - verticalTolerance && landmarkCy <= (roiTop + roiH) + verticalTolerance);

    final inRoi = horizInRoi && vertInRoi;
    // --- END CHANGED BLOCK ---

    final yaw  = face.headEulerAngleY ?? 0.0;     // left/right
    final roll = face.headEulerAngleZ ?? 0.0;     // tilt
    // Pitch is not provided; approximate using eye-to-nose geometry when possible.
    // If landmarks missing, leave 0.0 so the clamp below fails only if others fail.
    double pitch = 0.0;
    // --- START CHANGED BLOCK (use landmark variables for pitch) ---
    // The `le`, `re`, `nose` variables are already declared above and assigned.
    // No need to redeclare them here.
    if (le != null && re != null && nose != null) {
      // --- END CHANGED BLOCK ---
      final eyeY = (le.y + re.y) / 2.0;
      final eyeX = (le.x + re.x) / 2.0;
      final eyeDist = max(1.0, (re.x - le.x).abs());
      // crude pitch proxy: nose vertical offset relative to eye line
      final pitchNorm = (nose.y - eyeY).abs() / eyeDist; // ~0.3–0.6
      // Map 0.25..0.75 roughly into 0..25°
      pitch = (max(0.0, (pitchNorm - 0.25)) * 50.0).clamp(0.0, 25.0);
    }

    // Blur & brightness on the crop
    final g = img.grayscale(img.copyResize(faceCrop, width: 64, height: 64));
    double sobel = 0;
    const sx = [[-1,0,1],[-2,0,2],[-1,0,1]];
    const sy = [[-1,-2,-1],[0,0,0],[1,2,1]];
    for (int y = 1; y < g.height - 1; y++) {
      for (int x = 1; x < g.width - 1; x++) {
        double gx = 0, gy = 0;
        for (int j = -1; j <= 1; j++) {
          for (int i = -1; i <= 1; i++) {
            final lum = img.getLuminance(g.getPixel(x + i, y + j)).toDouble();
            gx += sx[j + 1][i + 1] * lum;
            gy += sy[j + 1][i + 1] * lum;
          }
        }
        sobel += gx * gx + gy * gy;
      }
    }
    sobel /= ((g.width - 2) * (g.height - 2));

    final mean = BrightnessEstimator.meanLumaFromImage(faceCrop);
    final lighting = BrightnessEstimator.classify(mean);
    final policy = (lighting == Lighting.lowLight)
        ? ThresholdPolicy.lowLight
        : ThresholdPolicy.daylight;

    final List<String> reasons = [];
    // --- START CHANGED BLOCK (More specific centering reasons) ---
    if (!inRoi) {
      if (!horizInRoi) {
        reasons.add(landmarkCx < roiLeft ? 'Move face to the right' : 'Move face to the left');
      }
      if (!vertInRoi) {
        reasons.add(landmarkCy < roiTop ? 'Raise your face slightly' : 'Lower your face slightly');
      }
    }
    // --- END CHANGED BLOCK ---

    if (yaw.abs()   > 15.0) reasons.add('Yaw > 15°');
    if (roll.abs()  > 15.0) reasons.add('Roll > 15°');
    if (pitch.abs() > 15.0) reasons.add('Pitch > 15°');
    if (sobel < policy.blurMin) reasons.add('Too blurry');

    // --- START ADDED BLOCK (normalizedVerticalOffset calculation) ---
    // Calculate the normalized vertical offset of the face's center from the *true* image center.
    // This value can be used by the UI to draw up/down arrows.
    // Positive means face center is above image center, negative means below.
    final double normalizedVerticalOffset = (landmarkCy - (fullImage.height / 2)) / (fullImage.height / 2);
    // --- END ADDED BLOCK ---

    return QualityResult(
      pass: reasons.isEmpty,
      reasons: reasons,
      lighting: lighting,
      meanLuma: mean,
      sobelEnergy: sobel,
      yaw: yaw, roll: roll, pitchApprox: pitch,
      normalizedVerticalOffset: normalizedVerticalOffset, // <-- ADD THIS LINE
    );
  }
}


// // quality_gates.dart
// import 'dart:math';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:image/image.dart' as img;
// import 'brightness_estimator.dart';
// import 'threshold_policy.dart';
//
// class QualityResult {
//   final bool pass;
//   final List<String> reasons;
//   final Lighting lighting;
//   final double meanLuma;
//   final double sobelEnergy;
//   final double yaw, roll, pitchApprox;
//   QualityResult({
//     required this.pass,
//     required this.reasons,
//     required this.lighting,
//     required this.meanLuma,
//     required this.sobelEnergy,
//     required this.yaw,
//     required this.roll,
//     required this.pitchApprox,
//   });
// }
//
// class QualityGates {
//   /// Returns QualityResult. Uses:
//   /// - ROI center gate (central 60% box)
//   /// - |yaw|,|pitch|,|roll| <= 15°
//   /// - blur (Sobel) >= policy.blurMin
//   static QualityResult evaluate({
//     required Face face,
//     required img.Image fullImage,
//     required img.Image faceCrop,
//     double roiFrac = 0.60,
//   }) {
//     final bb = face.boundingBox;
//     final cx = bb.left + bb.width / 2;
//     final cy = bb.top + bb.height / 2;
//     final roiW = fullImage.width * roiFrac;
//     final roiH = fullImage.height * roiFrac;
//     final roiLeft = (fullImage.width - roiW) / 2;
//     final roiTop  = (fullImage.height - roiH) / 2;
//
//     final inRoi = (cx >= roiLeft && cx <= (roiLeft + roiW) &&
//         cy >= roiTop  && cy <= (roiTop  + roiH));
//
//     final yaw  = face.headEulerAngleY ?? 0.0;     // left/right
//     final roll = face.headEulerAngleZ ?? 0.0;     // tilt
//     // Pitch is not provided; approximate using eye-to-nose geometry when possible.
//     // If landmarks missing, leave 0.0 so the clamp below fails only if others fail.
//     double pitch = 0.0;
//     final le = face.landmarks[FaceLandmarkType.leftEye]?.position;
//     final re = face.landmarks[FaceLandmarkType.rightEye]?.position;
//     final nose = face.landmarks[FaceLandmarkType.noseBase]?.position;
//     if (le != null && re != null && nose != null) {
//       final eyeY = (le.y + re.y) / 2.0;
//       final eyeX = (le.x + re.x) / 2.0;
//       final eyeDist = max(1.0, (re.x - le.x).abs());
//       // crude pitch proxy: nose vertical offset relative to eye line
//       final pitchNorm = (nose.y - eyeY).abs() / eyeDist; // ~0.3–0.6
//       // Map 0.25..0.75 roughly into 0..25°
//       pitch = (max(0.0, (pitchNorm - 0.25)) * 50.0).clamp(0.0, 25.0);
//     }
//
//     // Blur & brightness on the crop
//     final g = img.grayscale(img.copyResize(faceCrop, width: 64, height: 64));
//     double sobel = 0;
//     const sx = [[-1,0,1],[-2,0,2],[-1,0,1]];
//     const sy = [[-1,-2,-1],[0,0,0],[1,2,1]];
//     for (int y = 1; y < g.height - 1; y++) {
//       for (int x = 1; x < g.width - 1; x++) {
//         double gx = 0, gy = 0;
//         for (int j = -1; j <= 1; j++) {
//           for (int i = -1; i <= 1; i++) {
//             final lum = img.getLuminance(g.getPixel(x + i, y + j)).toDouble();
//             gx += sx[j + 1][i + 1] * lum;
//             gy += sy[j + 1][i + 1] * lum;
//           }
//         }
//         sobel += gx * gx + gy * gy;
//       }
//     }
//     sobel /= ((g.width - 2) * (g.height - 2));
//
//     final mean = BrightnessEstimator.meanLumaFromImage(faceCrop);
//     final lighting = BrightnessEstimator.classify(mean);
//     final policy = (lighting == Lighting.lowLight)
//         ? ThresholdPolicy.lowLight
//         : ThresholdPolicy.daylight;
//
//     final List<String> reasons = [];
//     if (!inRoi) reasons.add('Face not centered');
//     if (yaw.abs()   > 15.0) reasons.add('Yaw > 15°');
//     if (roll.abs()  > 15.0) reasons.add('Roll > 15°');
//     if (pitch.abs() > 15.0) reasons.add('Pitch > 15°');
//     if (sobel < policy.blurMin) reasons.add('Too blurry');
//
//     return QualityResult(
//       pass: reasons.isEmpty,
//       reasons: reasons,
//       lighting: lighting,
//       meanLuma: mean,
//       sobelEnergy: sobel,
//       yaw: yaw, roll: roll, pitchApprox: pitch,
//     );
//   }
// }
