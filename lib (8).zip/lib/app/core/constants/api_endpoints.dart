class ApiEndpoints {
  // This class should not be instantiated.
  ApiEndpoints._();

  // =========== AUTHENTICATION ===========
  static const String login = 'api/auth/login';
  // --- NEW: Endpoint for refreshing the authentication token ---
  static const String refreshToken = 'api/auth/refresh';


  // =========== EMPLOYEES ===========
  // Endpoint to get a list of valid employee IDs
  static const String employeeIds = 'api/employees/ids';

  // --- COMMENT UPDATED ---
  // Endpoint to fetch all registered employee profiles from the server
  static const String employeeProfileRegistration = 'api/employee-profile-registrations';

  // Endpoint to send employee registration data to the server
  static const String bulkProfileRegistration = 'api/employee-profile-registrations/bulk';


  // =========== TIMESHEETS ===========
  // Endpoint to send punch events (timesheets) to the server
  static const String bulkTimesheet = 'api/wfm/timesheets/bulk';
}