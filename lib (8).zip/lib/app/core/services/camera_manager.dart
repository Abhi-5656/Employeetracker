import 'package:camera/camera.dart';

class CameraManager {
  static CameraController? _controller;

  static Future<CameraController> getController() async {
    if (_controller != null && _controller!.value.isInitialized) {
      return _controller!;
    }
    final cameras = await availableCameras();
    final frontCamera = cameras.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
      orElse: () => cameras.first,
    );
    _controller = CameraController(
      frontCamera,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.nv21,
    );
    await _controller!.initialize();
    try {
      await _controller!.setFlashMode(FlashMode.auto);
    } catch (_) {}
    try {
      await _controller!.setFocusMode(FocusMode.auto);
    } catch (_) {}
    return _controller!;
  }

  static CameraController? get controller => _controller;

  static Future<void> dispose() async {
    if (_controller != null) {
      await _controller!.dispose();
      _controller = null;
    }
  }
}
