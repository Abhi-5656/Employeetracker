// lib/app/core/models/employee_profile_registration.dart

class EmployeeProfileRegistration {
  final String employeeId;
  final String employeeImageData; // JSON-encoded float embedding (NOT raw image)

  EmployeeProfileRegistration({
    required this.employeeId,
    required this.employeeImageData,
  });

  /// Converts the object to a Map suitable for JSON encoding,
  /// matching the server's expected format.
  Map<String, dynamic> toMap() {
    return {
      'employeeId': employeeId,
      'employeeImageData': employeeImageData,
    };
  }
}

//older
// lib/app/core/models/employee_profile_registration.dart
//
// class EmployeeProfileRegistration {
//   final String employeeId;
//   final String employeeImageData; // JSON-encoded float embedding (NOT raw image)
//
//   EmployeeProfileRegistration({
//     required this.employeeId,
//     required this.employeeImageData,
//   });
//
//   /// Converts the object to a Map suitable for JSON encoding,
//   /// matching the server's expected format.
//   Map<String, dynamic> toMap() {
//     return {
//       'employeeId': employeeId,
//       'employeeImageData': employeeImageData,
//     };
//   }
// }
