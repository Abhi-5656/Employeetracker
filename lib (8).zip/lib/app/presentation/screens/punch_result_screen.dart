import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

enum PunchResultKind { inPunch, outPunch }

Future<void> showPunchResult(
    BuildContext context, {
      required bool success,
      required PunchResultKind kind,
      String? employeeId,                      // shown on success
      required DateTime punchedAt,
      String failureMessage = 'Please try again',
      Duration autoDismiss = const Duration(seconds: 2),
    }) async {
  await showGeneralDialog(
    context: context,
    barrierDismissible: false,
    barrierLabel: 'punch_result',
    barrierColor: Colors.transparent,
    transitionDuration: const Duration(milliseconds: 200),
    pageBuilder: (_, __, ___) => _PunchResultPage(
      success: success,
      kind: kind,
      employeeId: employeeId,
      punchedAt: punchedAt,
      failureMessage: failureMessage,
      autoDismiss: autoDismiss,
    ),
    transitionBuilder: (_, anim, __, child) =>
        Transform.scale(scale: 0.98 + 0.02 * anim.value, child: Opacity(opacity: anim.value, child: child)),
  );
}

class _PunchResultPage extends StatefulWidget {
  const _PunchResultPage({
    required this.success,
    required this.kind,
    required this.punchedAt,
    required this.failureMessage,
    required this.autoDismiss,
    this.employeeId,
  });

  final bool success;
  final PunchResultKind kind;
  final DateTime punchedAt;
  final String failureMessage;
  final Duration autoDismiss;
  final String? employeeId;

  @override
  State<_PunchResultPage> createState() => _PunchResultPageState();
}

class _PunchResultPageState extends State<_PunchResultPage> {
  @override
  void initState() {
    super.initState();
    // Auto-close after delay
    Future.delayed(widget.autoDismiss, () {
      if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
    });
  }

  @override
  Widget build(BuildContext context) {
    final isSuccess = widget.success;

    final gradient = isSuccess
        ? const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFF1FD1A5), Color(0xFF1ABC9C)],
    )
        : const LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: [Color(0xFFE74C3C), Color(0xFFC0392B)],
    );

    final icon = isSuccess ? Icons.check : Icons.close;
    final title = isSuccess
        ? 'Punch ${widget.kind == PunchResultKind.inPunch ? "In" : "Out"} Successful!'
        : 'Authentication Failed';
    final lines = <String>[
      if (isSuccess && (widget.employeeId ?? '').isNotEmpty) 'Employee: ${widget.employeeId}',
      if (isSuccess) 'Time: ${DateFormat('h:mm a').format(widget.punchedAt)}',
      if (!isSuccess) widget.failureMessage,
    ];

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(gradient: gradient),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 124,
                height: 124,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Colors.black.withOpacity(.10), blurRadius: 16, offset: const Offset(0, 8)),
                  ],
                ),
                child: Icon(icon, size: 64, color: isSuccess ? const Color(0xFF16A085) : const Color(0xFFB3392A)),
              ),
              const SizedBox(height: 28),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Colors.white)),
              const SizedBox(height: 10),
              for (final l in lines)
                Padding(
                  padding: const EdgeInsets.only(top: 2.0),
                  child: Text(l,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.white)),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
