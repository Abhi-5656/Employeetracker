// import 'dart:async';
// import 'package:intl/intl.dart';
// import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';
//
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models/punch_event.dart';
// import '../../core/models/timesheet.dart';
// import 'home_screen.dart';
//
// // /// Put this class near the top of punch_camera_screen.dart (or in a utils file)
// class ConsensusGate {
//   final int N, K;
//   final Duration cooldown;
//
//   DateTime _lastCommit = DateTime.fromMillisecondsSinceEpoch(0);
//   final List<String?> _win = [];
//
//   ConsensusGate({
//     this.N = 7,
//     this.K = 5,
//     this.cooldown = const Duration(seconds: 4),
//   });
//
//   bool get inCooldown => DateTime.now().difference(_lastCommit) < cooldown;
//
//   String? push(String? candidate) {
//     if (candidate == null || inCooldown) return null;
//     _win.add(candidate);
//     if (_win.length > N) _win.removeAt(0);
//
//
//     final c = _win.where((x) => x == candidate).length;
//     if (c >= K) {
//       _lastCommit = DateTime.now();
//       _win.clear();
//       return candidate;
//     }
//     return null;
//   }
// }
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen>
// {
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//
//   // after:
//   final ConsensusGate _gate = ConsensusGate(N: 7, K: 5, cooldown: const Duration(seconds: 4));
//   bool _captureBusy = false; // NEW
//
//
//   final FaceRecognitionService _faceRecognitionService =
//   FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//
//   bool _isProcessing = false;
//   bool _isClosing = false; // prevents double-dispose
//
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     _cameraController?.dispose();
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _teardownCamera() async {
//     if (_isClosing) return;
//     _isClosing = true;
//     try {
//       final c = _cameraController;
//       if (c != null) {
//         // If you ever enable image stream, always stop it first
//         if (c.value.isInitialized && c.value.isStreamingImages) {
//           try { await c.stopImageStream(); } catch (_) {}
//         }
//         try { await c.dispose(); } catch (_) {}
//       }
//     } finally {
//       _cameraController = null;
//       _isClosing = false;
//     }
//   }
//
//   /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
//   Future<void> _showOverlayThenGoHome({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // 2) make sure camera surfaces are gone (prevents a black preview underneath)
//     await _teardownCamera();
//
//     // 3) show result overlay
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId, // printed on success
//     );
//
//     if (!mounted) return;
//
//     // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
//     Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (_) => const HomeScreen()),
//           (route) => false,
//     );
//   }
//
//
//   Future<void> _initializeCamera() async {
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.medium,
//         enableAudio: false,
//       );
//
//       await _cameraController!.initialize();
//
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error initializing camera: $e');
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//       }
//     }
//   }
//
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC ---
//   Future<void> _takePictureAndProcess() async {
//     // ---- hard guards FIRST (prevents overlapping calls) ----
//     if (_captureBusy ||
//         _isProcessing ||
//         _cameraController == null ||
//         !_cameraController!.value.isInitialized) {
//       return;
//     }
//     _captureBusy = true;                    // acquire
//     setState(() => _isProcessing = true);   // show overlay
//
//     final started = DateTime.now();
//     const totalBudget = Duration(seconds: 4);
//     const interFrame  = Duration(milliseconds: 200);
//
//     try {
//       String? committedId;
//
//       // keep capturing until consensus or time budget is exhausted
//       while (committedId == null &&
//           DateTime.now().difference(started) < totalBudget) {
//
//         // 1) still capture (PAUSE → takePicture → RESUME)
//         await _cameraController!.pausePreview();
//         XFile image;
//         try {
//           image = await _cameraController!.takePicture();
//         } finally {
//           try { await _cameraController!.resumePreview(); } catch (_) {}
//         }
//
//         // 2) recognize
//         String? candidate = await _faceRecognitionService.recognizeFace(image);
//
//         // 3) one-shot retry if we still have time
//         if (candidate == null) {
//           const retryDelay = Duration(milliseconds: 250);
//           if (DateTime.now().difference(started) + retryDelay < totalBudget) {
//             await Future.delayed(retryDelay);
//
//             // PAUSE → takePicture (retry) → RESUME
//             await _cameraController!.pausePreview();
//             XFile retry;
//             try {
//               retry = await _cameraController!.takePicture();
//             } finally {
//               try { await _cameraController!.resumePreview(); } catch (_) {}
//             }
//
//             candidate = await _faceRecognitionService.recognizeFace(retry);
//           }
//         }
//
//         // 4) vote into consensus window
//         committedId = _gate.push(candidate);
//
//         // brief spacing between frames (but don't exceed time budget)
//         if (committedId == null) {
//           final elapsed = DateTime.now().difference(started);
//           if (elapsed + interFrame >= totalBudget) break;
//           await Future.delayed(interFrame);
//         }
//       }
//
//       // No consensus within budget → soft fail and exit via overlay
//       if (committedId == null) {
//         _showErrorMessage('Authentication inconclusive—hold steady and try again.');
//         await _showOverlayThenExit(success: false, when: DateTime.now());
//         return;
//       }
//
//       // ===== existing punch logic (unchanged) =====
//       final employeeId = committedId;
//       final position = await _getCurrentLocation();
//
//       final punchEvent = PunchEvent(
//         employeeId: employeeId,
//         eventTime: DateTime.now(),
//         punchType: widget.punchType,
//         status: 'VALID',
//         deviceId: 'KIOSK01',
//         latitude: position?.latitude,
//         longitude: position?.longitude,
//       );
//
//       await _faceRecognitionService.logPunchDecision(
//         widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//         employeeId: employeeId,
//       );
//
//       final connectivityResult = await Connectivity().checkConnectivity();
//       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//           connectivityResult.contains(ConnectivityResult.wifi);
//
//       if (isOnline) {
//         final timesheet = Timesheet(
//           employeeId: punchEvent.employeeId,
//           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//           punchEvents: [
//             PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!),
//           ],
//         );
//
//         final success = await _apiService.sendBulkTimsheets([timesheet]);
//
//         if (success) {
//           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//           await _showOverlayThenExit(
//             success: true,
//             when: punchEvent.eventTime,
//             employeeId: employeeId,
//           );
//           return;
//         } else {
//           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//           await _showOverlayThenExit(
//             success: true,
//             when: punchEvent.eventTime,
//             employeeId: employeeId,
//           );
//           return;
//         }
//       } else {
//         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//         await _showOverlayThenExit(
//           success: true,
//           when: punchEvent.eventTime,
//           employeeId: employeeId,
//         );
//         return;
//       }
//       // ===== end unchanged logic =====
//     } catch (e) {
//       // keep your logging + graceful exit
//       // ignore: avoid_print
//       print('Error during face recognition or punch processing: $e');
//       _showErrorMessage('An error occurred. Please try again.');
//       await _showOverlayThenExit(success: false, when: DateTime.now());
//     } finally {
//       // ---- ALWAYS release busy flag, even on early returns/errors ----
//       _captureBusy = false;
//     }
//   }
//
//
//
//
//   // void _takePictureAndProcess() async {
//   //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//   //   setState(() => _isProcessing = true);
//   //
//   //
//   //   try {
//   //     final image = await _cameraController!.takePicture();
//   //
//   //     var employeeId = await _faceRecognitionService.recognizeFace(image);
//   //     if (employeeId == null) {
//   //       await Future.delayed(const Duration(milliseconds: 250));
//   //       final retry = await _cameraController!.takePicture();
//   //       employeeId = await _faceRecognitionService.recognizeFace(retry);
//   //     }
//   //
//   //     if (employeeId != null) {
//   //       final position = await _getCurrentLocation();
//   //
//   //       final punchEvent = PunchEvent(
//   //         employeeId: employeeId,
//   //         eventTime: DateTime.now(),
//   //         punchType: widget.punchType,
//   //         status: 'VALID',
//   //         deviceId: 'KIOSK01', // Example device ID
//   //         latitude: position?.latitude,
//   //         longitude: position?.longitude,
//   //       );
//   //
//   //       await _faceRecognitionService.logPunchDecision(
//   //         widget.punchType.toString(),
//   //         employeeId: employeeId,
//   //       );
//   //
//   //
//   //       final connectivityResult = await Connectivity().checkConnectivity();
//   //       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//   //           connectivityResult.contains(ConnectivityResult.wifi);
//   //
//   //       if (isOnline) {
//   //         // Try direct sync
//   //         // ignore: avoid_print
//   //         print('Device is online. Attempting to send punch event directly.');
//   //
//   //         final timesheet = Timesheet(
//   //           employeeId: punchEvent.employeeId,
//   //           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//   //           punchEvents: [
//   //             PunchEventPayload.fromPunchEvent(
//   //               punchEvent,
//   //               punchEvent.deviceId!,
//   //             ),
//   //           ],
//   //         );
//   //
//   //         await _faceRecognitionService.logPunchDecision(
//   //           widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//   //           employeeId: employeeId,
//   //         );
//   //
//   //         final success = await _apiService.sendBulkTimsheets([timesheet]);
//   //
//   //         if (success) {
//   //           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         } else {
//   //           // Fallback to queue
//   //           // ignore: avoid_print
//   //           print("Direct sync failed. Queuing punch event for later.");
//   //           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         }
//   //       } else {
//   //         // Offline: queue it
//   //         // ignore: avoid_print
//   //         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//   //         await _showOverlayThenExit(
//   //           success: true,
//   //           when: punchEvent.eventTime,
//   //           employeeId: employeeId,
//   //         );
//   //         return;
//   //
//   //       }
//   //     } else {
//   //       _showErrorMessage('Authentication Failed. Please try again.');
//   //       await _showOverlayThenExit(
//   //         success: false,
//   //         when: DateTime.now(),
//   //       );
//   //       return;
//   //     }
//   //   } catch (e) {
//   //     // ignore: avoid_print
//   //     print('Error during face recognition or punch processing: $e');
//   //     _showErrorMessage('An error occurred. Please try again.');
//   //     await _showOverlayThenExit(
//   //       success: false,
//   //       when: DateTime.now(),
//   //     );
//   //     return;
//   //   }
//   //   // finally {
//   //   //   if (mounted) {
//   //   //     Navigator.of(context).pop();
//   //   //   }
//   //   // }
//   // }
//
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       final serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         // ignore: avoid_print
//         print('Location services are disabled.');
//         return null;
//       }
//
//       var permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           // ignore: avoid_print
//           print('Location permission denied.');
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         // ignore: avoid_print
//         print('Location permissions are permanently denied.');
//         return null;
//       }
//
//       return Geolocator.getCurrentPosition();
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error getting location: $e');
//       return null;
//     }
//   }
//
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message),
//       ),
//     );
//   }
//
//
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message),
//       ),
//     );
//   }
//   Future<void> _showOverlayThenExit({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // Make sure your black processing veil is gone so the overlay is visible
//     // if (mounted) setState(() => _isProcessing = false);
//
//     // Map your existing punch type to the overlay enum
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId,
//     );
//
//     if (!mounted) return;
//     // 4) go back to Home (first route). If you use named routes, adjust to your home route.
//     Navigator.of(context).popUntil((route) => route.isFirst);// return to previous screen AFTER overlay closes
//   }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(child: CameraPreview(_cameraController!))
//           else
//             const Center(child: CircularProgressIndicator()),
//
//           // Capture button
//           Positioned(
//             bottom: 40,
//             child: FloatingActionButton(
//               onPressed: _isProcessing ? null : _takePictureAndProcess,
//               backgroundColor:
//               _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
//               child: const Icon(Icons.camera_alt),
//             ),
//           ),
//
//           // Processing overlay
//           if (_isProcessing)
//             Positioned.fill(
//               child: Container(
//                 color: Colors.black.withOpacity(0.5),
//                 child: const Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       CircularProgressIndicator(),
//                       SizedBox(height: 16),
//                       Text(
//                         'Recognizing face...',
//                         style: TextStyle(color: Colors.white, fontSize: 16),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }


//
// import 'dart:async';
// import 'package:flutter/foundation.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:intl/intl.dart';
// import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';
// import 'dart:typed_data';
//
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models/punch_event.dart';
// import '../../core/models/timesheet.dart';
// import 'home_screen.dart';
// import 'package:image/image.dart' as img;
// import 'package:kiosk/app/core/utils/threshold_policy.dart';
// import 'package:kiosk/app/core/services/liveness_service.dart';
// import 'package:kiosk/app/presentation/screens/widgets/fallback_pin_dialog.dart';
// import 'dart:math' as math;
// import 'package:google_mlkit_commons/google_mlkit_commons.dart';
//
//
//
// // /// Put this class near the top of punch_camera_screen.dart (or in a utils file)
// class ConsensusGate {
//   final int N, K;
//   final Duration cooldown;
//
//   DateTime _lastCommit = DateTime.fromMillisecondsSinceEpoch(0);
//   final List<String?> _win = [];
//
//   ConsensusGate({
//     this.N = 7,
//     this.K = 5,
//     this.cooldown = const Duration(seconds: 4),
//   });
//
//   bool get inCooldown => DateTime.now().difference(_lastCommit) < cooldown;
//
//   String? push(String? candidate) {
//     _win.add(candidate);
//     if (_win.length > N) _win.removeAt(0);
//
//     if (candidate == null || inCooldown) return null;
//
//     final c = _win.where((x) => x == candidate).length;
//     if (c >= K) {
//       _lastCommit = DateTime.now();
//       _win.clear();
//       return candidate;
//     }
//     return null;
//   }
// }
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen>
// {
//   Rect? _previewRect;
//   Rect? _ovalRect;
//   Rect _previewRectInScreen(Size screen, Size preview) {
//     final screenAR  = screen.height / screen.width;
//     final previewAR = preview.height / preview.width; // camera gives landscape
//     if (screenAR > previewAR) {
//       final h = screen.height;
//       final w = h / previewAR;
//       final left = (screen.width - w) / 2;
//       return Rect.fromLTWH(left, 0, w, h);
//     } else {
//       final w = screen.width;
//       final h = w * previewAR;
//       final top = (screen.height - h) / 2;
//       return Rect.fromLTWH(0, top, w, h);
//     }
//   }
//
//   bool _pointInEllipse(Offset p, Rect ellipse) {
//     final dx = (p.dx - ellipse.center.dx) / (ellipse.width  / 2);
//     final dy = (p.dy - ellipse.center.dy) / (ellipse.height / 2);
//     return dx*dx + dy*dy <= 1.0;
//   }
//
//   void _recalcRects(BuildContext context) {
//     if (_cameraController == null || !_cameraController!.value.isInitialized) return;
//     final screen = MediaQuery.of(context).size;
//
//     // previewSize is landscape; swap for portrait UI
//     final pv = _cameraController!.value.previewSize!;
//     final preview = Size(pv.height.toDouble(), pv.width.toDouble());
//
//     _previewRect = _previewRectInScreen(screen, preview);
//
//     _ovalRect = Rect.fromCenter(
//       center: _previewRect!.center.translate(0, -_previewRect!.height * 0.06),
//       width:  _previewRect!.width  * 0.72,
//       height: _previewRect!.height * 0.58,
//     );
//   }
//
//
//   Uint8List _yuv420ToNv21(CameraImage image) {
//     // Convert 3-plane YUV_420_888 to interleaved NV21 (Y + VU)
//     final y = image.planes[0].bytes;
//     final u = image.planes[1].bytes;
//     final v = image.planes[2].bytes;
//
//     final out = Uint8List(y.length + u.length + v.length);
//     out.setAll(0, y);
//     for (int i = 0, j = y.length; i < u.length; i++, j += 2) {
//       out[j] = v[i];       // V
//       out[j + 1] = u[i];   // U
//     }
//     return out;
//   }
//
//   Uint8List _bytesForMlkit(CameraImage image) {
//     // If single plane (BGRA on iOS, or some NV21), just use it
//     if (image.planes.length == 1) return image.planes[0].bytes;
//     // Typical Android YUV_420_888 → convert to NV21
//     return _yuv420ToNv21(image);
//   }
//
//   double _estimateLuma(CameraImage image) {
//     // Single-plane path: NV21 (Android) or BGRA (iOS)
//     if (image.planes.length == 1) {
//       if (defaultTargetPlatform == TargetPlatform.iOS) {
//         // BGRA: sample G channel
//         final b = image.planes[0].bytes;
//         double sum = 0; int n = 0;
//         for (int i = 1; i < b.length; i += 16) { sum += b[i]; n++; } // G
//         return n == 0 ? 0 : sum / n;
//       } else {
//         // NV21: Y is the first W*H bytes; sample that region
//         final b = image.planes[0].bytes;
//         final yLen = image.width * image.height;
//         if (b.isEmpty || yLen <= 0 || yLen > b.length) return 0;
//         double sum = 0; int n = 0;
//         for (int i = 0; i < yLen; i += 8) { sum += b[i]; n++; }
//         return n == 0 ? 0 : sum / n;
//       }
//     }
//
//     // 3-plane YUV_420_888: sample Y plane directly
//     final y = image.planes[0].bytes;
//     double sum = 0; int n = 0;
//     for (int i = 0; i < y.length; i += 8) { sum += y[i]; n++; }
//     return n == 0 ? 0 : sum / n;
//   }
//
//
//   // --- Guidance stream / overlay state ---
//   final FaceDetector _guideDetector = FaceDetector(
//     options: FaceDetectorOptions(
//       performanceMode: FaceDetectorMode.fast,
//       enableLandmarks: false,
//       enableContours: false,
//       enableClassification: false,
//       minFaceSize: 0.15,
//     ),
//   );
// // ignore: unused_field
//   bool _isStreaming = false;
//   bool _isAnalyzing = false;
//
// // Live alignment state for overlay + capture gating
//   bool _isAligned = false;
//   int _alignedStreak = 0;
//   static const int _alignedNeeded = 3; // frames-in-a-row to turn GREEN
//
// // last guidance diagnostics (optional; helpful for threshold tuning)
//
//   double _lastYaw = 0, _lastRoll = 0, _lastBrightness = 999;
//
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//
//   // after:
//   final ConsensusGate _gate = ConsensusGate(N: 5, K: 3, cooldown: const Duration(seconds: 4));
//
//   final FaceRecognitionService _faceRecognitionService =
//   FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//
//   bool _isProcessing = false;
//   bool _isClosing = false; // prevents double-dispose
//
//
//   final LivenessService _liveness = LivenessService();
//   int _failedAttempts = 0;
//
//   // helper: decode to image (for liveness only)
//   Future<img.Image?> _decodeImage(XFile xf) async {
//     try { final b = await xf.readAsBytes(); return img.decodeImage(b); } catch (_) { return null; }
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     _guideDetector.close();  // ⬅ add this
//     _cameraController?.dispose();
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _teardownCamera() async {
//     if (_isClosing) return;
//     _isClosing = true;
//     try {
//       final c = _cameraController;
//       if (c != null) {
//         if (c.value.isInitialized && c.value.isStreamingImages) {
//           try { await c.stopImageStream(); } catch (_) {}
//           await Future.delayed(const Duration(milliseconds: 80)); // drain buffers
//         }
//         try { await c.dispose(); } catch (_) {}
//       }
//     } finally {
//       _cameraController = null;
//       _isClosing = false;
//     }
//     // if (_isClosing) return;
//     // _isClosing = true;
//     // try {
//     //   final c = _cameraController;
//     //   if (c != null) {
//     //     // If you ever enable image stream, always stop it first
//     //     if (c.value.isInitialized && c.value.isStreamingImages) {
//     //       try { await c.stopImageStream(); } catch (_) {}
//     //     }
//     //     try { await c.dispose(); } catch (_) {}
//     //   }
//     // } finally {
//     //   _cameraController = null;
//     //   _isClosing = false;
//     // }
//   }
//
//   Future<void> _startGuideStream() async {
//     if (_cameraController == null) return;
//     if (!_cameraController!.value.isInitialized) return;
//     if (_cameraController!.value.isStreamingImages) { _isStreaming = true; return; }
//
//     _isStreaming = true;
//     await _cameraController!.startImageStream((CameraImage image) async {
//       if (_isAnalyzing || _isProcessing) return; // throttle
//       _isAnalyzing = true;
//       try {
//         // ---------- Platform-aware format + metadata ----------
//         final bytes = _bytesForMlkit(image);
//         final bool singlePlane = image.planes.length == 1;
//
//         late final InputImageFormat fmt;
//         late final int bpr;
//
//         if (singlePlane) {
//           if (defaultTargetPlatform == TargetPlatform.iOS) {
//             fmt = InputImageFormat.bgra8888;
//             bpr = image.planes[0].bytesPerRow;
//           } else {
//             // Android single-plane -> NV21
//             fmt = InputImageFormat.nv21;
//             bpr = image.width; // NV21 stride == width
//           }
//         } else {
//           // 3-plane YUV_420_888 -> we convert to NV21 bytes
//           fmt = InputImageFormat.nv21;
//           bpr = image.width;
//         }
//
//         final rotation = InputImageRotationValue.fromRawValue(
//           _cameraController!.description.sensorOrientation,
//         ) ?? InputImageRotation.rotation0deg;
//
//         final metadata = InputImageMetadata(
//           size: Size(image.width.toDouble(), image.height.toDouble()),
//           rotation: rotation,
//           format: fmt,
//           bytesPerRow: bpr,
//         );
//
//         final inputImage = InputImage.fromBytes(bytes: bytes, metadata: metadata);
//
//         // ---------- Declare all vars up-front so they exist for logs ----------
//         bool aligned = false;
//         bool sizeOk = false, centerOk = false, angleOk = false, lightOk = false;
//         double yaw = 0, roll = 0, pitch = 0;
//
//         // brightness (works for NV21 & BGRA)
//         final meanY = _estimateLuma(image);
//         _lastBrightness = meanY;
//         lightOk = meanY >= 60;
//
//
//         // ---------- Detect faces ----------
//         final faces = await _guideDetector.processImage(inputImage);
//
//         if (faces.isNotEmpty) {
//           faces.sort((a, b) =>
//               (b.boundingBox.width * b.boundingBox.height)
//                   .compareTo(a.boundingBox.width * a.boundingBox.height));
//           final f = faces.first;
//
//           final imgW = metadata.size.width;
//           final imgH = metadata.size.height;
//
//           final cx = f.boundingBox.center.dx / imgW;
//           final cy = f.boundingBox.center.dy / imgH;
//           final w  = f.boundingBox.width / imgW;
//           final h  = f.boundingBox.height / imgH;
//
//           // bail out if rects not ready (first few frames)
//           if (_previewRect == null || _ovalRect == null) {
//             _isAnalyzing = false;
//             return;
//           }
//
// // map normalized image coords → on-screen coords inside the preview
//           final cxScreen = _previewRect!.left + cx * _previewRect!.width;
//           final cyScreen = _previewRect!.top  + cy * _previewRect!.height;
//           final wScreen  = w * _previewRect!.width;
//           final hScreen  = h * _previewRect!.height;
//
// // center gate: inside the drawn ellipse
//           final centerOk = _pointInEllipse(Offset(cxScreen, cyScreen), _ovalRect!);
//
// // size gate: fits well inside the ellipse (leave a small margin)
//           final sizeOk = wScreen <= _ovalRect!.width  * 0.95 &&
//               hScreen <= _ovalRect!.height * 0.95 &&
//               (wScreen >= _ovalRect!.width * 0.40 || hScreen >= _ovalRect!.height * 0.40);
//
//
//
//
//           const double minFill   = 0.26;
//           const double maxFill = 0.62; // tighter so still JPEG doesn't clip the face
//           const double centerTol = 0.20;
//
//           const double targetX = 0.50;
//           const double targetY = 0.44; // because painter uses center.y - 0.06*height
//
//           const double tolX = 0.22; // a hair wider than before
//           const double tolY = 0.18;
//
//           yaw   = (f.headEulerAngleY ?? 0).abs().toDouble();
//           roll  = (f.headEulerAngleZ ?? 0).abs().toDouble();
//           pitch = (f.headEulerAngleX ?? 0).abs().toDouble();
//
//           _lastYaw = yaw;
//           _lastRoll = roll;
//
//           // size gate (normalized in image space)
// //           final sizeOk = (math.max(w, h) >= minFill) && (math.max(w, h) <= maxFill);
// //
// // // center gate (shifted target to match the painted oval)
// //           final centerOk = ((cx - targetX).abs() <= tolX) && ((cy - targetY).abs() <= tolY);
//           angleOk  = (yaw <= 20) && (roll <= 15) && (pitch <= 12);
//
//
//           aligned = sizeOk && centerOk && angleOk && lightOk;
//         }
//
//         // ---------- Maintain streak & update UI ----------
//         if (aligned) {
//           _alignedStreak++;
//         } else {
//           _alignedStreak = 0;
//         }
//         final nowAligned = _alignedStreak >= _alignedNeeded;
//         if (nowAligned != _isAligned && mounted) {
//           setState(() => _isAligned = nowAligned);
//         }
//
//         // ---------- Helpful log ----------
//         if (kDebugMode) {
//           debugPrint(
//               '[guide] faces=${faces.length} '
//                   'luma=${_lastBrightness.toStringAsFixed(0)} '
//                   'sizeOk=$sizeOk centerOk=$centerOk '
//                   'yaw=${yaw.toStringAsFixed(1)} roll=${roll.toStringAsFixed(1)} pitch=${pitch.toStringAsFixed(1)} '
//                   'lightOk=$lightOk aligned=$aligned streak=$_alignedStreak'
//           );
//         }
//       } catch (_) {
//         // ignore transient errors
//       } finally {
//         _isAnalyzing = false;
//       }
//     });
//
//   }
//
//
//   Future<void> _stopGuideStream() async {
//     if (_cameraController == null) return;
//     if (_cameraController!.value.isStreamingImages) {
//       try { await _cameraController!.stopImageStream(); } catch (_) {}
//       await Future.delayed(const Duration(milliseconds: 80)); // drain buffers
//     }
//     _isStreaming = false;
//   }
//
//   /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
//   Future<void> _showOverlayThenGoHome({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // 2) make sure camera surfaces are gone (prevents a black preview underneath)
//     await _teardownCamera();
//
//     // 3) show result overlay
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId, // printed on success
//     );
//
//     if (!mounted) return;
//
//     // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
//     Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (_) => const HomeScreen()),
//           (route) => false,
//     );
//   }
//
//
//   Future<void> _initializeCamera() async {
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.high, // ✅ was ResolutionPreset.medium
//         enableAudio: false,
//         imageFormatGroup: ImageFormatGroup.nv21, // ✅ important for Android
//       );
//
//       await _cameraController!.initialize();
//       try {
//         await _cameraController!.setFlashMode(FlashMode.auto);   // helps in low light
//       } catch (_) {}
//       try {
//         await _cameraController!.setFocusMode(FocusMode.auto);   // keep AF active if supported
//       } catch (_) {}
//
//
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//       _recalcRects(context);           // <— add this line
//       // ⬇️ Start the face-alignment guidance stream
//       await _startGuideStream();  // ⬅ start the live guidance stream
//
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error initializing camera: $e');
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//       }
//     }
//   }
//
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC ---
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC WITH CONSENSUS ---
//   // UPDATED OFFLINE-FIRST PUNCH LOGIC WITH GATES + CONSENSUS + FALLBACK
//   Future<void> _takePictureAndProcess() async {
//     if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//
//     // ✅ Only start an attempt if the guide is green
//     if (!_isAligned) {
//       _showErrorMessage('Align your face until the oval turns green.');
//       return;
//     }
//
//     setState(() => _isProcessing = true);
// // Stop analysis stream during still capture to avoid "maxImages" / buffer pressure
//     if (_cameraController!.value.isStreamingImages) {
//       try { await _cameraController!.stopImageStream(); } catch (_) {}
//       _isStreaming = false;
//     }
//     try {
//       String? committedId;
//       _liveness.reset();
//
//       // Rolling window; updated after first frame based on lighting policy
//       Duration window = const Duration(milliseconds: 1500);
//       var policy = ThresholdPolicy.daylight;
//       const interFrame = Duration(milliseconds: 340); // ↑ was 260 — throttle to avoid buffer starvation
//       const maxFrames = 6;                            // cap frames per attempt window
//
//       final started = DateTime.now();
//       bool sawLiveness = false;                       // window-level liveness
//       int sameIdCount = 0;
//       String? lastId;
//       int frames = 0;
//
//       RecognitionResult? lastRes; // for user-friendly reason
//
//       while (frames < maxFrames && DateTime.now().difference(started) < window) {
//         frames++;
// // Only capture when aligned to improve frame consistency
//         if (!_isAligned) {
//           await Future.delayed(const Duration(milliseconds: 60));
//           frames--; // don't burn a frame slot while unaligned
//           continue;
//         }
//
//         // If a capture is still in-flight, wait a bit
//         while (_cameraController!.value.isTakingPicture) {
//           if (!mounted) return;
//           await Future.delayed(const Duration(milliseconds: 40));
//         }
//
//         // Take a picture with backoff for "maxImages" pressure
//         XFile frame;
//         try {
//           frame = await _cameraController!.takePicture();
//         } on CameraException catch (e) {
//           if (e.description?.contains('maxImages') == true) {
//             // Camera pipeline is crowded; breathe and retry this frame slot
//             await Future.delayed(const Duration(milliseconds: 220));
//             frames--; // don't count this failed attempt
//             continue;
//           }
//           rethrow;
//         }
//
//         // Give pipeline a moment (JPEG encode/write) before the next request
//         await Future.delayed(const Duration(milliseconds: 100));
//
//         // Detailed 1:N with reasons (keeps your friendly messages)
//         final res = await _faceRecognitionService.recognizeFaceDetailed(frame);
//         lastRes = res;
//
//         // Update lighting policy & window from last metrics
//         final mean = _faceRecognitionService.lastMeanLuma ?? 100.0;
//         final light = (mean < 85) ? Lighting.lowLight : Lighting.daylight;
//         policy = (light == Lighting.lowLight) ? ThresholdPolicy.lowLight : ThresholdPolicy.daylight;
//         window = policy.window;
//
//         // Liveness: only needs to pass once in the whole window
//         final decoded = await _decodeImage(frame);
//         if (decoded != null && _liveness.pass(decoded, light)) {
//           sawLiveness = true;
//         }
//
//         // Vote on ID (recognition result); liveness is window-level gate
//         // --- Voting logic: strong = accepted; weak = near-threshold/margin-only ---
//         String? vote;
//         bool voteIsStrong = false;
//         bool weak = false;
//
// // Local threshold for logging/fallback (if res didn't include one)
//         final double thrLocal = res.threshold ?? policy.baseDistance;
//
// // 1) Strong vote when fully accepted
//         if (res.success && res.employeeId != null) {
//           vote = res.employeeId;
//           voteIsStrong = true;
//         }
// // 2) Weak vote: top-1 is close to threshold OR only failed the margin
//         else if (res.d1 != null) {
//           final d1 = res.d1!;
//           final nearThr = d1 <= (thrLocal + 0.06);
//           final marginOnly = (res.reason == RejectReason.lowMargin) && d1 <= thrLocal;
//           if (res is RecognitionResult && (nearThr || marginOnly)) {
//             // use best candidate carried in RecognitionResult (same as employeeId on success)
//             vote = _faceRecognitionService.lastBestId ?? res.employeeId;  // ✅ public getter
// // safe fallback
//             weak = true;
//           }
//         }
//
//         if (vote != null) {
//           if (lastId == vote) {
//             sameIdCount++;
//           } else {
//             sameIdCount = 1;
//             lastId = vote;
//           }
//
//           final needed = policy.requiredConsensus + (voteIsStrong ? 0 : 1);
//           if (sameIdCount >= needed && sawLiveness) {
//             committedId = vote;
//             break;
//           }
//
//           if (kDebugMode) {
//             debugPrint('[vote] id=$vote '
//                 'score=${res.d1?.toStringAsFixed(3)} thr=${thrLocal.toStringAsFixed(3)} '
//                 'strong=$voteIsStrong weak=$weak '
//                 'same=$sameIdCount needed=${policy.requiredConsensus + (voteIsStrong ? 0 : 1)} '
//                 'live=$sawLiveness');
//           }
//         }
//
//
//         // pacing until window end
//         final elapsed = DateTime.now().difference(started);
//         if (elapsed + interFrame >= window) break;
//         await Future.delayed(interFrame);
//       }
//
//       if (kDebugMode && committedId == null) {
//         debugPrint('[window end] frames=$frames live=$sawLiveness lastReason=${lastRes?.reason}');
//       }
//
//       // No consensus → strike handling
//       if (committedId == null) {
//         _failedAttempts++;
//
//         // After 3 rejections → 1:1 fallback (stay on camera if it fails)
//         if (_failedAttempts >= 3) {
//           final entered = await showFallbackPinDialog(context);
//           if (entered != null && entered.isNotEmpty) {
//             try {
//               while (_cameraController!.value.isTakingPicture) {
//                 if (!mounted) return;
//                 await Future.delayed(const Duration(milliseconds: 40));
//               }
//               final verifyFrame = await _cameraController!.takePicture();
//               final pass = await _faceRecognitionService.verify1to1(entered, verifyFrame, policy: policy);
//               if (pass) {
//                 await _submitPunch(entered);
//                 return;
//               }
//             } on CameraException catch (e) {
//               if (e.description?.contains('maxImages') == true) {
//                 await Future.delayed(const Duration(milliseconds: 220));
//               } else {
//                 rethrow;
//               }
//             }
//             _showErrorMessage('Verification failed. Please try again.');
//           }
//           _failedAttempts = 0; // reset after fallback path
//           setState(() => _isProcessing = false); // stay on camera
//           if (!_cameraController!.value.isStreamingImages) {
//             await _startGuideStream();
//           }
//
//           return;
//         }
//
//         // Friendly reason and stay on camera (no navigation)
//         final msg = _messageForReject(lastRes?.reason);
//         _showErrorMessage(msg);
//         setState(() => _isProcessing = false);
//         if (!_cameraController!.value.isStreamingImages) {
//           await _startGuideStream();
//         }
//
//         return;
//       }
//
//       // Success → submit & navigate via your existing overlay flow
//       await _submitPunch(committedId);
//       _failedAttempts = 0;
//     } catch (e) {
//       // Keep user on camera; don't navigate away on error
//       // ignore: avoid_print
//       print('Error during face recognition or punch processing: $e');
//       _showErrorMessage('An error occurred. Please try again.');
//       setState(() => _isProcessing = false);
//     }
//   }
//
//   // Future<void> _takePictureAndProcess() async {
//   //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//   //   setState(() => _isProcessing = true);
//   //
//   //   try {
//   //     String? committedId;
//   //     _liveness.reset();
//   //
//   //     // Rolling window based on lighting policy (set after first frame)
//   //     Duration window = const Duration(milliseconds: 1500);
//   //     final interFrame = const Duration(milliseconds: 260);//changed from 180 to 260
//   //     final started = DateTime.now();
//   //
//   //     ThresholdPolicy policy = ThresholdPolicy.daylight; // default; updated after first sample
//   //     int sameIdCount = 0;
//   //     String? lastId;
//   //
//   //     RecognitionResult? lastRes; // to show friendly reason on failure
//   //
//   //     while (DateTime.now().difference(started) < window) {
//   //       // ✅ Throttle: wait if a picture is still in flight
//   //       while (_cameraController!.value.isTakingPicture) {
//   //         if (!mounted) return;
//   //         await Future.delayed(const Duration(milliseconds: 40));
//   //       }
//   //
//   //       final frame = await _cameraController!.takePicture();
//   //       await Future.delayed(const Duration(milliseconds: 120)); // give pipeline time to breathe
//   //
//   //       // Use detailed recognition to get reasons
//   //       final res = await _faceRecognitionService.recognizeFaceDetailed(frame);
//   //       lastRes = res;
//   //
//   //       // Lighting & policy update from last metrics
//   //       final mean = _faceRecognitionService.lastMeanLuma ?? 100.0;
//   //       final light = (mean < 85) ? Lighting.lowLight : Lighting.daylight;
//   //       policy = (light == Lighting.lowLight) ? ThresholdPolicy.lowLight : ThresholdPolicy.daylight;
//   //       window = policy.window;
//   //
//   //       // Liveness check on current frame (cheap)
//   //       final decoded = await _decodeImage(frame);
//   //       final liveOk = decoded != null && _liveness.pass(decoded, light);
//   //
//   //       // Vote only if both recognition and liveness pass
//   //       final vote = (res.success && liveOk) ? res.employeeId : null;
//   //
//   //       if (vote != null) {
//   //         if (lastId == vote) {
//   //           sameIdCount++;
//   //         } else {
//   //           sameIdCount = 1;
//   //           lastId = vote;
//   //         }
//   //
//   //         // NEW: weak matches need one extra frame
//   //         final needed = policy.requiredConsensus +
//   //             (_faceRecognitionService.lastDecisionIsStrong ? 0 : 1);
//   //
//   //         if (sameIdCount >= needed) {
//   //           committedId = vote;
//   //           break;
//   //         }
//   //       }
//   //
//   //       // pacing until window end
//   //       final elapsed = DateTime.now().difference(started);
//   //       if (elapsed + interFrame >= window) break;
//   //       await Future.delayed(interFrame);
//   //     }
//   //
//   //     if (committedId == null) {
//   //       _failedAttempts++;
//   //
//   //       // After 3 rejections → 1:1 fallback; stay on camera if it fails
//   //       if (_failedAttempts >= 3) {
//   //         final entered = await showFallbackPinDialog(context);
//   //         if (entered != null && entered.isNotEmpty) {
//   //           // throttle before capture again
//   //           while (_cameraController!.value.isTakingPicture) {
//   //             if (!mounted) return;
//   //             await Future.delayed(const Duration(milliseconds: 40));
//   //           }
//   //           final verifyFrame = await _cameraController!.takePicture();
//   //           await Future.delayed(const Duration(milliseconds: 120));
//   //
//   //           final pass = await _faceRecognitionService.verify1to1(entered, verifyFrame, policy: policy);
//   //           if (pass) {
//   //             await _submitPunch(entered); // success path tears down + overlays + navigates
//   //             return;
//   //           }
//   //           _showErrorMessage('Verification failed. Please try again.');
//   //         }
//   //         _failedAttempts = 0; // reset after fallback path
//   //         setState(() => _isProcessing = false); // stay on camera
//   //         return;
//   //       }
//   //
//   //       // ❌ Do NOT navigate away on failure; show friendly reason and stay
//   //       final msg = _messageForReject(lastRes?.reason);
//   //       _showErrorMessage(msg);
//   //       setState(() => _isProcessing = false);
//   //       return;
//   //     }
//   //
//   //     // ✅ Success → submit and navigate via overlay (teardown inside)
//   //     await _submitPunch(committedId);
//   //     _failedAttempts = 0;
//   //
//   //   } catch (e) {
//   //     // Keep user on camera; don't navigate away on error
//   //     // ignore: avoid_print
//   //     print('Error during face recognition or punch processing: $e');
//   //     _showErrorMessage('An error occurred. Please try again.');
//   //     setState(() => _isProcessing = false);
//   //   }
//   // }
//
//   String _messageForReject(RejectReason? r) {
//     // use live metrics as a fallback when reason is null
//     final mean = _faceRecognitionService.lastMeanLuma ?? 999;
//     final sharp = _faceRecognitionService.lastSharpness ?? 999;
//
//     switch (r) {
//       case RejectReason.lowLight:
//         return 'Too dim. Move into better light or face a brighter area.';
//       case RejectReason.poorQuality:
//         return 'Hold steady for a moment—avoid motion blur.';
//       case RejectReason.faceTooSmall:
//         return 'Move closer so your face fills more of the frame.';
//       case RejectReason.lowMargin:
//         return 'Face not distinct enough—look straight at the camera.';
//       case RejectReason.aboveThreshold:
//         return 'Face not recognized—try again facing forward.';
//       case RejectReason.noFace:
//         return 'No face detected—center your face in the frame.';
//       case RejectReason.galleryEmpty:
//       case RejectReason.noValidVectors:
//         return 'No enrolled templates available. Please re-register.';
//       default:
//       // fallback based on metrics
//         if (mean < 75) return 'Too dim. Move into better light.';
//         if (sharp < 500) return 'Hold steady to reduce blur.';
//         return 'Hold steady, look at the camera, and try again.';
//     }
//   }
//
//   Future<void> _submitPunch(String employeeId) async {
//     final position = await _getCurrentLocation();
//     final punchEvent = PunchEvent(
//       employeeId: employeeId,
//       eventTime: DateTime.now(),
//       punchType: widget.punchType,
//       status: 'VALID',
//       deviceId: 'KIOSK01',
//       latitude: position?.latitude,
//       longitude: position?.longitude,
//     );
//
//     await _faceRecognitionService.logPunchDecision(
//       widget.punchType == PunchType.IN ? 'IN' : 'OUT', // ✅ use your actual enum
//       employeeId: employeeId,
//     );
//
//     final connectivityResult = await Connectivity().checkConnectivity();
//     final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//         connectivityResult.contains(ConnectivityResult.wifi);
//
//     if (isOnline) {
//       final timesheet = Timesheet(
//         employeeId: punchEvent.employeeId,
//         workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//         punchEvents: [ PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!) ],
//       );
//
//       final success = await _apiService.sendBulkTimsheets([timesheet]);
//       if (success) {
//         _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//         await _showOverlayThenExit(success: true, when: punchEvent.eventTime, employeeId: employeeId);
//         return;
//       }
//       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//       _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//       await _showOverlayThenExit(success: true, when: punchEvent.eventTime, employeeId: employeeId);
//       return;
//     } else {
//       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//       _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//       await _showOverlayThenExit(success: true, when: punchEvent.eventTime, employeeId: employeeId);
//       return;
//     }
//   }
//   // Future<void> _takePictureAndProcess() async {
//   //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//   //   setState(() => _isProcessing = true);
//   //
//   //   final started = DateTime.now();
//   //   const totalBudget = Duration(seconds: 3);      // hard cap for recognition
//   //   const interFrame = Duration(milliseconds: 160); // spacing between frames
//   //
//   //   try {
//   //     String? committedId;
//   //
//   //     // Keep capturing until we either get consensus or run out of time
//   //     while (committedId == null && DateTime.now().difference(started) < totalBudget) {
//   //       // 1) capture a frame
//   //       final image = await _cameraController!.takePicture();
//   //
//   //       // 2) run recognition
//   //       String? candidate = await _faceRecognitionService.recognizeFace(image);
//   //
//   //       // 3) one-shot retry (preserved), only if we still have time left
//   //       if (candidate == null) {
//   //         const retryDelay = Duration(milliseconds: 250);
//   //         if (DateTime.now().difference(started) + retryDelay < totalBudget) {
//   //           await Future.delayed(retryDelay);
//   //           final retry = await _cameraController!.takePicture();
//   //           candidate = await _faceRecognitionService.recognizeFace(retry);
//   //         }
//   //       }
//   //
//   //       // 4) vote into the consensus window
//   //       committedId = _gate.push(candidate);
//   //
//   //       // brief spacing between frames so the user can steady their face,
//   //       // but don't exceed the total time budget
//   //       if (committedId == null) {
//   //         final elapsed = DateTime.now().difference(started);
//   //         if (elapsed + interFrame >= totalBudget) break;
//   //         await Future.delayed(interFrame);
//   //       }
//   //     }
//   //
//   //     // No consensus within the time budget → soft fail and exit via overlay
//   //     if (committedId == null) {
//   //       _showErrorMessage('Authentication inconclusive—hold steady and try again.');
//   //       await _showOverlayThenExit(
//   //         success: false,
//   //         when: DateTime.now(),
//   //       );
//   //       return;
//   //     }
//   //
//   //     // ===== From here down: your existing offline-first punch code (unchanged) =====
//   //     final employeeId = committedId;
//   //     final position = await _getCurrentLocation();
//   //
//   //     final punchEvent = PunchEvent(
//   //       employeeId: employeeId,
//   //       eventTime: DateTime.now(),
//   //       punchType: widget.punchType,
//   //       status: 'VALID',
//   //       deviceId: 'KIOSK01', // Example device ID
//   //       latitude: position?.latitude,
//   //       longitude: position?.longitude,
//   //     );
//   //
//   //     await _faceRecognitionService.logPunchDecision(
//   //       widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//   //       employeeId: employeeId,
//   //     );
//   //
//   //     final connectivityResult = await Connectivity().checkConnectivity();
//   //     final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//   //         connectivityResult.contains(ConnectivityResult.wifi);
//   //
//   //     if (isOnline) {
//   //       // Try direct sync
//   //       final timesheet = Timesheet(
//   //         employeeId: punchEvent.employeeId,
//   //         workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//   //         punchEvents: [
//   //           PunchEventPayload.fromPunchEvent(
//   //             punchEvent,
//   //             punchEvent.deviceId!,
//   //           ),
//   //         ],
//   //       );
//   //
//   //       final success = await _apiService.sendBulkTimsheets([timesheet]);
//   //
//   //       if (success) {
//   //         _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//   //         await _showOverlayThenExit(
//   //           success: true,
//   //           when: punchEvent.eventTime,
//   //           employeeId: employeeId,
//   //         );
//   //         return;
//   //       } else {
//   //         // Fallback to queue
//   //         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//   //         await _showOverlayThenExit(
//   //           success: true,
//   //           when: punchEvent.eventTime,
//   //           employeeId: employeeId,
//   //         );
//   //         return;
//   //       }
//   //     } else {
//   //       // Offline: queue it
//   //       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //       _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//   //       await _showOverlayThenExit(
//   //         success: true,
//   //         when: punchEvent.eventTime,
//   //         employeeId: employeeId,
//   //       );
//   //       return;
//   //     }
//   //     // ===== end unchanged logic =====
//   //   } catch (e) {
//   //     // ignore: avoid_print
//   //     print('Error during face recognition or punch processing: $e');
//   //     _showErrorMessage('An error occurred. Please try again.');
//   //     await _showOverlayThenExit(
//   //       success: false,
//   //       when: DateTime.now(),
//   //     );
//   //     return;
//   //   }
//   // }
//
//
//   // void _takePictureAndProcess() async {
//   //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//   //   setState(() => _isProcessing = true);
//   //
//   //
//   //   try {
//   //     final image = await _cameraController!.takePicture();
//   //
//   //     var employeeId = await _faceRecognitionService.recognizeFace(image);
//   //     if (employeeId == null) {
//   //       await Future.delayed(const Duration(milliseconds: 250));
//   //       final retry = await _cameraController!.takePicture();
//   //       employeeId = await _faceRecognitionService.recognizeFace(retry);
//   //     }
//   //
//   //     if (employeeId != null) {
//   //       final position = await _getCurrentLocation();
//   //
//   //       final punchEvent = PunchEvent(
//   //         employeeId: employeeId,
//   //         eventTime: DateTime.now(),
//   //         punchType: widget.punchType,
//   //         status: 'VALID',
//   //         deviceId: 'KIOSK01', // Example device ID
//   //         latitude: position?.latitude,
//   //         longitude: position?.longitude,
//   //       );
//   //
//   //       await _faceRecognitionService.logPunchDecision(
//   //         widget.punchType.toString(),
//   //         employeeId: employeeId,
//   //       );
//   //
//   //
//   //       final connectivityResult = await Connectivity().checkConnectivity();
//   //       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//   //           connectivityResult.contains(ConnectivityResult.wifi);
//   //
//   //       if (isOnline) {
//   //         // Try direct sync
//   //         // ignore: avoid_print
//   //         print('Device is online. Attempting to send punch event directly.');
//   //
//   //         final timesheet = Timesheet(
//   //           employeeId: punchEvent.employeeId,
//   //           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//   //           punchEvents: [
//   //             PunchEventPayload.fromPunchEvent(
//   //               punchEvent,
//   //               punchEvent.deviceId!,
//   //             ),
//   //           ],
//   //         );
//   //
//   //         await _faceRecognitionService.logPunchDecision(
//   //           widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//   //           employeeId: employeeId,
//   //         );
//   //
//   //         final success = await _apiService.sendBulkTimsheets([timesheet]);
//   //
//   //         if (success) {
//   //           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         } else {
//   //           // Fallback to queue
//   //           // ignore: avoid_print
//   //           print("Direct sync failed. Queuing punch event for later.");
//   //           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         }
//   //       } else {
//   //         // Offline: queue it
//   //         // ignore: avoid_print
//   //         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//   //         await _showOverlayThenExit(
//   //           success: true,
//   //           when: punchEvent.eventTime,
//   //           employeeId: employeeId,
//   //         );
//   //         return;
//   //
//   //       }
//   //     } else {
//   //       _showErrorMessage('Authentication Failed. Please try again.');
//   //       await _showOverlayThenExit(
//   //         success: false,
//   //         when: DateTime.now(),
//   //       );
//   //       return;
//   //     }
//   //   } catch (e) {
//   //     // ignore: avoid_print
//   //     print('Error during face recognition or punch processing: $e');
//   //     _showErrorMessage('An error occurred. Please try again.');
//   //     await _showOverlayThenExit(
//   //       success: false,
//   //       when: DateTime.now(),
//   //     );
//   //     return;
//   //   }
//   //   // finally {
//   //   //   if (mounted) {
//   //   //     Navigator.of(context).pop();
//   //   //   }
//   //   // }
//   // }
//
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       final serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         // ignore: avoid_print
//         print('Location services are disabled.');
//         return null;
//       }
//
//       var permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           // ignore: avoid_print
//           print('Location permission denied.');
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         // ignore: avoid_print
//         print('Location permissions are permanently denied.');
//         return null;
//       }
//
//       return Geolocator.getCurrentPosition();
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error getting location: $e');
//       return null;
//     }
//   }
//
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message),
//       ),
//     );
//   }
//
//
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message),
//       ),
//     );
//   }
//   Future<void> _showOverlayThenExit({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
// // ✅ Stop camera before dialogs/navigation to prevent buffer errors.
//     await _teardownCamera();
//     // Make sure your black processing veil is gone so the overlay is visible
//     // if (mounted) setState(() => _isProcessing = false);
//
//     // Map your existing punch type to the overlay enum
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId,
//     );
//
//     if (!mounted) return;
//     // 4) go back to Home (first route). If you use named routes, adjust to your home route.
//     Navigator.of(context).popUntil((route) => route.isFirst);// return to previous screen AFTER overlay closes
//   }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(
//             child: Stack(
//             fit: StackFit.expand,
//                 children: [
//                 CameraPreview(_cameraController!),
//                   if (kDebugMode)
//                     Positioned(
//                       top: 48, left: 12,
//                       child: Container(
//                         padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                         color: Colors.black54,
//                         child: Text(
//                           'luma=${_lastBrightness.toStringAsFixed(0)}  '
//                               'yaw=${_lastYaw.toStringAsFixed(0)}  '
//                               'roll=${_lastRoll.toStringAsFixed(0)}',
//                           style: const TextStyle(color: Colors.white, fontSize: 12),
//                         ),
//                       ),
//                     ),
//
//
//                   // Alignment overlay (red/green)
//            IgnorePointer(
//            child: CustomPaint(
//              painter: _OvalGuidePainter(green: _isAligned, stroke: 6),
//            ),
//            ),
//           // Optional hint text
//           Positioned(
//             top: 28,
//             left: 0,
//             right: 0,
//             child: Text(
//               _isAligned ? 'Hold steady… capturing' : 'Align your face inside the frame',
//               textAlign: TextAlign.center,
//               style: const TextStyle(color: Colors.white70, fontSize: 14),
//             ),
//           ),
//         ],
//     ),
//         )
//           else
//             const Center(child: CircularProgressIndicator()),
//
//           // Capture button
//           Positioned(
//             bottom: 40,
//             child: FloatingActionButton(
//               onPressed: _isProcessing ? null : _takePictureAndProcess,
//               backgroundColor:
//               _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
//               child: const Icon(Icons.camera_alt),
//             ),
//           ),
//
//           // Processing overlay
//           if (_isProcessing)
//             Positioned.fill(
//               child: Container(
//                 color: Colors.black.withOpacity(0.5),
//                 child: const Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       CircularProgressIndicator(),
//                       SizedBox(height: 16),
//                       Text(
//                         'Recognizing face...',
//                         style: TextStyle(color: Colors.white, fontSize: 16),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
//
// }
// class _OvalGuidePainter extends CustomPainter {
//   final bool green;
//   final double stroke;
//   const _OvalGuidePainter({required this.green, this.stroke = 5});
//
//   @override
//   void paint(Canvas canvas, Size size) {
//     // same geometry as registration
//     final rect = Rect.fromCenter(
//       center: size.center(Offset(0, -size.height * 0.06)), // a touch higher
//       width: size.width * 0.72,
//       height: size.height * 0.58,
//     );
//
//     final p = Paint()
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = stroke
//       ..color = green ? Colors.greenAccent : Colors.redAccent;
//
//     // draw oval
//     canvas.drawOval(rect, p);
//
//     // dim outside, like registration
//     final path = Path()..addOval(rect);
//     final overlay = Path()..addRect(Offset.zero & size);
//     final outside = Path.combine(PathOperation.difference, overlay, path);
//     canvas.drawPath(outside, Paint()..color = const Color.fromRGBO(0, 0, 0, 0.28));
//   }
//
//   @override
//   bool shouldRepaint(covariant _OvalGuidePainter old) =>
//       old.green != green || old.stroke != stroke;
// }
//

import 'dart:async';
import 'dart:typed_data';
import 'package:kiosk/app/core/services/camera_manager.dart';

import 'package:camera/camera.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_mlkit_commons/google_mlkit_commons.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;
import 'package:intl/intl.dart';

import '../../core/services/face_recognition_service.dart';
import 'home_screen.dart';
import 'package:kiosk/app/core/services/api_service.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:kiosk/app/core/services/liveness_service.dart';
import 'package:kiosk/app/core/utils/threshold_policy.dart';
import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';
import 'package:kiosk/app/presentation/screens/widgets/fallback_pin_dialog.dart';

import '../../core/models/punch_event.dart';
import '../../core/models/timesheet.dart';

class PunchCameraScreen extends StatefulWidget {
  final PunchType punchType;

  const PunchCameraScreen({
    super.key,
    required this.punchType,
  });

  @override
  State<PunchCameraScreen> createState() => _PunchCameraScreenState();
}

class _PunchCameraScreenState extends State<PunchCameraScreen>
    with WidgetsBindingObserver {
  Rect? _previewRect;
  Rect? _ovalRect;


  void _resetAutoCaptureGates() {
    _autoCaptureTriggered = false;
    _isAligned = false;
    _alignedStreak = 0;
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final CameraController? cameraController = _cameraController;
    if (cameraController == null || !cameraController.value.isInitialized) {
      if (state == AppLifecycleState.resumed) {
        // even if controller is null, we’ll re-init below
        _resetAutoCaptureGates();
        _initializeCamera();
      }
      return;
    }
    if (state == AppLifecycleState.inactive) {
      _teardownCamera();
    } else if (state == AppLifecycleState.resumed) {
      _resetAutoCaptureGates();           // 👈 ensure gates allow auto-trigger

      _initializeCamera();
    }
  }

  Rect _previewRectInScreen(Size screen, Size preview) {
    final screenAR = screen.height / screen.width;
    final previewAR = preview.height / preview.width;

    if (screenAR > previewAR) {
      final h = screen.height;
      final w = h / previewAR;
      final left = (screen.width - w) / 2;
      return Rect.fromLTWH(left, 0, w, h);
    } else {
      final w = screen.width;
      final h = w * previewAR;
      final top = (screen.height - h) / 2;
      return Rect.fromLTWH(0, top, w, h);
    }
  }

  bool _pointInEllipse(Offset p, Rect ellipse) {
    final dx = (p.dx - ellipse.center.dx) / (ellipse.width / 2);
    final dy = (p.dy - ellipse.center.dy) / (ellipse.height / 2);
    return dx * dx + dy * dy <= 1.0;
  }

  void _recalcRects(BuildContext context) {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      return;
    }
    final screen = MediaQuery.of(context).size;
    final pv = _cameraController!.value.previewSize!;
    final preview = Size(pv.height.toDouble(), pv.width.toDouble());
    _previewRect = _previewRectInScreen(screen, preview);
    _ovalRect = Rect.fromCenter(
      center: _previewRect!.center
          .translate(0, -_previewRect!.height * 0.06), // slightly higher
      width: _previewRect!.width * 0.72,
      height: _previewRect!.height * 0.58,
    );
  }

  Uint8List _yuv420ToNv21(CameraImage image) {
    final y = image.planes[0].bytes;
    final u = image.planes[1].bytes;
    final v = image.planes[2].bytes;

    final out = Uint8List(y.length + u.length + v.length);
    out.setAll(0, y);

    for (int i = 0, j = y.length; i < u.length; i++, j += 2) {
      out[j] = v[i];
      out[j + 1] = u[i];
    }
    return out;
  }

  Uint8List _bytesForMlkit(CameraImage image) {
    if (image.planes.length == 1) return image.planes[0].bytes;
    return _yuv420ToNv21(image);
  }

  double _estimateLuma(CameraImage image) {
    if (image.planes.length == 1) {
      if (defaultTargetPlatform == TargetPlatform.iOS) {
        final b = image.planes[0].bytes;
        double sum = 0;
        int n = 0;
        for (int i = 1; i < b.length; i += 16) {
          sum += b[i];
          n++;
        }
        return n == 0 ? 0 : sum / n;
      } else {
        final b = image.planes[0].bytes;
        final yLen = image.width * image.height;
        if (b.isEmpty || yLen <= 0 || yLen > b.length) return 0;
        double sum = 0;
        int n = 0;
        for (int i = 0; i < yLen; i += 8) {
          sum += b[i];
          n++;
        }
        return n == 0 ? 0 : sum / n;
      }
    }

    final y = image.planes[0].bytes;
    double sum = 0;
    int n = 0;
    for (int i = 0; i < y.length; i += 8) {
      sum += y[i];
      n++;
    }
    return n == 0 ? 0 : sum / n;
  }

  final FaceDetector _guideDetector = FaceDetector(
    options: FaceDetectorOptions(
      performanceMode: FaceDetectorMode.fast,
      enableLandmarks: false,
      enableContours: false,
      enableClassification: false,
      minFaceSize: 0.15,
    ),
  );

  bool _isStreaming = false;
  bool _isAnalyzing = false;
  bool _isAligned = false;
  int _alignedStreak = 0;
  static const int _alignedNeeded = 3;

  double _lastYaw = 0, _lastRoll = 0, _lastBrightness = 999;

  CameraController? _cameraController;
  bool _isCameraInitialized = false;

  final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
  final ApiService _apiService = ApiService();
  final LivenessService _liveness = LivenessService();

  bool _isProcessing = false;
  bool _isClosing = false;
  int _failedAttempts = 0;

  // *** NEW: Auto-capture state ***
  bool _autoCaptureTriggered = false; // prevents multiple auto-triggers

  Future<img.Image?> _decodeImage(XFile xf) async {
    try {
      final b = await xf.readAsBytes();
      return img.decodeImage(b);
    } catch (_) {
      return null;
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _guideDetector.close();
    // _teardownCamera();
    CameraManager.dispose();  // Use CameraManager to dispose camera controller
    _faceRecognitionService.dispose();
    super.dispose();
  }

  Future<void> _teardownCamera() async {
    if (_isClosing) return;
    _isClosing = true;
    try {
      final c = _cameraController;
      if (c != null) {
        if (c.value.isInitialized && c.value.isStreamingImages) {
          try {
            await c.stopImageStream();
          } catch (_) {}
          await Future.delayed(const Duration(milliseconds: 80));
        }
        try {
          await c.dispose();
        } catch (_) {}
      }
    } finally {
      _cameraController = null;
      _isClosing = false;
    }
  }

  Future<void> _startGuideStream() async {
    if (_cameraController == null) return;
    if (!_cameraController!.value.isInitialized) return;

    if (_cameraController!.value.isStreamingImages) {
      _isStreaming = true;
      return;
    }

    _isStreaming = true;
    _resetAutoCaptureGates();               // 👈 make sure stream starts “armed”
    try {
      await _cameraController!.startImageStream((CameraImage image) async {
        if (_isAnalyzing || _isProcessing) return;
        _isAnalyzing = true;
        try {
          final bytes = _bytesForMlkit(image);
          final bool singlePlane = image.planes.length == 1;

          late final InputImageFormat fmt;
          late final int bpr;

          if (singlePlane) {
            if (defaultTargetPlatform == TargetPlatform.iOS) {
              fmt = InputImageFormat.bgra8888;
              bpr = image.planes[0].bytesPerRow;
            } else {
              fmt = InputImageFormat.nv21;
              bpr = image.width;
            }
          } else {
            fmt = InputImageFormat.nv21;
            bpr = image.width;
          }

          final rotation = InputImageRotationValue.fromRawValue(
            _cameraController!.description.sensorOrientation,
          ) ??
              InputImageRotation.rotation0deg;

          final metadata = InputImageMetadata(
            size: Size(
              image.width.toDouble(),
              image.height.toDouble(),
            ),
            rotation: rotation,
            format: fmt,
            bytesPerRow: bpr,
          );

          final inputImage = InputImage.fromBytes(
            bytes: bytes,
            metadata: metadata,
          );

          bool aligned = false;
          bool sizeOk = false, centerOk = false, angleOk = false, lightOk = false;

          double yaw = 0, roll = 0, pitch = 0;

          final meanY = _estimateLuma(image);
          _lastBrightness = meanY;
          lightOk = meanY >= 60;

          final faces = await _guideDetector.processImage(inputImage);
          if (faces.isNotEmpty) {
            faces.sort(
                  (a, b) => (b.boundingBox.width * b.boundingBox.height)
                  .compareTo(a.boundingBox.width * a.boundingBox.height),
            );

            final f = faces.first;
            final imgW = metadata.size.width;
            final imgH = metadata.size.height;

            final cx = f.boundingBox.center.dx / imgW;
            final cy = f.boundingBox.center.dy / imgH;
            final w = f.boundingBox.width / imgW;
            final h = f.boundingBox.height / imgH;

            if (_previewRect == null || _ovalRect == null) {
              _isAnalyzing = false;
              return;
            }

            final cxScreen = _previewRect!.left + cx * _previewRect!.width;
            final cyScreen = _previewRect!.top + cy * _previewRect!.height;
            final wScreen = w * _previewRect!.width;
            final hScreen = h * _previewRect!.height;

            centerOk = _pointInEllipse(Offset(cxScreen, cyScreen), _ovalRect!);

            sizeOk = wScreen <= _ovalRect!.width * 0.95 &&
                hScreen <= _ovalRect!.height * 0.95 &&
                (wScreen >= _ovalRect!.width * 0.40 ||
                    hScreen >= _ovalRect!.height * 0.40);

            yaw = (f.headEulerAngleY ?? 0).abs().toDouble();
            roll = (f.headEulerAngleZ ?? 0).abs().toDouble();
            pitch = (f.headEulerAngleX ?? 0).abs().toDouble();
            _lastYaw = yaw;
            _lastRoll = roll;

            angleOk = (yaw <= 20) && (roll <= 15) && (pitch <= 12);
            aligned = sizeOk && centerOk && angleOk && lightOk;
          }

          if (aligned) {
            _alignedStreak++;
          } else {
            _alignedStreak = 0;
          }

          final nowAligned = _alignedStreak >= _alignedNeeded;

          // *** Automatic capture trigger logic ***
          // if (nowAligned &&
          //     !_isAligned &&
          //     !_autoCaptureTriggered &&
          //     !_isProcessing &&
          //     mounted) {
          //   setState(() {
          //     _isAligned = nowAligned; // update UI
          //     _autoCaptureTriggered = true; // prevent re-trigger
          //   });
          //   _takePictureAndProcess(); // trigger capture
          // }
          // else if (!nowAligned && _isAligned && mounted) {
          //   setState(() {
          //     _isAligned = nowAligned;
          //     _autoCaptureTriggered = false; // reset if alignment is lost
          //   });
          // } else if (nowAligned && _isAligned) {
          //   // Already aligned & triggered — noop
          // }
          // --- Robust auto-capture gating ---
// Trigger whenever aligned and not already processing/triggered.
// This works even if we resumed with _isAligned already true.
          final alignmentStopwatch = Stopwatch();
          if (mounted) {
            if (nowAligned) {
              if (!_isAligned) {
                setState(() => _isAligned = true);
                alignmentStopwatch.stop();
                debugPrint('[Timing] Face aligned and auto-capture triggered at ${alignmentStopwatch.elapsedMilliseconds} ms');
              }

              final shouldTrigger = !_isProcessing && !_autoCaptureTriggered;
              if (shouldTrigger) {
                _autoCaptureTriggered = true; // arm once per aligned window
                Future.delayed(const Duration(milliseconds: 400), () {
                  if (!mounted) return;
                  if (_isAligned && _autoCaptureTriggered && !_isProcessing) {
                    _takePictureAndProcess();
                  }
                });
              }
            } else {
              if (_isAligned) setState(() => _isAligned = false);  // paint RED
              _autoCaptureTriggered = false;                       // disarm when misaligned
              alignmentStopwatch.start(); // reset/start when out of alignment
            }
          }


          if (kDebugMode) {
            debugPrint(
              '[guide] faces=${faces.length} '
                  'luma=${_lastBrightness.toStringAsFixed(0)} '
                  'sizeOk=$sizeOk centerOk=$centerOk '
                  'yaw=${yaw.toStringAsFixed(1)} roll=${roll.toStringAsFixed(1)} pitch=${pitch.toStringAsFixed(1)} '
                  'lightOk=$lightOk aligned=$aligned streak=$_alignedStreak',
            );
          }
        } catch (_) {
          // ignore transient errors
        } finally {
          _isAnalyzing = false;
        }
      });
    } on CameraException catch (e) {
      if (e.code == 'CameraAccessDenied') {
        _showErrorMessage('Camera access denied. Please grant permission in settings.');
      } else {
        debugPrint('Error starting image stream: $e');
        _showErrorMessage('Error starting camera stream.');
      }
      _isStreaming = false;
    }
  }

  Future<void> _stopGuideStream() async {
    if (_cameraController == null) return;
    if (_cameraController!.value.isStreamingImages) {
      try {
        await _cameraController!.stopImageStream();
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 80));
    }
    _isStreaming = false;
  }

  /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
  Future<void> _showOverlayThenGoHome({
    required bool success,
    required DateTime when,
    String? employeeId,
  }) async {
    if (!mounted) return;

    // 1) remove the black processing mask so the dialog is visible
    setState(() => _isProcessing = false);

    // 2) make sure camera surfaces are gone (prevents a black preview underneath)
    await _teardownCamera();

    // 3) show result overlay
    final kind = (widget.punchType.toString().toLowerCase().contains('out'))
        ? PunchResultKind.outPunch
        : PunchResultKind.inPunch;

    await showPunchResult(
      context,
      success: success,
      kind: kind,
      punchedAt: when,
      employeeId: employeeId, // printed on success
    );

    if (!mounted) return;

    // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
    Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
          (route) => false,
    );
  }

  Future<void> _initializeCamera() async {
    final stopwatch = Stopwatch()..start();
    debugPrint('[Timing] Camera initialization started.');
    try {
      _cameraController = await CameraManager.getController();
      if (!mounted) return;

      setState(() {
        _isCameraInitialized = true;
      });

      _recalcRects(context); // compute overlay geometry
      _resetAutoCaptureGates();
      await _startGuideStream();
    } catch (e) {
      if (mounted) {
        _showErrorMessage('Failed to initialize camera.');
      }
    }
    stopwatch.stop();
    debugPrint('[Timing] Camera initialization completed in ${stopwatch.elapsedMilliseconds} ms');
  }


  /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC WITH ADAPTIVE CONSENSUS AND LIVENESS ---
  Future<void> _takePictureAndProcess() async {
    final stopwatch = Stopwatch()..start();
    debugPrint('[Timing] Recognition process started at ${DateTime.now()}');

    if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) {
      debugPrint('[Timing] Recognition process aborted: camera not ready or processing');
      return;
    }

    if (!_isAligned) {
      _showErrorMessage('Align your face until the oval turns green.');
      return;
    }

    setState(() => _isProcessing = true);

    // 1. Stop camera stream & track time
    final stopStreamStopwatch = Stopwatch()..start();
    if (_cameraController!.value.isStreamingImages) {
      try {
        await _cameraController!.stopImageStream();
      } catch (_) {}
      _isStreaming = false;
    }
    stopStreamStopwatch.stop();
    debugPrint('[Timing] Camera stream stopped in ${stopStreamStopwatch.elapsedMilliseconds} ms');

    try {
      String? committedId;
      _liveness.reset();
      ThresholdPolicy policy = ThresholdPolicy.daylight;
      const Duration maxRecognitionTime = Duration(seconds: 3);
      const Duration frameCaptureInterval = Duration(milliseconds: 200);
      const int maxFramesToCapture = 8;

      final startedTime = DateTime.now();
      bool sawLivenessInWindow = false;
      String? currentCandidateId;
      int currentCandidateStreak = 0;
      RecognitionResult? lastRecognitionResult;
      int framesProcessed = 0;

      while (committedId == null &&
          DateTime.now().difference(startedTime) < maxRecognitionTime &&
          framesProcessed < maxFramesToCapture) {
        framesProcessed++;

        if (!_isAligned) {
          await Future.delayed(const Duration(milliseconds: 100));
          framesProcessed--;
          continue;
        }

        while (_cameraController!.value.isTakingPicture) {
          await Future.delayed(const Duration(milliseconds: 40));
        }

        // 2. Take picture & track time
        final frameStopwatch = Stopwatch()..start();
        XFile frame;
        try {
          frame = await _cameraController!.takePicture();
        } on CameraException catch (e) {
          if (e.description?.contains('maxImages') == true) {
            await Future.delayed(const Duration(milliseconds: 200));
            framesProcessed--;
            continue;
          }
          rethrow;
        }
        frameStopwatch.stop();
        debugPrint('[Timing] Captured frame in ${frameStopwatch.elapsedMilliseconds} ms');

        await Future.delayed(const Duration(milliseconds: 80));

        // 3. Face recognition call & time
        final recognitionStopwatch = Stopwatch()..start();
        final res = await _faceRecognitionService.recognizeFaceDetailed(frame);
        recognitionStopwatch.stop();
        debugPrint('[Timing] Face recognition took ${recognitionStopwatch.elapsedMilliseconds} ms');

        lastRecognitionResult = res;

        // 4. Liveness check & time
        final livenessStopwatch = Stopwatch()..start();
        final decodedImage = await _decodeImage(frame);
        if (decodedImage != null &&
            _liveness.pass(
              decodedImage,
              (_faceRecognitionService.lastMeanLuma ?? 100.0) < 85 ? Lighting.lowLight : Lighting.daylight,
            )) {
          sawLivenessInWindow = true;
        }
        livenessStopwatch.stop();
        debugPrint('[Timing] Liveness check took ${livenessStopwatch.elapsedMilliseconds} ms');

        // Voting and consensus logic...

        final elapsed = DateTime.now().difference(startedTime);
        if (elapsed < maxRecognitionTime) {
          final timeToWait = frameCaptureInterval - (DateTime.now().difference(startedTime) - elapsed);
          if (timeToWait > Duration.zero) {
            await Future.delayed(timeToWait);
          }
        }
      }

      stopwatch.stop();
      debugPrint('[Timing] Recognition process ended. Total duration: ${stopwatch.elapsedMilliseconds} ms');

      if (committedId != null) {
        // SUCCESS: submit punch
        await _submitPunch(committedId);
        _failedAttempts = 0;
      } else {
        // FAILURE: fallback and retry logic
        _failedAttempts++;
        if (_failedAttempts >= 3) {
          final enteredPin = await showFallbackPinDialog(context);
          if (enteredPin != null && enteredPin.isNotEmpty) {
            final id = enteredPin.trim().toUpperCase();
            final verifyFrame = await _cameraController!.takePicture();
            final pass = await _faceRecognitionService.verify1to1(id, verifyFrame, policy: policy);
            if (pass) {
              await _submitPunch(id);
              return;
            } else {
              _showErrorMessage('PIN verification failed. Please try again.');
            }
          }
          _failedAttempts = 0;
        }
        final reasonMessage = _messageForReject(lastRecognitionResult);
        _showErrorMessage(reasonMessage);
        setState(() => _isProcessing = false);
        await _startGuideStream();
      }
    } catch (e) {
      debugPrint('❌ Error during face recognition or punch processing: $e');
      stopwatch.stop();
      debugPrint('[Timing] Recognition process failed after ${stopwatch.elapsedMilliseconds} ms');
      _showErrorMessage('An unexpected error occurred. Please try again.');
      setState(() => _isProcessing = false);
      await _startGuideStream();
    } finally {
      if (!_isStreaming &&
          mounted &&
          _cameraController != null &&
          _cameraController!.value.isInitialized) {
        await _startGuideStream();
      }
      if (mounted) setState(() => _isProcessing = false);
    }
  }


  // Update the _messageForReject function
  String _messageForReject(RecognitionResult? lastResult) {
    final mean = _faceRecognitionService.lastMeanLuma ?? 999;
    final sharp = _faceRecognitionService.lastSharpness ?? 999;
    final lastD1 = lastResult?.d1;

    // current policy (or fallback)
    final effectivePolicy = _faceRecognitionService.currentPolicy;
    final threshold =
        lastResult?.threshold ?? effectivePolicy?.baseDistance ?? THR_FLOAT_BASE;

    switch (lastResult?.reason) {
      case RejectReason.lowLight:
        return 'Too dim. Move into better light or face a brighter area.';
      case RejectReason.poorQuality:
        return 'Hold steady for a moment—avoid motion blur.';
      case RejectReason.faceTooSmall:
        return 'Move closer so your face fills more of the frame.';
      case RejectReason.lowMargin:
        return 'Face not distinct enough. Ensure good lighting, look straight, and try adjusting glasses or headwear.';
      case RejectReason.aboveThreshold:
        return 'Face not recognized. Try again facing forward directly, or adjust glasses/headwear.';
      case RejectReason.noFace:
        return 'No face detected—center your face in the frame.';
      case RejectReason.galleryEmpty:
      case RejectReason.noValidVectors:
        return 'No enrolled templates available. Please re-register.';
      case null:
      // No explicit reason — infer from metrics
        if (lastD1 != null && lastD1 > threshold * 1.05) {
          return 'Face not recognized. Please re-align or adjust glasses/headwear.';
        }
        if (mean < 75) return 'Too dim. Move into better light.';
        if (sharp < 500) return 'Hold steady to reduce blur.';
        return 'Hold steady, look at the camera, and try again.';
      default:
        return 'Hold steady, look at the camera, and try again.';
    }
  }

  Future<void> _submitPunch(String employeeId) async {
    final position = await _getCurrentLocation();

    final punchEvent = PunchEvent(
      employeeId: employeeId,
      eventTime: DateTime.now(),
      punchType: widget.punchType,
      status: 'VALID',
      deviceId: 'KIOSK01',
      latitude: position?.latitude,
      longitude: position?.longitude,
    );

    await _faceRecognitionService.logPunchDecision(
      widget.punchType == PunchType.IN ? 'IN' : 'OUT',
      employeeId: employeeId,
    );

    final connectivityResult = await Connectivity().checkConnectivity();
    final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
        connectivityResult.contains(ConnectivityResult.wifi);

    if (isOnline) {
      final timesheet = Timesheet(
        employeeId: punchEvent.employeeId,
        workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
        punchEvents: [
          PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!),
        ],
      );

      final success = await _apiService.sendBulkTimsheets([timesheet]);
      if (success) {
        _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
        await _showOverlayThenGoHome(
          success: true,
          when: punchEvent.eventTime,
          employeeId: employeeId,
        );
        return;
      }

      await DatabaseService.instance.addPunchEventToQueue(punchEvent);
      _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
      await _showOverlayThenGoHome(
        success: true,
        when: punchEvent.eventTime,
        employeeId: employeeId,
      );
      return;
    } else {
      await DatabaseService.instance.addPunchEventToQueue(punchEvent);
      _showSuccessMessage(
        'Welcome, $employeeId! Punch saved. Will sync when online.',
      );
      await _showOverlayThenGoHome(
        success: true,
        when: punchEvent.eventTime,
        employeeId: employeeId,
      );
      return;
    }
  }

  Future<Position?> _getCurrentLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // ignore: avoid_print
        print('Location services are disabled.');
        return null;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission != LocationPermission.whileInUse &&
            permission != LocationPermission.always) {
          // ignore: avoid_print
          print('Location permission denied.');
          return null;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        // ignore: avoid_print
        print('Location permissions are permanently denied.');
        return null;
      }

      return Geolocator.getCurrentPosition();
    } catch (e) {
      // ignore: avoid_print
      print('Error getting location: $e');
      return null;
    }
  }

  void _showSuccessMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text(message),
      ),
    );
  }

  void _showErrorMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(message),
      ),
    );
  }

  Future<void> _showOverlayThenExit({
    required bool success,
    required DateTime when,
    String? employeeId,
  }) async {
    if (!mounted) return;

    // 1) remove the black processing mask so the dialog is visible
    setState(() => _isProcessing = false);

    // ✅ Stop camera before dialogs/navigation to prevent buffer errors.
    await _teardownCamera();

    final kind = (widget.punchType.toString().toLowerCase().contains('out'))
        ? PunchResultKind.outPunch
        : PunchResultKind.inPunch;

    await showPunchResult(
      context,
      success: success,
      kind: kind,
      punchedAt: when,
      employeeId: employeeId,
    );

    if (!mounted) return;

    // Go back to Home (first route)
    Navigator.of(context).popUntil((route) => route.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        alignment: Alignment.center,
        children: [
          if (_isCameraInitialized && _cameraController != null)
            Center(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  CameraPreview(_cameraController!),

                  if (kDebugMode)
                    Positioned(
                      top: 48,
                      left: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        color: Colors.black54,
                        child: Text(
                          'luma=${_lastBrightness.toStringAsFixed(0)} '
                              'yaw=${_lastYaw.toStringAsFixed(0)} '
                              'roll=${_lastRoll.toStringAsFixed(0)}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                        ),
                      ),
                    ),

                  // Alignment overlay (red/green)
                  const IgnorePointer(
                    child: CustomPaint(
                      painter: _OvalGuidePainter(green: false, stroke: 6),
                    ),
                  ),

                  // We need a dynamic painter to reflect _isAligned
                  IgnorePointer(
                    child: CustomPaint(
                      painter: _OvalGuidePainter(
                        green: _isAligned,
                        stroke: 6,
                      ),
                    ),
                  ),

                  // Optional hint text
                  Positioned(
                    top: 28,
                    left: 0,
                    right: 0,
                    child: Text(
                      _isAligned ? 'Hold steady… capturing' : 'Align your face inside the frame',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            )
          else
            const Center(child: CircularProgressIndicator()),

          // Capture button
          Positioned(
            bottom: 40,
            child: FloatingActionButton(
              onPressed: _isProcessing ? null : _takePictureAndProcess,
              backgroundColor:
              _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
              child: const Icon(Icons.camera_alt),
            ),
          ),

          // Processing overlay
          if (_isProcessing)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.5),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 16),
                      Text(
                        'Recognizing face...',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _OvalGuidePainter extends CustomPainter {
  final bool green;
  final double stroke;

  const _OvalGuidePainter({
    required this.green,
    this.stroke = 5,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // same geometry as registration
    final rect = Rect.fromCenter(
      center: size.center(Offset(0, -size.height * 0.06)), // a touch higher
      width: size.width * 0.72,
      height: size.height * 0.58,
    );

    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..color = green ? Colors.greenAccent : Colors.redAccent;

    // draw oval
    canvas.drawOval(rect, p);

    // dim outside, like registration
    final path = Path()..addOval(rect);
    final overlay = Path()..addRect(Offset.zero & size);
    final outside = Path.combine(PathOperation.difference, overlay, path);
    canvas.drawPath(
      outside,
      Paint()..color = const Color.fromRGBO(0, 0, 0, 0.28),
    );
  }

  @override
  bool shouldRepaint(covariant _OvalGuidePainter old) =>
      old.green != green || old.stroke != stroke;
}

/// latest
// import 'dart:async';
// import 'package:flutter/foundation.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:intl/intl.dart';
// import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';
// import 'dart:typed_data';
//
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'dart:io' as io; // Alias for dart:io
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models/punch_event.dart';
// import '../../core/models/timesheet.dart';
// import 'home_screen.dart';
// import 'package:image/image.dart' as img;
// import 'package:kiosk/app/core/utils/threshold_policy.dart';
// import 'package:kiosk/app/core/services/liveness_service.dart';
// import 'package:kiosk/app/presentation/screens/widgets/fallback_pin_dialog.dart';
// import 'dart:math' as math;
// import 'package:google_mlkit_commons/google_mlkit_commons.dart';
//
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen>
//     with WidgetsBindingObserver { // Add WidgetsBindingObserver for app lifecycle
//   Rect? _previewRect;
//   Rect? _ovalRect;
//
//   @override
//   void didChangeAppLifecycleState(AppLifecycleState state) {
//     // App state changed, check if camera needs to be managed
//     final CameraController? cameraController = _cameraController;
//
//     if (cameraController == null || !cameraController.value.isInitialized) {
//       return;
//     }
//
//     if (state == AppLifecycleState.inactive) {
//       // Free up camera resources when the app is inactive
//       _teardownCamera(); // Use the robust teardown method
//     } else if (state == AppLifecycleState.resumed) {
//       // Reinitialize camera when the app resumes
//       _initializeCamera();
//     }
//   }
//
//   Rect _previewRectInScreen(Size screen, Size preview) {
//     final screenAR = screen.height / screen.width;
//     final previewAR = preview.height / preview.width; // camera gives landscape
//     if (screenAR > previewAR) {
//       final h = screen.height;
//       final w = h / previewAR;
//       final left = (screen.width - w) / 2;
//       return Rect.fromLTWH(left, 0, w, h);
//     } else {
//       final w = screen.width;
//       final h = w * previewAR;
//       final top = (screen.height - h) / 2;
//       return Rect.fromLTWH(0, top, w, h);
//     }
//   }
//
//   bool _pointInEllipse(Offset p, Rect ellipse) {
//     final dx = (p.dx - ellipse.center.dx) / (ellipse.width / 2);
//     final dy = (p.dy - ellipse.center.dy) / (ellipse.height / 2);
//     return dx * dx + dy * dy <= 1.0;
//   }
//
//   void _recalcRects(BuildContext context) {
//     if (_cameraController == null || !_cameraController!.value.isInitialized) return;
//     final screen = MediaQuery.of(context).size;
//
//     // previewSize is landscape; swap for portrait UI
//     final pv = _cameraController!.value.previewSize!;
//     final preview = Size(pv.height.toDouble(), pv.width.toDouble());
//
//     _previewRect = _previewRectInScreen(screen, preview);
//
//     _ovalRect = Rect.fromCenter(
//       center: _previewRect!.center.translate(0, -_previewRect!.height * 0.06),
//       width: _previewRect!.width * 0.72,
//       height: _previewRect!.height * 0.58,
//     );
//   }
//
//
//   Uint8List _yuv420ToNv21(CameraImage image) {
//     // Convert 3-plane YUV_420_888 to interleaved NV21 (Y + VU)
//     final y = image.planes[0].bytes;
//     final u = image.planes[1].bytes;
//     final v = image.planes[2].bytes;
//
//     final out = Uint8List(y.length + u.length + v.length);
//     out.setAll(0, y);
//     for (int i = 0, j = y.length; i < u.length; i++, j += 2) {
//       out[j] = v[i];       // V
//       out[j + 1] = u[i];   // U
//     }
//     return out;
//   }
//
//   Uint8List _bytesForMlkit(CameraImage image) {
//     // If single plane (BGRA on iOS, or some NV21), just use it
//     if (image.planes.length == 1) return image.planes[0].bytes;
//     // Typical Android YUV_420_888 → convert to NV21
//     return _yuv420ToNv21(image);
//   }
//
//   double _estimateLuma(CameraImage image) {
//     // Single-plane path: NV21 (Android) or BGRA (iOS)
//     if (image.planes.length == 1) {
//       if (defaultTargetPlatform == TargetPlatform.iOS) {
//         // BGRA: sample G channel
//         final b = image.planes[0].bytes;
//         double sum = 0;
//         int n = 0;
//         for (int i = 1; i < b.length; i += 16) {
//           sum += b[i];
//           n++;
//         } // G
//         return n == 0 ? 0 : sum / n;
//       } else {
//         // NV21: Y is the first W*H bytes; sample that region
//         final b = image.planes[0].bytes;
//         final yLen = image.width * image.height;
//         if (b.isEmpty || yLen <= 0 || yLen > b.length) return 0;
//         double sum = 0;
//         int n = 0;
//         for (int i = 0; i < yLen; i += 8) {
//           sum += b[i];
//           n++;
//         }
//         return n == 0 ? 0 : sum / n;
//       }
//     }
//
//     // 3-plane YUV_420_888: sample Y plane directly
//     final y = image.planes[0].bytes;
//     double sum = 0;
//     int n = 0;
//     for (int i = 0; i < y.length; i += 8) {
//       sum += y[i];
//       n++;
//     }
//     return n == 0 ? 0 : sum / n;
//   }
//
//
//   // --- Guidance stream / overlay state ---
//   final FaceDetector _guideDetector = FaceDetector(
//     options: FaceDetectorOptions(
//       performanceMode: FaceDetectorMode.fast,
//       enableLandmarks: false,
//       enableContours: false,
//       enableClassification: false,
//       minFaceSize: 0.15,
//     ),
//   );
//   // ignore: unused_field
//   bool _isStreaming = false;
//   bool _isAnalyzing = false;
//
//   // Live alignment state for overlay + capture gating
//   bool _isAligned = false;
//   int _alignedStreak = 0;
//   static const int _alignedNeeded = 3; // frames-in-a-row to turn GREEN
//
//   // last guidance diagnostics (optional; helpful for threshold tuning)
//
//   double _lastYaw = 0, _lastRoll = 0, _lastBrightness = 999;
//
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//
//   final FaceRecognitionService _faceRecognitionService =
//   FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//
//   bool _isProcessing = false;
//   bool _isClosing = false; // prevents double-dispose
//
//
//   final LivenessService _liveness = LivenessService();
//   int _failedAttempts = 0;
//
//   // helper: decode to image (for liveness only)
//   Future<img.Image?> _decodeImage(XFile xf) async {
//     try {
//       final b = await xf.readAsBytes();
//       return img.decodeImage(b);
//     } catch (_) {
//       return null;
//     }
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance.addObserver(this); // Register observer
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     WidgetsBinding.instance.removeObserver(this); // Unregister observer
//     _guideDetector.close();
//     _teardownCamera(); // Use the robust teardown method
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _teardownCamera() async {
//     if (_isClosing) return;
//     _isClosing = true;
//     try {
//       final c = _cameraController;
//       if (c != null) {
//         if (c.value.isInitialized && c.value.isStreamingImages) {
//           try {
//             await c.stopImageStream();
//           } catch (_) {}
//           await Future.delayed(const Duration(milliseconds: 80)); // drain buffers
//         }
//         try {
//           await c.dispose();
//         } catch (_) {}
//       }
//     } finally {
//       _cameraController = null;
//       _isClosing = false;
//     }
//   }
//
//   Future<void> _startGuideStream() async {
//     if (_cameraController == null) return;
//     if (!_cameraController!.value.isInitialized) return;
//     if (_cameraController!.value.isStreamingImages) {
//       _isStreaming = true;
//       return;
//     } // Already streaming
//
//     _isStreaming = true;
//     try {
//       await _cameraController!.startImageStream((CameraImage image) async {
//         if (_isAnalyzing || _isProcessing) return; // throttle
//         _isAnalyzing = true;
//         try {
//           // ---------- Platform-aware format + metadata ----------
//           final bytes = _bytesForMlkit(image);
//           final bool singlePlane = image.planes.length == 1;
//
//           late final InputImageFormat fmt;
//           late final int bpr;
//
//           if (singlePlane) {
//             if (defaultTargetPlatform == TargetPlatform.iOS) {
//               fmt = InputImageFormat.bgra8888;
//               bpr = image.planes[0].bytesPerRow;
//             } else {
//               // Android single-plane -> NV21
//               fmt = InputImageFormat.nv21;
//               bpr = image.width; // NV21 stride == width
//             }
//           } else {
//             // 3-plane YUV_420_888 -> we convert to NV21 bytes
//             fmt = InputImageFormat.nv21;
//             bpr = image.width;
//           }
//
//           final rotation = InputImageRotationValue.fromRawValue(
//             _cameraController!.description.sensorOrientation,
//           ) ?? InputImageRotation.rotation0deg;
//
//           final metadata = InputImageMetadata(
//             size: Size(image.width.toDouble(), image.height.toDouble()),
//             rotation: rotation,
//             format: fmt,
//             bytesPerRow: bpr,
//           );
//
//           final inputImage = InputImage.fromBytes(bytes: bytes, metadata: metadata);
//
//           // ---------- Declare all vars up-front so they exist for logs ----------
//           bool aligned = false;
//           bool sizeOk = false, centerOk = false, angleOk = false, lightOk = false;
//           double yaw = 0, roll = 0, pitch = 0;
//
//           // brightness (works for NV21 & BGRA)
//           final meanY = _estimateLuma(image);
//           _lastBrightness = meanY;
//           lightOk = meanY >= 60;
//
//
//           // ---------- Detect faces ----------
//           final faces = await _guideDetector.processImage(inputImage);
//
//           if (faces.isNotEmpty) {
//             faces.sort((a, b) =>
//                 (b.boundingBox.width * b.boundingBox.height)
//                     .compareTo(a.boundingBox.width * a.boundingBox.height));
//             final f = faces.first;
//
//             final imgW = metadata.size.width;
//             final imgH = metadata.size.height;
//
//             final cx = f.boundingBox.center.dx / imgW;
//             final cy = f.boundingBox.center.dy / imgH;
//             final w = f.boundingBox.width / imgW;
//             final h = f.boundingBox.height / imgH;
//
//             // bail out if rects not ready (first few frames)
//             if (_previewRect == null || _ovalRect == null) {
//               _isAnalyzing = false;
//               return;
//             }
//
//             // map normalized image coords → on-screen coords inside the preview
//             final cxScreen = _previewRect!.left + cx * _previewRect!.width;
//             final cyScreen = _previewRect!.top + cy * _previewRect!.height;
//             final wScreen = w * _previewRect!.width;
//             final hScreen = h * _previewRect!.height;
//
//             // center gate: inside the drawn ellipse
//             centerOk = _pointInEllipse(Offset(cxScreen, cyScreen), _ovalRect!);
//
//             // size gate: fits well inside the ellipse (leave a small margin)
//             sizeOk = wScreen <= _ovalRect!.width * 0.95 &&
//                 hScreen <= _ovalRect!.height * 0.95 &&
//                 (wScreen >= _ovalRect!.width * 0.40 || hScreen >= _ovalRect!.height * 0.40);
//
//
//             yaw = (f.headEulerAngleY ?? 0).abs().toDouble();
//             roll = (f.headEulerAngleZ ?? 0).abs().toDouble();
//             pitch = (f.headEulerAngleX ?? 0).abs().toDouble();
//
//             _lastYaw = yaw;
//             _lastRoll = roll;
//
//             angleOk = (yaw <= 20) && (roll <= 15) && (pitch <= 12);
//
//
//             aligned = sizeOk && centerOk && angleOk && lightOk;
//           }
//
//           // ---------- Maintain streak & update UI ----------
//           if (aligned) {
//             _alignedStreak++;
//           } else {
//             _alignedStreak = 0;
//           }
//           final nowAligned = _alignedStreak >= _alignedNeeded;
//           if (nowAligned != _isAligned && mounted) {
//             setState(() => _isAligned = nowAligned);
//           }
//
//           // ---------- Helpful log ----------
//           if (kDebugMode) {
//             debugPrint(
//                 '[guide] faces=${faces.length} '
//                     'luma=${_lastBrightness.toStringAsFixed(0)} '
//                     'sizeOk=$sizeOk centerOk=$centerOk '
//                     'yaw=${yaw.toStringAsFixed(1)} roll=${roll.toStringAsFixed(1)} pitch=${pitch.toStringAsFixed(1)} '
//                     'lightOk=$lightOk aligned=$aligned streak=$_alignedStreak'
//             );
//           }
//         } catch (_) {
//           // ignore transient errors
//         } finally {
//           _isAnalyzing = false;
//         }
//       });
//     } on CameraException catch (e) {
//       if (e.code == 'CameraAccessDenied') {
//         _showErrorMessage('Camera access denied. Please grant permission in settings.');
//       } else {
//         debugPrint('Error starting image stream: $e');
//         _showErrorMessage('Error starting camera stream.');
//       }
//       _isStreaming = false;
//     }
//   }
//
//
//   Future<void> _stopGuideStream() async {
//     if (_cameraController == null) return;
//     if (_cameraController!.value.isStreamingImages) {
//       try {
//         await _cameraController!.stopImageStream();
//       } catch (_) {}
//       await Future.delayed(const Duration(milliseconds: 80)); // drain buffers
//     }
//     _isStreaming = false;
//   }
//
//   /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
//   Future<void> _showOverlayThenGoHome({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // 2) make sure camera surfaces are gone (prevents a black preview underneath)
//     await _teardownCamera();
//
//     // 3) show result overlay
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId, // printed on success
//     );
//
//     if (!mounted) return;
//
//     // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
//     Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (_) => const HomeScreen()),
//           (route) => false,
//     );
//   }
//
//
//   Future<void> _initializeCamera() async {
//     if (_isCameraInitialized && _cameraController != null && _cameraController!.value.isInitialized) {
//       // Camera already initialized, just ensure guide stream is running
//       await _startGuideStream();
//       return;
//     }
//
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.high, // ✅ was ResolutionPreset.medium
//         enableAudio: false,
//         imageFormatGroup: ImageFormatGroup.nv21, // ✅ important for Android
//       );
//
//       await _cameraController!.initialize();
//       try {
//         await _cameraController!.setFlashMode(FlashMode.auto); // helps in low light
//       } catch (_) {}
//       try {
//         await _cameraController!.setFocusMode(FocusMode.auto); // keep AF active if supported
//       } catch (_) {}
//
//
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//       _recalcRects(context); // <— add this line
//       // ⬇️ Start the face-alignment guidance stream
//       await _startGuideStream(); // ⬅ start the live guidance stream
//
//     } on CameraException catch (e) {
//       debugPrint('❌ Error initializing camera: $e');
//       if (mounted) {
//         if (e.code == 'CameraAccessDenied') {
//           _showErrorMessage('Camera access denied. Please grant permission in settings.');
//         } else {
//           _showErrorMessage('Failed to initialize camera.');
//         }
//       }
//     } catch (e) {
//       debugPrint('❌ Error initializing camera: $e');
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//       }
//     }
//   }
//
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC WITH ADAPTIVE CONSENSUS AND LIVENESS ---
//   Future<void> _takePictureAndProcess() async {
//     if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//
//     // Only start an attempt if the guide is green
//     if (!_isAligned) {
//       _showErrorMessage('Align your face until the oval turns green.');
//       return;
//     }
//
//     setState(() => _isProcessing = true);
//
//     // Stop analysis stream during still capture to avoid "maxImages" / buffer pressure
//     if (_cameraController!.value.isStreamingImages) {
//       try {
//         await _cameraController!.stopImageStream();
//       } catch (_) {}
//       _isStreaming = false; // Set to false here, will be restarted later
//     }
//
//     try {
//       String? committedId;
//       _liveness.reset(); // Reset liveness for new attempt
//
//       // Initial policy (daylight as default), will adapt
//       ThresholdPolicy policy = ThresholdPolicy.daylight;
//
//       // Define recognition window parameters
//       const Duration maxRecognitionTime = Duration(seconds: 3);
//       const Duration frameCaptureInterval = Duration(milliseconds: 200); // Increased for stability
//       const int maxFramesToCapture = 8; // More frames give more chances for consensus
//
//       final startedTime = DateTime.now();
//       bool sawLivenessInWindow = false; // Track liveness status for the current window
//
//       // Voting variables
//       String? currentCandidateId;
//       int currentCandidateStreak = 0;
//       RecognitionResult? lastRecognitionResult; // Store the last detailed result
//
//       int framesProcessed = 0;
//
//       while (committedId == null && DateTime.now().difference(startedTime) < maxRecognitionTime && framesProcessed < maxFramesToCapture) {
//         framesProcessed++;
//
//         // Ensure camera is not busy and still aligned
//         if (!_isAligned) {
//           // If alignment is lost, pause briefly and try again, but don't count this as a processed frame
//           await Future.delayed(const Duration(milliseconds: 100));
//           framesProcessed--;
//           continue;
//         }
//
//         // Wait if a capture is still in-flight
//         while (_cameraController!.value.isTakingPicture) {
//           if (!mounted) return;
//           await Future.delayed(const Duration(milliseconds: 40));
//         }
//
//         XFile frame;
//         try {
//           frame = await _cameraController!.takePicture();
//         } on CameraException catch (e) {
//           if (e.description?.contains('maxImages') == true) {
//             await Future.delayed(const Duration(milliseconds: 200)); // Give camera a break
//             framesProcessed--; // Don't count this failed capture
//             continue;
//           }
//           rethrow;
//         }
//         await Future.delayed(const Duration(milliseconds: 80)); // Allow pipeline to breathe
//
//         // --- Perform Detailed Recognition ---
//         final res = await _faceRecognitionService.recognizeFaceDetailed(frame);
//         lastRecognitionResult = res; // Store the result
//
//         // Update lighting policy based on the frame's brightness
//         final meanLuma = _faceRecognitionService.lastMeanLuma ?? 100.0;
//         policy = (meanLuma < 85) ? ThresholdPolicy.lowLight : ThresholdPolicy.daylight;
//         _faceRecognitionService.setPolicy(policy); // Update policy in service for subsequent calls
//
//         // --- Liveness Check ---
//         final decodedImage = await _decodeImage(frame);
//         if (decodedImage != null && _liveness.pass(decodedImage, (meanLuma < 85) ? Lighting.lowLight : Lighting.daylight)) {
//           sawLivenessInWindow = true;
//         }
//
//         // --- Voting Logic for ID Consensus ---
//         String? frameRecognizedId = res.employeeId; // This is the best ID from RecognitionResult
//         bool isStrongMatch = _faceRecognitionService.lastDecisionIsStrong; // From face_recognition_service
//
//         if (frameRecognizedId != null) {
//           if (frameRecognizedId == currentCandidateId) {
//             currentCandidateStreak++;
//           } else {
//             // New candidate or streak broken
//             currentCandidateId = frameRecognizedId;
//             currentCandidateStreak = 1;
//           }
//
//           // Determine required consensus: more frames for weak matches
//           final int requiredConsensus = policy.requiredConsensus;
//           final int actualRequired = isStrongMatch ? requiredConsensus : (requiredConsensus + 1); // Weak matches need 1 more
//
//           if (currentCandidateStreak >= actualRequired && sawLivenessInWindow) {
//             committedId = currentCandidateId;
//             break; // Consensus reached
//           }
//
//           if (kDebugMode) {
//             debugPrint('[PUNCH_VOTE] ID: $frameRecognizedId, Streak: $currentCandidateStreak/$actualRequired, Strong: $isStrongMatch, Liveness OK: $sawLivenessInWindow');
//           }
//         } else {
//           // If no employeeId recognized in this frame, reset streak (or if mismatch)
//           currentCandidateId = null;
//           currentCandidateStreak = 0;
//         }
//
//         // Pacing for the next frame
//         final elapsed = DateTime.now().difference(startedTime);
//         if (elapsed < maxRecognitionTime) {
//           final timeToWait = frameCaptureInterval - (DateTime.now().difference(startedTime) - elapsed);
//           if (timeToWait > Duration.zero) { // Corrected: use > Duration.zero
//             await Future.delayed(timeToWait);
//           }
//         }
//       }
//
//       // --- Decision Time ---
//       if (committedId != null) {
//         // SUCCESS: Submit punch
//         await _submitPunch(committedId);
//         _failedAttempts = 0; // Reset failed attempts on success
//       } else {
//         // FAILURE: No consensus or liveness failed within the window
//         _failedAttempts++;
//
//         if (kDebugMode) {
//           debugPrint('[PUNCH_FAIL] No consensus or liveness failed. Failed attempts: $_failedAttempts');
//         }
//
//         // Fallback to PIN after multiple failures
//         if (_failedAttempts >= 3) {
//           final enteredPin = await showFallbackPinDialog(context);
//           if (enteredPin != null && enteredPin.isNotEmpty) {
//             // Try 1:1 verification with PIN-entered ID
//             final verifyFrame = await _cameraController!.takePicture();
//             final pass = await _faceRecognitionService.verify1to1(enteredPin, verifyFrame, policy: policy);
//
//             if (pass) {
//               await _submitPunch(enteredPin);
//               return;
//             } else {
//               _showErrorMessage('PIN verification failed. Please try again.');
//             }
//           }
//           _failedAttempts = 0; // Reset after PIN attempt, regardless of its outcome
//         }
//
//         // If not successful or PIN failed, show error message and restart guide stream
//         String reasonMessage = _messageForReject(lastRecognitionResult); // Pass the last RecognitionResult
//         _showErrorMessage(reasonMessage);
//         setState(() => _isProcessing = false);
//         await _startGuideStream(); // Restart stream for next attempt
//       }
//     } catch (e) {
//       debugPrint('❌ Error during face recognition or punch processing: $e');
//       _showErrorMessage('An unexpected error occurred. Please try again.');
//       setState(() => _isProcessing = false);
//       await _startGuideStream(); // Ensure camera stream is back on error
//     } finally {
//       // Always ensure the guide stream is running if we are still on the screen
//       if (!_isStreaming && mounted && _cameraController != null && _cameraController!.value.isInitialized) {
//         await _startGuideStream();
//       }
//       if (mounted) setState(() => _isProcessing = false); // Ensure UI state is reset
//     }
//   }
//
//
//   // Update the _messageForReject function
//   String _messageForReject(RecognitionResult? lastResult) {
//     final mean = _faceRecognitionService.lastMeanLuma ?? 999;
//     final sharp = _faceRecognitionService.lastSharpness ?? 999;
//     final lastD1 = lastResult?.d1;
//     // Access the current effective policy from the service
//     final effectivePolicy = _faceRecognitionService.currentPolicy;
//     // Use the result's threshold if available, otherwise fallback to current policy's baseDistance, then global constant
//     final threshold = lastResult?.threshold ?? effectivePolicy?.baseDistance ?? THR_FLOAT_BASE; // Use global constant
//
//     // Access reason directly from the result object if available
//     switch (lastResult?.reason) {
//       case RejectReason.lowLight:
//         return 'Too dim. Move into better light or face a brighter area.';
//       case RejectReason.poorQuality:
//         return 'Hold steady for a moment—avoid motion blur.';
//       case RejectReason.faceTooSmall:
//         return 'Move closer so your face fills more of the frame.';
//       case RejectReason.lowMargin:
//         return 'Face not distinct enough. Ensure good lighting, look straight, and try adjusting glasses or headwear.';
//       case RejectReason.aboveThreshold:
//         return 'Face not recognized. Try again facing forward directly, or adjust glasses/headwear.';
//     // *** MODIFICATION END ***
//       case RejectReason.noFace:
//         return 'No face detected—center your face in the frame.';
//       case RejectReason.galleryEmpty:
//       case RejectReason.noValidVectors:
//         return 'No enrolled templates available. Please re-register.';
//       case null: // If reason is null, try to infer from metrics or d1
//       // *** MODIFICATION START ***
//       // More specific fallback message if the system provides no explicit reason
//         if (lastD1 != null && lastD1 > threshold * 1.05) return 'Face not recognized. Please re-align or adjust glasses/headwear.';
//         // *** MODIFICATION END ***
//         if (mean < 75) return 'Too dim. Move into better light.';
//         if (sharp < 500) return 'Hold steady to reduce blur.';
//         return 'Hold steady, look at the camera, and try again.';
//       default:
//         return 'Hold steady, look at the camera, and try again.';
//     }
//   }
//
//   Future<void> _submitPunch(String employeeId) async {
//     final position = await _getCurrentLocation();
//     final punchEvent = PunchEvent(
//       employeeId: employeeId,
//       eventTime: DateTime.now(),
//       punchType: widget.punchType,
//       status: 'VALID',
//       deviceId: 'KIOSK01',
//       latitude: position?.latitude,
//       longitude: position?.longitude,
//     );
//
//     await _faceRecognitionService.logPunchDecision(
//       widget.punchType == PunchType.IN ? 'IN' : 'OUT', // ✅ use your actual enum
//       employeeId: employeeId,
//     );
//
//     final connectivityResult = await Connectivity().checkConnectivity();
//     final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//         connectivityResult.contains(ConnectivityResult.wifi);
//
//     if (isOnline) {
//       final timesheet = Timesheet(
//         employeeId: punchEvent.employeeId,
//         workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//         punchEvents: [PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!)],
//       );
//
//       final success = await _apiService.sendBulkTimsheets([timesheet]);
//       if (success) {
//         _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//         await _showOverlayThenGoHome(success: true, when: punchEvent.eventTime, employeeId: employeeId);
//         return;
//       }
//       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//       _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//       await _showOverlayThenGoHome(success: true, when: punchEvent.eventTime, employeeId: employeeId);
//       return;
//     } else {
//       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//       _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//       await _showOverlayThenGoHome(success: true, when: punchEvent.eventTime, employeeId: employeeId);
//       return;
//     }
//   }
//
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       final serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         // ignore: avoid_print
//         print('Location services are disabled.');
//         return null;
//       }
//
//       var permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           // ignore: avoid_print
//           print('Location permission denied.');
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         // ignore: avoid_print
//         print('Location permissions are permanently denied.');
//         return null;
//       }
//
//       return Geolocator.getCurrentPosition();
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error getting location: $e');
//       return null;
//     }
//   }
//
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message),
//       ),
//     );
//   }
//
//
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message),
//       ),
//     );
//   }
//
//   Future<void> _showOverlayThenExit({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//     // ✅ Stop camera before dialogs/navigation to prevent buffer errors.
//     await _teardownCamera();
//     // Make sure your black processing veil is gone so the overlay is visible
//     // if (mounted) setState(() => _isProcessing = false);
//
//     // Map your existing punch type to the overlay enum
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId,
//     );
//
//     if (!mounted) return;
//     // 4) go back to Home (first route). If you use named routes, adjust to your home route.
//     Navigator.of(context).popUntil((route) => route.isFirst); // return to previous screen AFTER overlay closes
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(
//               child: Stack(
//                 fit: StackFit.expand,
//                 children: [
//                   CameraPreview(_cameraController!),
//                   if (kDebugMode)
//                     Positioned(
//                       top: 48, left: 12,
//                       child: Container(
//                         padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
//                         color: Colors.black54,
//                         child: Text(
//                           'luma=${_lastBrightness.toStringAsFixed(0)}  '
//                               'yaw=${_lastYaw.toStringAsFixed(0)}  '
//                               'roll=${_lastRoll.toStringAsFixed(0)}',
//                           style: const TextStyle(color: Colors.white, fontSize: 12),
//                         ),
//                       ),
//                     ),
//
//                   // Alignment overlay (red/green)
//                   IgnorePointer(
//                     child: CustomPaint(
//                       painter: _OvalGuidePainter(green: _isAligned, stroke: 6),
//                     ),
//                   ),
//                   // Optional hint text
//                   Positioned(
//                     top: 28,
//                     left: 0,
//                     right: 0,
//                     child: Text(
//                       _isAligned ? 'Hold steady… capturing' : 'Align your face inside the frame',
//                       textAlign: TextAlign.center,
//                       style: const TextStyle(color: Colors.white70, fontSize: 14),
//                     ),
//                   ),
//                 ],
//               ),
//             )
//           else
//             const Center(child: CircularProgressIndicator()),
//
//           // Capture button
//           Positioned(
//             bottom: 40,
//             child: FloatingActionButton(
//               onPressed: _isProcessing ? null : _takePictureAndProcess,
//               backgroundColor:
//               _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
//               child: const Icon(Icons.camera_alt),
//             ),
//           ),
//
//           // Processing overlay
//           if (_isProcessing)
//             Positioned.fill(
//               child: Container(
//                 color: Colors.black.withOpacity(0.5),
//                 child: const Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       CircularProgressIndicator(),
//                       SizedBox(height: 16),
//                       Text(
//                         'Recognizing face...',
//                         style: TextStyle(color: Colors.white, fontSize: 16),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
//
// }
// class _OvalGuidePainter extends CustomPainter {
//   final bool green;
//   final double stroke;
//   const _OvalGuidePainter({required this.green, this.stroke = 5});
//
//   @override
//   void paint(Canvas canvas, Size size) {
//     // same geometry as registration
//     final rect = Rect.fromCenter(
//       center: size.center(Offset(0, -size.height * 0.06)), // a touch higher
//       width: size.width * 0.72,
//       height: size.height * 0.58,
//     );
//
//     final p = Paint()
//       ..style = PaintingStyle.stroke
//       ..strokeWidth = stroke
//       ..color = green ? Colors.greenAccent : Colors.redAccent;
//
//     // draw oval
//     canvas.drawOval(rect, p);
//
//     // dim outside, like registration
//     final path = Path()..addOval(rect);
//     final overlay = Path()..addRect(Offset.zero & size);
//     final outside = Path.combine(PathOperation.difference, overlay, path);
//     canvas.drawPath(outside, Paint()..color = const Color.fromRGBO(0, 0, 0, 0.28));
//   }
//
//   @override
//   bool shouldRepaint(covariant _OvalGuidePainter old) =>
//       old.green != green || old.stroke != stroke;
// }



//older version
// lib/app/presentation/screens/punch_camera_screen.dart
// import 'dart:async';
// import 'package:intl/intl.dart';
// import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';
//
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models/punch_event.dart';
// import '../../core/models/timesheet.dart';
// import 'home_screen.dart';
//
// // /// Put this class near the top of punch_camera_screen.dart (or in a utils file)
// class ConsensusGate {
//   final int N, K;
//   final Duration cooldown;
//
//   DateTime _lastCommit = DateTime.fromMillisecondsSinceEpoch(0);
//   final List<String?> _win = [];
//
//   ConsensusGate({
//     this.N = 7,
//     this.K = 5,
//     this.cooldown = const Duration(seconds: 4),
//   });
//
//   bool get inCooldown => DateTime.now().difference(_lastCommit) < cooldown;
//
//   String? push(String? candidate) {
//     _win.add(candidate);
//     if (_win.length > N) _win.removeAt(0);
//
//     if (candidate == null || inCooldown) return null;
//
//     final c = _win.where((x) => x == candidate).length;
//     if (c >= K) {
//       _lastCommit = DateTime.now();
//       _win.clear();
//       return candidate;
//     }
//     return null;
//   }
// }
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen>
// {
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//
//   // after:
//   final ConsensusGate _gate = ConsensusGate(N: 5, K: 3, cooldown: const Duration(seconds: 4));
//
//   final FaceRecognitionService _faceRecognitionService =
//   FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//
//   bool _isProcessing = false;
//   bool _isClosing = false; // prevents double-dispose
//
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     _cameraController?.dispose();
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _teardownCamera() async {
//     if (_isClosing) return;
//     _isClosing = true;
//     try {
//       final c = _cameraController;
//       if (c != null) {
//         // If you ever enable image stream, always stop it first
//         if (c.value.isInitialized && c.value.isStreamingImages) {
//           try { await c.stopImageStream(); } catch (_) {}
//         }
//         try { await c.dispose(); } catch (_) {}
//       }
//     } finally {
//       _cameraController = null;
//       _isClosing = false;
//     }
//   }
//
//   /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
//   Future<void> _showOverlayThenGoHome({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // 2) make sure camera surfaces are gone (prevents a black preview underneath)
//     await _teardownCamera();
//
//     // 3) show result overlay
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId, // printed on success
//     );
//
//     if (!mounted) return;
//
//     // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
//     Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (_) => const HomeScreen()),
//           (route) => false,
//     );
//   }
//
//
//   Future<void> _initializeCamera() async {
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.medium,
//         enableAudio: false,
//       );
//
//       await _cameraController!.initialize();
//
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error initializing camera: $e');
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//       }
//     }
//   }
//
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC ---
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC WITH CONSENSUS ---
//   Future<void> _takePictureAndProcess() async {
//     if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//     setState(() => _isProcessing = true);
//
//     final started = DateTime.now();
//     const totalBudget = Duration(seconds: 3);      // hard cap for recognition
//     const interFrame = Duration(milliseconds: 160); // spacing between frames
//
//     try {
//       String? committedId;
//
//       // Keep capturing until we either get consensus or run out of time
//       while (committedId == null && DateTime.now().difference(started) < totalBudget) {
//         // 1) capture a frame
//         final image = await _cameraController!.takePicture();
//
//         // 2) run recognition
//         String? candidate = await _faceRecognitionService.recognizeFace(image);
//
//         // 3) one-shot retry (preserved), only if we still have time left
//         if (candidate == null) {
//           const retryDelay = Duration(milliseconds: 250);
//           if (DateTime.now().difference(started) + retryDelay < totalBudget) {
//             await Future.delayed(retryDelay);
//             final retry = await _cameraController!.takePicture();
//             candidate = await _faceRecognitionService.recognizeFace(retry);
//           }
//         }
//
//         // 4) vote into the consensus window
//         committedId = _gate.push(candidate);
//
//         // brief spacing between frames so the user can steady their face,
//         // but don't exceed the total time budget
//         if (committedId == null) {
//           final elapsed = DateTime.now().difference(started);
//           if (elapsed + interFrame >= totalBudget) break;
//           await Future.delayed(interFrame);
//         }
//       }
//
//       // No consensus within the time budget → soft fail and exit via overlay
//       if (committedId == null) {
//         _showErrorMessage('Authentication inconclusive—hold steady and try again.');
//         await _showOverlayThenExit(
//           success: false,
//           when: DateTime.now(),
//         );
//         return;
//       }
//
//       // ===== From here down: your existing offline-first punch code (unchanged) =====
//       final employeeId = committedId;
//       final position = await _getCurrentLocation();
//
//       final punchEvent = PunchEvent(
//         employeeId: employeeId,
//         eventTime: DateTime.now(),
//         punchType: widget.punchType,
//         status: 'VALID',
//         deviceId: 'KIOSK01', // Example device ID
//         latitude: position?.latitude,
//         longitude: position?.longitude,
//       );
//
//       await _faceRecognitionService.logPunchDecision(
//         widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//         employeeId: employeeId,
//       );
//
//       final connectivityResult = await Connectivity().checkConnectivity();
//       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//           connectivityResult.contains(ConnectivityResult.wifi);
//
//       if (isOnline) {
//         // Try direct sync
//         final timesheet = Timesheet(
//           employeeId: punchEvent.employeeId,
//           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//           punchEvents: [
//             PunchEventPayload.fromPunchEvent(
//               punchEvent,
//               punchEvent.deviceId!,
//             ),
//           ],
//         );
//
//         final success = await _apiService.sendBulkTimsheets([timesheet]);
//
//         if (success) {
//           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//           await _showOverlayThenExit(
//             success: true,
//             when: punchEvent.eventTime,
//             employeeId: employeeId,
//           );
//           return;
//         } else {
//           // Fallback to queue
//           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//           await _showOverlayThenExit(
//             success: true,
//             when: punchEvent.eventTime,
//             employeeId: employeeId,
//           );
//           return;
//         }
//       } else {
//         // Offline: queue it
//         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//         await _showOverlayThenExit(
//           success: true,
//           when: punchEvent.eventTime,
//           employeeId: employeeId,
//         );
//         return;
//       }
//       // ===== end unchanged logic =====
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error during face recognition or punch processing: $e');
//       _showErrorMessage('An error occurred. Please try again.');
//       await _showOverlayThenExit(
//         success: false,
//         when: DateTime.now(),
//       );
//       return;
//     }
//   }
//
//
//   // void _takePictureAndProcess() async {
//   //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//   //   setState(() => _isProcessing = true);
//   //
//   //
//   //   try {
//   //     final image = await _cameraController!.takePicture();
//   //
//   //     var employeeId = await _faceRecognitionService.recognizeFace(image);
//   //     if (employeeId == null) {
//   //       await Future.delayed(const Duration(milliseconds: 250));
//   //       final retry = await _cameraController!.takePicture();
//   //       employeeId = await _faceRecognitionService.recognizeFace(retry);
//   //     }
//   //
//   //     if (employeeId != null) {
//   //       final position = await _getCurrentLocation();
//   //
//   //       final punchEvent = PunchEvent(
//   //         employeeId: employeeId,
//   //         eventTime: DateTime.now(),
//   //         punchType: widget.punchType,
//   //         status: 'VALID',
//   //         deviceId: 'KIOSK01', // Example device ID
//   //         latitude: position?.latitude,
//   //         longitude: position?.longitude,
//   //       );
//   //
//   //       await _faceRecognitionService.logPunchDecision(
//   //         widget.punchType.toString(),
//   //         employeeId: employeeId,
//   //       );
//   //
//   //
//   //       final connectivityResult = await Connectivity().checkConnectivity();
//   //       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//   //           connectivityResult.contains(ConnectivityResult.wifi);
//   //
//   //       if (isOnline) {
//   //         // Try direct sync
//   //         // ignore: avoid_print
//   //         print('Device is online. Attempting to send punch event directly.');
//   //
//   //         final timesheet = Timesheet(
//   //           employeeId: punchEvent.employeeId,
//   //           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//   //           punchEvents: [
//   //             PunchEventPayload.fromPunchEvent(
//   //               punchEvent,
//   //               punchEvent.deviceId!,
//   //             ),
//   //           ],
//   //         );
//   //
//   //         await _faceRecognitionService.logPunchDecision(
//   //           widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//   //           employeeId: employeeId,
//   //         );
//   //
//   //         final success = await _apiService.sendBulkTimsheets([timesheet]);
//   //
//   //         if (success) {
//   //           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         } else {
//   //           // Fallback to queue
//   //           // ignore: avoid_print
//   //           print("Direct sync failed. Queuing punch event for later.");
//   //           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         }
//   //       } else {
//   //         // Offline: queue it
//   //         // ignore: avoid_print
//   //         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//   //         await _showOverlayThenExit(
//   //           success: true,
//   //           when: punchEvent.eventTime,
//   //           employeeId: employeeId,
//   //         );
//   //         return;
//   //
//   //       }
//   //     } else {
//   //       _showErrorMessage('Authentication Failed. Please try again.');
//   //       await _showOverlayThenExit(
//   //         success: false,
//   //         when: DateTime.now(),
//   //       );
//   //       return;
//   //     }
//   //   } catch (e) {
//   //     // ignore: avoid_print
//   //     print('Error during face recognition or punch processing: $e');
//   //     _showErrorMessage('An error occurred. Please try again.');
//   //     await _showOverlayThenExit(
//   //       success: false,
//   //       when: DateTime.now(),
//   //     );
//   //     return;
//   //   }
//   //   // finally {
//   //   //   if (mounted) {
//   //   //     Navigator.of(context).pop();
//   //   //   }
//   //   // }
//   // }
//
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       final serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         // ignore: avoid_print
//         print('Location services are disabled.');
//         return null;
//       }
//
//       var permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           // ignore: avoid_print
//           print('Location permission denied.');
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         // ignore: avoid_print
//         print('Location permissions are permanently denied.');
//         return null;
//       }
//
//       return Geolocator.getCurrentPosition();
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error getting location: $e');
//       return null;
//     }
//   }
//
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message),
//       ),
//     );
//   }
//
//
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message),
//       ),
//     );
//   }
//   Future<void> _showOverlayThenExit({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // Make sure your black processing veil is gone so the overlay is visible
//     // if (mounted) setState(() => _isProcessing = false);
//
//     // Map your existing punch type to the overlay enum
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId,
//     );
//
//     if (!mounted) return;
//     // 4) go back to Home (first route). If you use named routes, adjust to your home route.
//     Navigator.of(context).popUntil((route) => route.isFirst);// return to previous screen AFTER overlay closes
//   }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(child: CameraPreview(_cameraController!))
//           else
//             const Center(child: CircularProgressIndicator()),
//
//           // Capture button
//           Positioned(
//             bottom: 40,
//             child: FloatingActionButton(
//               onPressed: _isProcessing ? null : _takePictureAndProcess,
//               backgroundColor:
//               _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
//               child: const Icon(Icons.camera_alt),
//             ),
//           ),
//
//           // Processing overlay
//           if (_isProcessing)
//             Positioned.fill(
//               child: Container(
//                 color: Colors.black.withOpacity(0.5),
//                 child: const Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       CircularProgressIndicator(),
//                       SizedBox(height: 16),
//                       Text(
//                         'Recognizing face...',
//                         style: TextStyle(color: Colors.white, fontSize: 16),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }

// lib/app/presentation/screens/punch_camera_screen.dart

// import 'dart:async';
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:intl/intl.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models /punch_event.dart';
// import '../../core/models /timesheet.dart';
// import 'camera_utils.dart'; // Helper for image conversion
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen> {
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//   bool _isProcessing = false;
//
//   // --- SERVICES & DETECTORS ---
//   final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//   late final FaceDetector _faceDetector;
//
//   // --- DETECTION STATE ---
//   bool _isDetecting = false;
//   bool _faceDetected = false; // For UI feedback
//
//   @override
//   void initState() {
//     super.initState();
//     // Initialize with flexible options for better real-world detection
//     _faceDetector = FaceDetector(
//       options: FaceDetectorOptions(
//         performanceMode: FaceDetectorMode.fast,
//         enableClassification: true, // Required for blink detection
//         enableLandmarks: true,
//         enableContours: true, // Helps with angled faces
//         minFaceSize: 0.1, // Detect faces that are further away
//       ),
//     );
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     // Gracefully dispose all resources
//     _cameraController?.stopImageStream();
//     _cameraController?.dispose();
//     _faceDetector.close();
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _initializeCamera() async {
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.medium,
//         enableAudio: false,
//         imageFormatGroup: ImageFormatGroup.nv21, // Format for ML Kit
//       );
//
//       await _cameraController!.initialize();
//       if (!mounted) return;
//
//       // Start processing the camera feed for blinks
//       await _cameraController!.startImageStream(_processCameraImage);
//
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     } catch (e) {
//       debugPrint("Error initializing camera: $e");
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//         Navigator.of(context).pop();
//       }
//     }
//   }
//
//   /// Processes each frame from the camera to detect a face and a subsequent blink.
//   Future<void> _processCameraImage(CameraImage image) async {
//     if (_isDetecting || _isProcessing) return;
//
//     _isDetecting = true;
//     try {
//       final inputImage = InputImage.fromBytes(
//         bytes: image.planes[0].bytes,
//         metadata: CameraUtils.buildImageMetadata(image, _cameraController!),
//       );
//
//       final faces = await _faceDetector.processImage(inputImage);
//
//       if (faces.isNotEmpty) {
//         if (!_faceDetected) {
//           setState(() => _faceDetected = true);
//         }
//
//         final face = faces.first;
//         // Check if both eyes are closed
//         if ((face.leftEyeOpenProbability ?? 1.0) < 0.3 &&
//             (face.rightEyeOpenProbability ?? 1.0) < 0.3) {
//           if (!_isProcessing) {
//             setState(() => _isProcessing = true);
//             // Stop stream and capture a high-quality image for recognition
//             await _cameraController?.stopImageStream();
//             await _captureAndProcess();
//           }
//         }
//       } else {
//         if (_faceDetected) {
//           setState(() => _faceDetected = false);
//         }
//       }
//     } catch (e) {
//       debugPrint("Error processing image stream: $e");
//     } finally {
//       _isDetecting = false;
//     }
//   }
//
//   /// Captures image, runs recognition, and handles both success and failure cases.
//   Future<void> _captureAndProcess() async {
//     if (!_cameraController!.value.isInitialized) {
//       await _resetForRetry('Camera not ready. Please try again.');
//       return;
//     }
//
//     try {
//       final image = await _cameraController!.takePicture();
//       final employeeId = await _faceRecognitionService.recognizeFace(image);
//
//       if (employeeId != null) {
//         // --- SUCCESS CASE ---
//         Position? position = await _getCurrentLocation();
//         final punchEvent = PunchEvent(
//           employeeId: employeeId,
//           eventTime: DateTime.now(),
//           punchType: widget.punchType,
//           status: 'VALID',
//           deviceId: 'KIOSK01',
//           latitude: position?.latitude,
//           longitude: position?.longitude,
//         );
//
//         await _handlePunchEvent(punchEvent);
//
//         // Pop screen after a delay to show the success message
//         await Future.delayed(const Duration(seconds: 2));
//         if (mounted) {
//           Navigator.of(context).pop();
//         }
//       } else {
//         // --- FAILURE CASE: Face not recognized ---
//         await _resetForRetry('Face not recognized. Please try again.');
//       }
//     } catch (e) {
//       debugPrint("Error during capture/recognition: $e");
//       await _resetForRetry('An error occurred. Please try again.');
//     }
//   }
//
//   /// Resets the state to allow the user to attempt recognition again.
//   Future<void> _resetForRetry(String message) async {
//     _showErrorMessage(message);
//     await Future.delayed(const Duration(seconds: 2)); // Let user read message
//
//     if (mounted) {
//       setState(() {
//         _isProcessing = false;
//         _faceDetected = false;
//       });
//       // Restart the stream to look for a face and blink again
//       if (_cameraController != null && _cameraController!.value.isInitialized) {
//         await _cameraController!.startImageStream(_processCameraImage);
//       }
//     }
//   }
//
//   /// Handles the logic for sending or queueing the punch event.
//   Future<void> _handlePunchEvent(PunchEvent punchEvent) async {
//     final connectivityResult = await Connectivity().checkConnectivity();
//     final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//         connectivityResult.contains(ConnectivityResult.wifi);
//
//     if (isOnline) {
//       debugPrint("Online. Attempting to sync punch event.");
//       final timesheet = Timesheet(
//         employeeId: punchEvent.employeeId,
//         workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//         punchEvents: [
//           PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!)
//         ],
//       );
//       final success = await _apiService.sendBulkTimsheets([timesheet]);
//       if (success) {
//         _showSuccessMessage('Welcome, ${punchEvent.employeeId}! Punch synced.');
//       } else {
//         debugPrint("Direct sync failed. Queuing punch event.");
//         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//         _showSuccessMessage(
//             'Welcome, ${punchEvent.employeeId}! Punch saved, will sync later.');
//       }
//     } else {
//       debugPrint("Offline. Queuing punch event.");
//       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//       _showSuccessMessage(
//           'Welcome, ${punchEvent.employeeId}! Punch saved, will sync when online.');
//     }
//   }
//
//   /// Helper method to get the current GPS location.
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         debugPrint("Location services are disabled.");
//         return null;
//       }
//
//       LocationPermission permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           debugPrint("Location permissions were denied.");
//           return null;
//         }
//       }
//       if (permission == LocationPermission.deniedForever) {
//         debugPrint("Location permissions are permanently denied, we cannot request permissions.");
//         return null;
//       }
//
//       return await Geolocator.getCurrentPosition();
//     } catch (e) {
//       debugPrint("Error getting location: $e");
//       return null;
//     }
//   }
//
//   /// Helper method to show a green success message.
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message, style: const TextStyle(color: Colors.white)),
//       ),
//     );
//   }
//
//   /// Helper method to show a red error message.
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message, style: const TextStyle(color: Colors.white)),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(child: CameraPreview(_cameraController!))
//           else
//             const Center(child: CircularProgressIndicator(color: Colors.white)),
//
//           // Dynamic UI prompt for the user
//           Positioned(
//             bottom: 60,
//             child: Container(
//               padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
//               decoration: BoxDecoration(
//                 color: Colors.black.withOpacity(0.6),
//                 borderRadius: BorderRadius.circular(30),
//               ),
//               child: Text(
//                 _isProcessing
//                     ? 'Processing...'
//                     : (_faceDetected ? 'Blink to Punch' : 'Position Face in Frame'),
//                 style: TextStyle(
//                   color: _faceDetected && !_isProcessing
//                       ? Colors.greenAccent
//                       : Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//
//           // Loading overlay during processing
//           if (_isProcessing)
//             Container(
//               color: Colors.black.withOpacity(0.5),
//               child: const Center(
//                 child: CircularProgressIndicator(color: Colors.white),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }