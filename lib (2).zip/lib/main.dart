import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:kiosk/app/core/config/environment.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:kiosk/app/core/services/storage_service.dart';
import 'package:kiosk/app/core/services/sync_service.dart';
import 'package:kiosk/app/presentation/screens/home_screen.dart';
import 'package:kiosk/app/presentation/screens/login_screen.dart';
import 'package:kiosk/app/presentation/screens/welcome_screen.dart';

void main() async {
  // Ensure all plugins are initialized before running the app
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize services
  await DatabaseService.instance.database;
  SyncService(); // Initializes the singleton instance and its listeners

  // Initialize environment configuration
  const environment =
  String.fromEnvironment('FLAVOR', defaultValue: Environment.dev);
  Environment().init(environment);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kiosk',
      debugShowCheckedModeBanner: false, // Hides the debug banner
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        textTheme: GoogleFonts.poppinsTextTheme(
          Theme.of(context).textTheme,
        ),
        useMaterial3: true,
      ),
      // Use the AuthWrapper to determine the starting screen
      home: const AuthWrapper(),
    );
  }
}

/// A widget that determines the initial screen to display based on
/// the user's authentication and setup status.
class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  final StorageService _storageService = StorageService();

  /// Checks storage and determines the correct starting screen.
  Future<Widget> _getInitialScreen() async {
    // Check if a refresh token exists. This means the user is logged in.
    final refreshToken = await _storageService.getRefreshToken();
    if (refreshToken != null) {
      return const HomeScreen();
    }

    // If no token, check if a tenant ID exists. This means they need to log in.
    final tenantId = await _storageService.getTenantId();
    if (tenantId != null) {
      return const LoginScreen();
    }

    // If neither exists, it's the first time opening the app.
    return const WelcomeScreen();
  }

  @override
  Widget build(BuildContext context) {
    // FutureBuilder handles the asynchronous check and UI updates.
    return FutureBuilder<Widget>(
      future: _getInitialScreen(),
      builder: (context, snapshot) {
        // While waiting for the checks to complete, show a loading indicator.
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        // If the checks are done, show the screen that was determined.
        if (snapshot.hasData) {
          return snapshot.data!;
        }

        // If something went wrong, default to the WelcomeScreen.
        return const WelcomeScreen();
      },
    );
  }
}