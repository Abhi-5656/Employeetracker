// import 'dart:convert';
// import 'dart:async';//add here
// import 'dart:math' as math;
// import 'dart:typed_data';
// import 'dart:io' as io;
// import 'dart:math';
// import 'package:camera/camera.dart';
// import 'package:flutter/foundation.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:image/image.dart' as img;
// import 'package:kiosk/app/core/services/database_service.dart'; // Assuming this is your database service
// import 'package:path_provider/path_provider.dart';
// import 'package:tflite_flutter/tflite_flutter.dart';
//
// // Inside FaceRecognitionService class (top-level private types ok):
// class _Cluster {
//   final List<double> centroid;
//   final double meanR;
//   final double maxR;
//   final int n;
//   _Cluster(this.centroid, this.meanR, this.maxR, this.n);
// }
//
//
// class FaceRecognitionService {
//
//   // --- Debug state for last recognition ---
//   List<double>? _lastLiveEmb;
//   List<double>? _lastBestEmb;
//   String? _lastBestId;
//   double? _lastD1;
//   double? _lastD2;
//   double? _lastSharpness; // from _qualityMetrics
//   double? _lastBoxW, _lastBoxH;          // from the selected face bbox
//
//   // in FaceRecognitionService fields:
//   List<double>? _liveFloatEmb;   // de-quantized -> L2 (correct modern form)
//   List<double>? _liveLegacyEmb;  // raw int -> L2 (legacy form to match old DB rows)
//
//   final Completer<bool> _modelReady = Completer<bool>();
//   Future<void> _ensureReady() async {
//     if (!_modelReady.isCompleted) {
//       await _modelReady.future;
//     }
//   }
//
//   img.Image? _decodeOriented(Uint8List bytes) {
//     final im = img.decodeImage(bytes);
//     if (im == null) return null;
//     // Ensures pixels match the orientation MLKit used for bounding boxes
//     return img.bakeOrientation(im);
//   }
//
//
// // Flag the punch screen can read for early-accept (optional)
//   bool lastDecisionIsStrong = false;
//
// // FAST detector just for live recognition (skip landmarks; cheaper)
//   // Also make the live detector a bit more permissive
//   final FaceDetector _liveDetector = FaceDetector(
//     options: FaceDetectorOptions(
//       performanceMode: FaceDetectorMode.fast,
//       enableLandmarks: false,
//       enableContours: false,
//       enableClassification: false,
//       minFaceSize: 0.10, // was 0.15
//     ),
//   );
//
// // Toggle: set true to dump full 512 floats to the log file (big!)
// // Default keeps only a short sample (first 16 dims) to keep logs small.
//   bool _logFullEmbeddings = false;
// // ---- Centroid/cluster cache (rebuilt on demand) ----
//   Map<String, List<List<double>>>? _gallery;      // employeeId -> list of templates
//   Map<String, List<double>>? _centroids;          // employeeId -> centroid (L2)
//   DateTime? _centroidsBuiltAt;
//
//   /// Call this after registration updates, deletions, or re-enrolments.
//   /// (registration_screen.dart calls this)
//   void invalidateClustersCache() {
//     _gallery = null;
//     _centroids = null;
//     _centroidsBuiltAt = null;
//   }
//
//   /// Build per-employee templates and centroids from DB (lazy)
//   Future<void> _ensureCentroids() async {
//     if (_centroids != null && _gallery != null) return;
//
//     final rows = await DatabaseService.instance.getAllEmployeeProfiles();
//     final g = <String, List<List<double>>>{};
//
//     for (final r in rows) {
//       final id = r['employee_id'] as String?;
//       final raw = r['image_data'];
//       if (id == null || raw is! String || raw.isEmpty) continue;
//
//       try {
//         final parsed = jsonDecode(raw);
//         final Iterable<List<double>> vecs =
//         (parsed is List && parsed.isNotEmpty && parsed.first is List)
//             ? (parsed as List).map<List<double>>(
//                 (v) => (v as List).map((e) => (e as num).toDouble()).toList())
//             : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
//
//         for (final v in vecs) {
//           if (v.isEmpty) continue;
//           (g[id] ??= <List<double>>[]).add(_l2Normalize(v));
//         }
//       } catch (_) {
//         // skip malformed rows
//       }
//     }
//
//     // compute centroids
//     final c = <String, List<double>>{};
//     for (final entry in g.entries) {
//       c[entry.key] = _centroid(entry.value);
//     }
//
//     _gallery = g;
//     _centroids = c;
//     _centroidsBuiltAt = DateTime.now();
//
//     await _logEvent({
//       'event': 'centroids_built',
//       'people': _centroids!.length,
//     });
//   }
//
//   ///
//   Future<Map<String, List<List<double>>>> _ensureGallery() async {
//     await _ensureCentroids();
//     return _gallery ?? <String, List<List<double>>>{};
//   }
//   ({String? id1, double d1, String? id2, double d2}) _top2ByEmployee(
//       Map<String, List<List<double>>> gallery,
//       List<double> liveFloatEmb,
//       List<double>? liveLegacyEmb,
//       bool Function(List<double>) looksLegacy,
//       double Function(List<double>, List<double>) l2,
//       ) {
//     final bestPerEmp = <String, double>{};
//
//     gallery.forEach((empId, vectors) {
//       double best = double.infinity;
//       for (final v in vectors) {
//         final isLegacy = looksLegacy(v);
//         final d = isLegacy
//             ? (liveLegacyEmb == null ? double.infinity : l2(liveLegacyEmb, v))
//             : l2(liveFloatEmb, v);
//         if (d < best) best = d;
//       }
//       if (best.isFinite) bestPerEmp[empId] = best;
//     });
//
//     String? id1; double d1 = double.infinity;
//     String? id2; double d2 = double.infinity;
//
//     bestPerEmp.forEach((empId, d) {
//       if (d < d1) {
//         d2 = d1; id2 = id1;
//         d1 = d;  id1 = empId;
//       } else if (d < d2) {
//         d2 = d;  id2 = empId;
//       }
//     });
//
//     return (id1: id1, d1: d1, id2: id2, d2: d2);
//   }
//
// ///
//   List<double> _centroid(List<List<double>> vecs) {
//     if (vecs.isEmpty) return <double>[];
//     final n = vecs.first.length;
//     final acc = List<double>.filled(n, 0.0);
//     var k = 0;
//     for (final v in vecs) {
//       if (v.length != n) continue;
//       for (var i = 0; i < n; i++) acc[i] += v[i];
//       k++;
//     }
//     if (k == 0) return List<double>.filled(n, 0.0);
//     for (var i = 0; i < n; i++) acc[i] /= k;
//     return _l2Normalize(acc);
//   }
//
//   late Interpreter _interpreter;
//   final FaceDetector _faceDetector = FaceDetector(
//     options: FaceDetectorOptions(
//       performanceMode: FaceDetectorMode.accurate,
//       enableLandmarks: true,
//       enableContours: false,
//       enableClassification: false,
//       minFaceSize: 0.07, // more permissive (7%)
//     ),
//   );
//
//
//   // ---------- geometric descriptor (optional fusion) ----------
//   // Replace your _shapeDescriptor with this version
//   List<double>? _shapeDescriptor(Face f) {
//     final le = f.landmarks[FaceLandmarkType.leftEye]?.position;
//     final re = f.landmarks[FaceLandmarkType.rightEye]?.position;
//     final nose = f.landmarks[FaceLandmarkType.noseBase]?.position;
//     if (le == null || re == null || nose == null) return null;
//
//     final leftAnchor  = f.landmarks[FaceLandmarkType.leftEar]?.position
//         ?? f.landmarks[FaceLandmarkType.leftCheek]?.position;
//     final rightAnchor = f.landmarks[FaceLandmarkType.rightEar]?.position
//         ?? f.landmarks[FaceLandmarkType.rightCheek]?.position;
//
//     final bb = f.boundingBox;
//
//     // Force everything to double
//     final double leX = le.x.toDouble(), leY = le.y.toDouble();
//     final double reX = re.x.toDouble(), reY = re.y.toDouble();
//     final double noseX = nose.x.toDouble(), noseY = nose.y.toDouble();
//     final double lx = (leftAnchor?.x ?? bb.left).toDouble();
//     final double ly = (leftAnchor?.y ?? bb.center.dy).toDouble();
//     final double rx = (rightAnchor?.x ?? bb.right).toDouble();
//     final double ry = (rightAnchor?.y ?? bb.center.dy).toDouble();
//
//     // Normalize to eye center, level the eyes, scale by inter-ocular distance
//     final double cx = (leX + reX) / 2.0;
//     final double cy = (leY + reY) / 2.0;
//     final double dx = reX - leX;
//     final double dy = reY - leY;
//     final double ang = atan2(dy, dx);
//     final double dist = sqrt(dx * dx + dy * dy);
//     if (dist < 1e-6) return null;
//
//     double normX(double x, double y) {
//       final double tx = x - cx;
//       final double ty = y - cy;
//       final double rx2 =  tx * cos(-ang) - ty * sin(-ang);
//       return rx2 / dist;
//     }
//     double normY(double x, double y) {
//       final double tx = x - cx;
//       final double ty = y - cy;
//       final double ry2 =  tx * sin(-ang) + ty * cos(-ang);
//       return ry2 / dist;
//     }
//
//     // 5 points × (x,y) = 10 dims (same length as before)
//     return [
//       normX(leX, leY),   normY(leX, leY),
//       normX(reX, reY),   normY(reX, reY),
//       normX(noseX, noseY), normY(noseX, noseY),
//       normX(lx, ly),     normY(lx, ly),
//       normX(rx, ry),     normY(rx, ry),
//     ];
//   }
//   // Low-cost lighting normalization for tough frames.
// // Keeps quantized input (uint8) but spreads contrast a bit in dark/bright conditions.
//   img.Image _lightNormalize(img.Image im) {
//     final qm = _qualityMetrics(im);
//     final mean = qm['meanLuma'] ?? 128.0;
//     _lastSharpness = qm['sobelEnergy'];
//     // Slight gamma & contrast nudges only at extremes
//     if (mean < 55) {
//       return img.adjustColor(im, gamma: 1.10, contrast: 0.05);
//     } else if (mean > 200) {
//       return img.adjustColor(im, gamma: 0.90, contrast: -0.05);
//     }
//     return im;
//   }
//
//   // ---------- aligned live embedding (uses _faceDetector with landmarks) ----------
//   Future<({List<double> emb, List<double>? shape})?> _getAlignedLiveEmbeddingFromXFile(XFile xf) async {
//     io.File? tmp;
//     try {
//       final bytes = await xf.readAsBytes();
//       final original = _decodeOriented(bytes);
//       if (original == null) return null;
//
//       // 🔧 Write oriented pixels for detection with landmarks
//       final orientedJpeg = Uint8List.fromList(img.encodeJpg(original, quality: 95));
//       final dir = await getTemporaryDirectory();
//       tmp = io.File('${dir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tmp.writeAsBytes(orientedJpeg, flush: true);
//
//       final input = InputImage.fromFilePath(tmp.path);
//       final faces = await _faceDetector.processImage(input); // accurate + landmarks
//       if (faces.isEmpty) return null;
//
//       faces.sort((a, b) {
//         final aa = a.boundingBox.width * a.boundingBox.height;
//         final bb = b.boundingBox.width * b.boundingBox.height;
//         return bb.compareTo(aa);
//       });
//       final face = faces.first;
//       if (!_passesQuality(face, imageW: original.width, imageH: original.height)) return null;
//
//       final crop = _cropFaceWithMargin(original, face, margin: 0.22);
//       final aligned = _alignByEyesIfAvailable(crop, face);
//
//       final qm = _qualityMetrics(aligned);
//       _lastSharpness = qm['sobelEnergy'];
//       _lastBoxW = face.boundingBox.width;
//       _lastBoxH = face.boundingBox.height;
//
//       final emb = _getEmbeddingFromImage(aligned);
//       final shp = _shapeDescriptor(face);
//       return (emb: emb, shape: shp);
//     } catch (e) {
//       debugPrint('❌ _getAlignedLiveEmbeddingFromXFile error: $e');
//       return null;
//     } finally {
//       await tmp?.delete();
//     }
//   }
//
//
//
//   double _shapeDistance(List<double> a, List<double> b) {
//     double s = 0.0;
//     for (int i = 0; i < a.length; i++) { final d = a[i] - b[i]; s += d * d; }
//     return sqrt(s);
//   }
//
//
//   FaceRecognitionService() {
//     _loadModel();
//   }
//
//
//   Future<void> _loadModel() async {
//     try {
//       final options = InterpreterOptions()..threads = 4;
//       // (keep your NNAPI/GPU delegate code if you had it)
//       _interpreter = await Interpreter.fromAsset('assets/facenet.tflite', options: options);
//
//       // warmup
//       final warmIn  = List.filled(1 * 160 * 160 * 3, 0).reshape([1,160,160,3]);
//       final warmOut = List.filled(1 * 512, 0).reshape([1,512]);
//       _interpreter.run(warmIn, warmOut);
//
//       if (!_modelReady.isCompleted) _modelReady.complete(true);
//     } catch (e) {
//       if (!_modelReady.isCompleted) _modelReady.completeError(e);
//       debugPrint('❌ Failed to load FaceNet model: $e');
//     }
//   }
//
//   /// Loads the TFLite model from assets.older
//   // Future<void> _loadModel() async {
//   //   try {
//   //     final options = InterpreterOptions()
//   //       ..threads = 4
//   //       ..useNnApiForAndroid = true; // NNAPI when available
//   //
//   //     // Optional GPU delegate (silently ignored if not available)
//   //     try {
//   //       final gpuDelegateV2 = GpuDelegateV2();
//   //       options.addDelegate(gpuDelegateV2);
//   //     } catch (_) {}
//   //
//   //     _interpreter = await Interpreter.fromAsset('assets/facenet.tflite', options: options);
//   //
//   //     // Warm-up to avoid first-inference stall
//   //     final warmIn = List.filled(1 * 160 * 160 * 3, 0).reshape([1, 160, 160, 3]);
//   //     final warmOut = List.filled(1 * 512, 0).reshape([1, 512]);
//   //     _interpreter.run(warmIn, warmOut);
//   //
//   //     debugPrint('✅ FaceNet model loaded + warmed.');
//   //   } catch (e) {
//   //     debugPrint('❌ Failed to load FaceNet model: $e');
//   //   }
//   // }
//
//   // Future<void> _loadModel() async {
//   //   try {
//   //     _interpreter = await Interpreter.fromAsset('assets/facenet.tflite');
//   //     debugPrint('✅ FaceNet model loaded successfully.');
//   //   } catch (e) {
//   //     debugPrint('❌ Failed to load FaceNet model: $e');
//   //   }
//   // }
//   List<double>? _sample(List<double>? v, [int k = 16]) {
//     if (v == null) return null;
//     if (v.length <= k) return List<double>.from(v);
//     return v.sublist(0, k);
//   }
//
// // Public wrapper so UI code can trigger a punch log with op type
//   Future<void> logPunchDecision(String op, {String? employeeId}) async {
//     await _logEvent({
//       'event': 'punch',
//       'op': op,                                  // e.g., IN / OUT (or your enum string)
//       'employeeId': employeeId ?? _lastBestId,   // who did we punch for
//       'd1': _lastD1,
//       'd2': _lastD2,
//       'delta': (_lastD1 != null && _lastD2 != null) ? (_lastD2! - _lastD1!) : null,
//       'liveEmbLen': _lastLiveEmb?.length,
//       'bestEmbLen': _lastBestEmb?.length,
//       'liveEmbSample': _sample(_lastLiveEmb),    // first 16 dims
//       'bestEmbSample': _sample(_lastBestEmb),
//       'note': _logFullEmbeddings ? 'full_embeddings_included' : 'samples_only',
//       'liveEmbedding': _logFullEmbeddings ? _lastLiveEmb : null,
//       'bestEmbedding': _logFullEmbeddings ? _lastBestEmb : null,
//     });
//   }
//
//   Future<String?> getPHashForRegistration(String base64Image) async {
//     try {
//       final cleaned = base64Image.split(',').last.trim();
//       final bytes = base64Decode(base64.normalize(cleaned));
//       // final original = img.decodeImage(bytes);
//       final original = _decodeOriented(bytes);
//       if (original == null) return null;
//
//       // Use ML Kit detector you already configured
//       final tempDir = await getTemporaryDirectory();
//       final tmp = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tmp.writeAsBytes(bytes, flush: true);
//       final input = InputImage.fromFilePath(tmp.path);
//       final faces = await _faceDetector.processImage(input);
//       await tmp.delete();
//
//       if (faces.isEmpty) return null;
//       // pick largest face
//       faces.sort((a, b) {
//         final aa = a.boundingBox.width * a.boundingBox.height;
//         final bb = b.boundingBox.width * b.boundingBox.height;
//         return bb.compareTo(aa);
//       });
//       final face = faces.first;
//       if (!_passesQuality(face)) return null;
//
//
//       final cropped = _cropFaceWithMargin(original, face, margin: 0.25);
//       final aligned = _alignByEyesIfAvailable(cropped, face);
//       return _aHashHex(aligned);
//     } catch (_) {
//       return null;
//     }
//   }
//   String _aHashHex(img.Image face) {
//     final g = img.grayscale(face);
//     final small = img.copyResize(g, width: 8, height: 8);
//     int sum = 0;
//     final vals = List<int>.filled(64, 0);
//     int k = 0;
//     for (int y = 0; y < 8; y++) {
//       for (int x = 0; x < 8; x++) {
//         final lum = img.getLuminance(small.getPixel(x, y)).toInt(); // ← cast
//         vals[k++] = lum;
//         sum += lum;
//       }
//     }
//     final avg = sum ~/ 64;
//
//     int hi = 0, lo = 0;
//     for (int i = 0; i < 64; i++) {
//       if (vals[i] >= avg) {
//         if (i < 32) {
//           hi |= (1 << (31 - i));
//         } else {
//           lo |= (1 << (63 - i));
//         }
//       }
//     }
//     final hiHex = hi.toRadixString(16).padLeft(8, '0');
//     final loHex = lo.toRadixString(16).padLeft(8, '0');
//     return '$hiHex$loHex';
//   }
//
//
//   // int _hammingHex(String a, String b) {
//   //   final ai = BigInt.parse(a, radix: 16);
//   //   final bi = BigInt.parse(b, radix: 16);
//   //   BigInt x = ai ^ bi;
//   //   int c = 0;
//   //   while (x != BigInt.zero) { x &= (x - BigInt.one); c++; }
//   //   return c;
//   // }
//
//
// // public wrapper to your internal logger
//   Future<void> logAudit(String event, Map<String, dynamic> extra) async {
//     await _logEvent({'event': event, ...extra});
//   }
//
//
//   // L2 normalization helper
//   List<double> _l2Normalize(List<double> v) {
//     double sum = 0.0;
//     for (final x in v) {
//       sum += x * x;
//     }
//     final norm = sqrt(sum);
//     if (norm < 1e-12) return v; // avoid div-by-zero; returns as-is
//     return List<double>.generate(v.length, (i) => v[i] / norm);
//   }
//
//   /// **Use this during employee registration.**
//   /// Takes a Base64 image string, computes the face embedding, and returns it.
//   // Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
//   //   try {
//   //     final Uint8List imageBytes = base64Decode(base64.normalize(base64Image));
//   //     return await _processImageBytes(imageBytes);
//   //   } on FormatException catch (e) {
//   //     debugPrint("❌ Invalid Base64 string provided: ${e.message}");
//   //     return null;
//   //   } catch (e) {
//   //     debugPrint("❌ An error occurred during registration embedding: $e");
//   //     return null;
//   //   }
//   // }
//
//   /// ✅ Now returns an L2-normalized embedding.
//   Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
//     await _ensureReady();
//     try {
//       // Handle both plain base64 and data URIs like "data:image/jpeg;base64,..."
//       final cleaned = base64Image.split(',').last.trim();
//
//       final Uint8List imageBytes = base64Decode(base64.normalize(cleaned));
//
//       // Your existing face pipeline should: decode -> detect -> ALIGN -> preprocess -> infer
//       final List<double>? rawEmbedding = await _processImageBytes(imageBytes);
//       if (rawEmbedding == null) return null;
//
//       // ✅ enforce L2 here as the last step
//       return _l2Normalize(rawEmbedding);
//     } on FormatException catch (e) {
//       debugPrint("❌ Invalid Base64 string provided: ${e.message}");
//       return null;
//     } catch (e) {
//       debugPrint("❌ An error occurred during registration embedding: $e");
//       return null;
//     }
//   }
//
//
//   /// **Use this for live face recognition.**
//   /// Takes a live image from the camera and computes the face embedding.
//   Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
//     await _ensureReady();
//     io.File? tmp;
//     try {
//       // Read + bake EXIF to get upright pixels
//       final bytes = await imageFile.readAsBytes();
//       final original = _decodeOriented(bytes);
//       if (original == null) return null;
//
//       // 🔧 Write oriented pixels & detect on that
//       final orientedJpeg = Uint8List.fromList(img.encodeJpg(original, quality: 95));
//       final dir = await getTemporaryDirectory();
//       tmp = io.File('${dir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tmp.writeAsBytes(orientedJpeg, flush: true);
//
//       final input = InputImage.fromFilePath(tmp.path);
//       // Fast first, then accurate if needed
//       List<Face> faces = await _liveDetector.processImage(input);
//       if (faces.isEmpty) {
//         faces = await _faceDetector.processImage(input);
//         if (faces.isEmpty) return null;
//       }
//
//       faces.sort((a, b) {
//         final aa = a.boundingBox.width * a.boundingBox.height;
//         final bb = b.boundingBox.width * b.boundingBox.height;
//         return bb.compareTo(aa);
//       });
//       final face = faces.first;
//
//       if (!_passesQuality(face, imageW: original.width, imageH: original.height)) {
//         await _logEvent({
//           'event': 'detect',
//           'reason': 'FACE_TOO_SMALL',
//           'boxW': face.boundingBox.width,
//           'boxH': face.boundingBox.height,
//         });
//         return null;
//       }
//
//       // Crop on the SAME oriented pixels
//       final crop = _cropFaceWithMargin(original, face, margin: 0.20);
//       final qm = _qualityMetrics(crop);
//       _lastSharpness = qm['sobelEnergy'];
//       _lastBoxW = face.boundingBox.width;
//       _lastBoxH = face.boundingBox.height;
//
//       return _getEmbeddingFromImage(crop);
//     } catch (e) {
//       debugPrint('❌ getEmbeddingFromLiveImage error: $e');
//       return null;
//     } finally {
//       await tmp?.delete();
//     }
//   }
//
//
//   // Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
//   //   try {
//   //     final imageBytes = await imageFile.readAsBytes();
//   //     return await _processImageBytes(imageBytes);
//   //   } catch (e) {
//   //     debugPrint("❌ An error occurred during live image embedding: $e");
//   //     return null;
//   //   }
//   // }
//
//   /// Centralized function to process image bytes (from Base64 or XFile).
//   Future<List<double>?> _processImageBytes(Uint8List imageBytes) async {
//     io.File? tempFile;
//     try {
//       // Bake EXIF so our pixels are upright
//       final originalImage = _decodeOriented(imageBytes);
//       if (originalImage == null) {
//         debugPrint('❌ Failed to decode image bytes for cropping.');
//         return null;
//       }
//
//       // 🔧 Write the *oriented* pixels to a temp JPEG
//       final orientedJpeg = Uint8List.fromList(img.encodeJpg(originalImage, quality: 95));
//       final tempDir = await getTemporaryDirectory();
//       tempFile = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tempFile.writeAsBytes(orientedJpeg, flush: true);
//
//       // Detect on the same oriented JPEG we’ll crop from
//       final inputImage = InputImage.fromFilePath(tempFile.path);
//       // NEW
//       List<Face> faces = await _faceDetector.processImage(inputImage);
//       if (faces.isEmpty) {
//         // try the fast detector as a second pass
//         faces = await _liveDetector.processImage(inputImage);
//         if (faces.isEmpty) {
//           debugPrint('No face detected (accurate + fast).');
//           return null;
//         }
//       }
//
//       faces.sort((a, b) {
//         final aSize = a.boundingBox.width * a.boundingBox.height;
//         final bSize = b.boundingBox.width * b.boundingBox.height;
//         return bSize.compareTo(aSize);
//       });
//       final selectedFace = faces.first;
//
//       if (!_passesQuality(selectedFace, imageW: originalImage.width, imageH: originalImage.height)) {
//         await _logEvent({
//           'event': 'detect',
//           'reason': 'FACE_TOO_SMALL',
//           'boxW': selectedFace.boundingBox.width,
//           'boxH': selectedFace.boundingBox.height,
//         });
//         return null;
//       }
//
//       final cropped = _cropFaceWithMargin(originalImage, selectedFace, margin: 0.25);
//       final aligned = _alignByEyesIfAvailable(cropped, selectedFace);
//
//       final qm = _qualityMetrics(aligned);
//       await _logEvent({
//         'event': 'quality',
//         'meanLuma': qm['meanLuma'],
//         'sobel': qm['sobelEnergy'],
//         'boxW': selectedFace.boundingBox.width,
//         'boxH': selectedFace.boundingBox.height,
//       });
//
//       // NEW
//       final prepped = _lightNormalize(aligned);
//       return _getEmbeddingFromImage(prepped);
//     } catch (e) {
//       debugPrint("❌ Error in _processImageBytes: $e");
//       return null;
//     } finally {
//       await tempFile?.delete();
//     }
//   }
//
//   Map<String, double> _qualityMetrics(img.Image face) {
//     // grayscale + 64x64 downsample for cheap metrics
//     final g = img.grayscale(face);
//     final s = img.copyResize(g, width: 64, height: 64);
//
//     // brightness (mean luminance)
//     double sum = 0;
//     for (int y = 0; y < s.height; y++) {
//       for (int x = 0; x < s.width; x++) {
//         sum += img.getLuminance(s.getPixel(x, y));
//       }
//     }
//     final mean = sum / (s.width * s.height);
//
//     // very light blur proxy: Sobel energy (larger = sharper)
//     double energy = 0;
//     const sx = [
//       [-1, 0, 1],
//       [-2, 0, 2],
//       [-1, 0, 1],
//     ];
//     const sy = [
//       [-1, -2, -1],
//       [ 0,  0,  0],
//       [ 1,  2,  1],
//     ];
//     for (int y = 1; y < s.height - 1; y++) {
//       for (int x = 1; x < s.width - 1; x++) {
//         double gx = 0, gy = 0;
//         for (int j = -1; j <= 1; j++) {
//           for (int i = -1; i <= 1; i++) {
//             final lum = img.getLuminance(s.getPixel(x + i, y + j)).toDouble();
//             gx += sx[j + 1][i + 1] * lum;
//             gy += sy[j + 1][i + 1] * lum;
//           }
//         }
//         energy += (gx * gx + gy * gy);
//       }
//     }
//     energy /= ((s.width - 2) * (s.height - 2));
//     return {'meanLuma': mean, 'sobelEnergy': energy};
//   }
//   Future<io.File> _logFile() async {
//     final dir = await getApplicationDocumentsDirectory();
//     return io.File('${dir.path}/face_debug.log');
//   }
//
//   Future<void> _logEvent(Map<String, dynamic> m) async {
//     try {
//       final f = await _logFile();
//       final rec = {
//         'ts': DateTime.now().toIso8601String(),
//         ...m,
//       };
//       await f.writeAsString('${jsonEncode(rec)}\n', mode: io.FileMode.append, flush: true);
//       // simple rotate if >512KB
//       if (await f.length() > 512 * 1024) {
//         final rotated = io.File('${f.path}.1');
//         if (await rotated.exists()) await rotated.delete();
//         await f.rename(rotated.path);
//       }
//     } catch (_) { /* ignore */ }
//   }
//
//
//   img.Image _cropFaceWithMargin(img.Image original, Face face, {double margin = 0.25}) {
//     final bb = face.boundingBox;
//     final cx = bb.left + bb.width / 2;
//     final cy = bb.top + bb.height / 2;
//     final size = max(bb.width, bb.height) * (1.0 + margin);
//
//     final int left   = max(0, (cx - size / 2).floor());
//     final int top    = max(0, (cy - size / 2).floor());
//     final int right  = min(original.width,  (cx + size / 2).ceil()).toInt();
//     final int bottom = min(original.height, (cy + size / 2).ceil()).toInt();
//
//     final int w = max(1, right - left).toInt();
//     final int h = max(1, bottom - top).toInt();
//     return img.copyCrop(original, x: left, y: top, width: w, height: h);
//   }
//   img.Image _alignByEyesIfAvailable(img.Image faceCrop, Face face) {
//     final leftEye = face.landmarks[FaceLandmarkType.leftEye]?.position;
//     final rightEye = face.landmarks[FaceLandmarkType.rightEye]?.position;
//     if (leftEye == null || rightEye == null) return faceCrop; // no landmarks → skip
//
//     // rotate so the eyes are level
//     final dy = rightEye.y - leftEye.y;
//     final dx = rightEye.x - leftEye.x;
//     final angleRad = atan2(dy, dx);
//     final angleDeg = -angleRad * 180 / pi; // negative to un-tilt
//     return img.copyRotate(faceCrop, angle: angleDeg);
//   }
//
//   // bool _passesQuality(Face face) {
//   //   // Temporarily relaxed; raise to 112px after you calibrate thresholds.
//   //   return face.boundingBox.width >= 80 && face.boundingBox.height >= 80;
//   // }
//
//   bool _passesQuality(Face face, {int? imageW, int? imageH, int minAbs = 60, double minFrac = 0.15}) {
//     final w = face.boundingBox.width;
//     final h = face.boundingBox.height;
//     final okAbs = (w >= minAbs) && (h >= minAbs);
//
//     if (imageW != null && imageH != null) {
//       final m = math.min(imageW, imageH).toDouble();
//       final okFrac = (w >= m * minFrac) && (h >= m * minFrac);
//       return okAbs || okFrac;
//     }
//     return okAbs;
//   }
//
//   // bool _passesQuality(
//   //     Face face, {
//   //       int? imageW,
//   //       int? imageH,
//   //       int minAbs = 60,         // <-- Tweak this (e.g., from 48 to 60 or higher)
//   //       double minFrac = 0.15,   // <-- Tweak this (e.g., from 0.12 to 0.15 or higher)
//   //     }) {
//   //   final w = face.boundingBox.width;
//   //   final h = face.boundingBox.height;
//   //
//   //   final okAbs = (w >= minAbs) && (h >= minAbs);
//   //
//   //   if (imageW != null && imageH != null) {
//   //     final m = min(imageW, imageH).toDouble();
//   //     final okFrac = (w >= m * minFrac) && (h >= m * minFrac);
//   //     return okAbs || okFrac;
//   //   }
//   //   return okAbs;
//   // }
//
//
//
//
//   /// Crops the face from the full image.
//   img.Image _cropFace(img.Image originalImage, Face face) {
//     final boundingBox = face.boundingBox;
//     return img.copyCrop(
//       originalImage,
//       x: boundingBox.left.toInt(),
//       y: boundingBox.top.toInt(),
//       width: boundingBox.width.toInt(),
//       height: boundingBox.height.toInt(),
//     );
//   }
//
//   /// Prepares the cropped face and runs the TFLite model to get the embedding.
//   // List<double> _getEmbeddingFromImage(img.Image image) {
//   //   final resizedImage = img.copyResize(image, width: 160, height: 160);
//   //
//   //   // Create a Uint8List to hold the raw pixel data for the quantized model.
//   //   final imageBytes = Uint8List(1 * 160 * 160 * 3);
//   //   int pixelIndex = 0;
//   //
//   //   // Iterate over the pixels and store their raw RGB integer values.
//   //   for (int y = 0; y < 160; y++) {
//   //     for (int x = 0; x < 160; x++) {
//   //       final pixel = resizedImage.getPixel(x, y);
//   //       imageBytes[pixelIndex++] = pixel.r.toInt();
//   //       imageBytes[pixelIndex++] = pixel.g.toInt();
//   //       imageBytes[pixelIndex++] = pixel.b.toInt();
//   //     }
//   //   }
//   //
//   //   // Reshape the flat list into the format [1, 160, 160, 3] required by the model.
//   //   final input = imageBytes.reshape([1, 160, 160, 3]);
//   //
//   //   // The output buffer should also be integer-based for a quantized model.
//   //   final output = List.filled(1 * 512, 0).reshape([1, 512]);
//   //
//   //   _interpreter.run(input, output);
//   //
//   //   // Convert the integer output from the model to a List<double> for distance calculation.
//   //   final embedding = (output[0] as List<int>).map((e) => e.toDouble()).toList();
//   //
//   //   return embedding;
//   // }
//
//   /// Prepares the cropped face and runs the TFLite model to get the embedding.
//   // List<double> _getEmbeddingFromImage(img.Image image) {
//   //   // keep your current resize
//   //   final resizedImage = img.copyResize(image, width: 160, height: 160);
//   //
//   //   // keep your current uint8 input construction (works with your quantized model)
//   //   final imageBytes = Uint8List(1 * 160 * 160 * 3);
//   //   int pixelIndex = 0;
//   //   for (int y = 0; y < 160; y++) {
//   //     for (int x = 0; x < 160; x++) {
//   //       final pixel = resizedImage.getPixel(x, y);
//   //       imageBytes[pixelIndex++] = pixel.r.toInt();
//   //       imageBytes[pixelIndex++] = pixel.g.toInt();
//   //       imageBytes[pixelIndex++] = pixel.b.toInt();
//   //     }
//   //   }
//   //
//   //   // run the model
//   //   final input = imageBytes.reshape([1, 160, 160, 3]);
//   //   final output = List.filled(1 * 512, 0).reshape([1, 512]); // your current output shape
//   //   _interpreter.run(input, output);
//   //
//   //   // convert to doubles
//   //   final raw = (output[0] as List<int>).map((e) => e.toDouble()).toList();
//   //
//   //   // ✅ L2-normalize here
//   //   final normalized = _l2Normalize(raw);
//   //   return normalized;
//   // }
//
//
//   ///
//   // replace your _getEmbeddingFromImage with this
//   List<double> _getEmbeddingFromImage(img.Image image) {
//     // 1) Resize to 160x160
//     final resized = img.copyResize(image, width: 160, height: 160);
//
//     // 2) Build uint8 input tensor (RGB)
//     final inputBytes = Uint8List(1 * 160 * 160 * 3);
//     int p = 0;
//     for (int y = 0; y < 160; y++) {
//       for (int x = 0; x < 160; x++) {
//         final px = resized.getPixel(x, y);
//         inputBytes[p++] = px.r.toInt();
//         inputBytes[p++] = px.g.toInt();
//         inputBytes[p++] = px.b.toInt();
//       }
//     }
//     final input = inputBytes.reshape([1, 160, 160, 3]);
//
//     // 3) Prepare output buffer based on actual tensor type (works across versions)
//     final t = _interpreter.getOutputTensor(0);
//     final shape = t.shape;                 // e.g. [1, 512]
//     final elems = shape.reduce((a, b) => a * b);
//     final typeStr = t.type.toString();     // e.g. "TfLiteType.float32" / ".int8" / ".uint8"
//
//     Object outBuf;
//     if (typeStr.contains('float32')) {
//       outBuf = List<double>.filled(elems, 0.0).reshape(shape);
//     } else if (typeStr.contains('int8')) {
//       outBuf = Int8List(elems).reshape(shape);
//     } else if (typeStr.contains('uint8')) {
//       outBuf = Uint8List(elems).reshape(shape);
//     } else {
//       // Fallback: treat as float
//       outBuf = List<double>.filled(elems, 0.0).reshape(shape);
//     }
//
//     // 4) Run model
//     _interpreter.run(input, outBuf);
//
//     // 5) Read & de-quantize if needed, also fill legacy space
//     List<double> floats;
//     if (typeStr.contains('float32')) {
//       floats = (outBuf as List).first.cast<num>().map((e) => e.toDouble()).toList();
//       _liveLegacyEmb = _l2Normalize(List<double>.from(floats)); // harmless fallback
//     } else {
//       final scale = t.params.scale;
//       final zp    = t.params.zeroPoint;
//       if (typeStr.contains('int8')) {
//         final q = (outBuf as List).first as Int8List;
//         floats = List<double>.generate(q.length, (i) => scale * (q[i] - zp));
//         final legacy = List<double>.generate(q.length, (i) => q[i].toDouble().abs());
//         _liveLegacyEmb = _l2Normalize(legacy);
//       } else {
//         final q = (outBuf as List).first as Uint8List;
//         floats = List<double>.generate(q.length, (i) => scale * (q[i] - zp));
//         final legacy = List<double>.generate(q.length, (i) => q[i].toDouble());
//         _liveLegacyEmb = _l2Normalize(legacy);
//       }
//     }
//
//     _liveFloatEmb = _l2Normalize(floats);
//     return _liveFloatEmb!;
//   }
//
//
//   ///
//
//
//   // List<double> _getEmbeddingFromImage(img.Image image) {
//   //   // 1) Resize to 160x160
//   //   final resized = img.copyResize(image, width: 160, height: 160);
//   //
//   //   // 2) Build uint8 input tensor (RGB)
//   //   final inputBytes = Uint8List(1 * 160 * 160 * 3);
//   //   int p = 0;
//   //   for (int y = 0; y < 160; y++) {
//   //     for (int x = 0; x < 160; x++) {
//   //       final px = resized.getPixel(x, y);
//   //       inputBytes[p++] = px.r.toInt();
//   //       inputBytes[p++] = px.g.toInt();
//   //       inputBytes[p++] = px.b.toInt();
//   //     }
//   //   }
//   //   final input = inputBytes.reshape([1, 160, 160, 3]);
//   //
//   //   // 3) Run model into INT buffer (quantized model)
//   //   final out = List.filled(1 * 512, 0).reshape([1, 512]);
//   //   _interpreter.run(input, out);
//   //   final q = (out[0] as List<int>);
//   //
//   //   // 4) Legacy live embedding (matches *old* DB rows)
//   //   final legacy = List<double>.generate(q.length, (i) => q[i].toDouble());
//   //   _liveLegacyEmb = _l2Normalize(legacy);
//   //
//   //   // 5) Proper de-quantized live embedding (matches *new* rows)
//   //   final t = _interpreter.getOutputTensor(0);
//   //   final scale = t.params.scale;     // float
//   //   final zp    = t.params.zeroPoint; // int
//   //   List<double> floats;
//   //   if (scale != 0.0) {
//   //     floats = List<double>.generate(q.length, (i) => scale * (q[i] - zp));
//   //   } else {
//   //     // non-quantized fallback
//   //     floats = (out[0] as List).map((e) => (e as num).toDouble()).toList();
//   //   }
//   //   _liveFloatEmb = _l2Normalize(floats);
//   //
//   //   // return modern float embedding by default
//   //   return _liveFloatEmb!;
//   // }
//   bool _looksLegacy(List<double> v) {
//     // Legacy int-L2 rows are non-negative and capped ~<=0.14 (because 255/L2norm)
//     double maxv = double.negativeInfinity, minv = double.infinity;
//     for (final x in v) { if (x > maxv) maxv = x; if (x < minv) minv = x; }
//     return minv >= 0.0 && maxv <= 0.20; // generous cap
//   }
//
//
//
//
//
//   /// Recognizes a face by comparing its live embedding to stored profiles.
//   /// Recognizes a face by comparing its live embedding to stored profiles (L2 + margin).
//   // Future<String?> recognizeFace(XFile liveImage) async {
//   //   final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
//   //   if (liveEmbedding == null) {
//   //     await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
//   //     return null;
//   //   }
//   //   _lastLiveEmb = liveEmbedding; // <-- store the live embedding for later punch log
//   //   final dim = liveEmbedding.length;
//   //   debugPrint('[LIVE] embedding dim=$dim');
//   //
//   //   final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
//   //   if (allProfiles.isEmpty) {
//   //     debugPrint('Database is empty. No faces to compare against.');
//   //     await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
//   //     return null;
//   //   }
//   //
//   //   // Tunables (start generous; tighten with logs)
//   //   final double threshold = (dim >= 512) ? 1.20 : 1.0;
//   //   const double marginAbs = 0.10;   // absolute separation
//   //   const double ratioThr  = 0.96;  // ratio separation (d1/d2 <= 0.985)
//   //
//   //   String? bestId;
//   //   double d1 = double.infinity, d2 = double.infinity;
//   //   int good = 0, bad = 0;
//   //
//   //   for (final profile in allProfiles) {
//   //     final raw = profile['image_data'];
//   //     if (raw is! String || raw.isEmpty) { bad++; continue; }
//   //     try {
//   //       final parsed = jsonDecode(raw);
//   //
//   //       final Iterable<List<double>> vectors =
//   //       (parsed is List && parsed.isNotEmpty && parsed.first is List)
//   //           ? (parsed as List).map<List<double>>(
//   //               (v) => (v as List).map((e) => (e as num).toDouble()).toList())
//   //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
//   //
//   //       for (final vec in vectors) {
//   //         if (vec.length != dim) { bad++; continue; }
//   //         final stored = _l2Normalize(vec);
//   //         final d = _euclideanDistance(liveEmbedding, stored);
//   //         if (d < d1) {
//   //           d2 = d1; d1 = d;
//   //           bestId = profile['employee_id'] as String?;
//   //           _lastBestEmb = stored;       // <-- add this line
//   //         } else if (d < d2) {
//   //           d2 = d;
//   //         }
//   //         good++;
//   //       }
//   //     } catch (_) { bad++; }
//   //   }
//   //
//   //   if (bestId == null) {
//   //     await _logEvent({'event': 'recognize', 'reason': 'NO_VALID_VECTORS', 'good': good, 'bad': bad});
//   //     return null;
//   //   }
//   //
//   //   final bool passThr = d1 < threshold;
//   //   final bool passSep = ((d2 - d1) >= marginAbs) || (d2 > 0 && (d1 / d2) <= ratioThr);
//   //
//   //   debugPrint('[MATCH] best=$bestId d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} '
//   //       'Δ=${(d2-d1).toStringAsFixed(3)} thr=$threshold abs=$marginAbs ratio=$ratioThr '
//   //       'passThr=$passThr passSep=$passSep good=$good bad=$bad');
//   //
//   //   _lastBestId = bestId;
//   //   _lastD1 = d1;
//   //   _lastD2 = d2;
//   //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
//   //
//   //
//   //   if (passThr && passSep) {
//   //     await _logEvent({
//   //       'event': 'recognize',
//   //       'decision': 'ACCEPT',
//   //       'bestId': bestId,
//   //       'd1': d1,
//   //       'd2': d2,
//   //       'delta': d2 - d1,
//   //       'ratio': (d2 > 0 ? d1 / d2 : 1.0),
//   //       'good': good,
//   //       'bad': bad,
//   //     });
//   //     return bestId;
//   //   }
//   //
//   //   _lastBestId = bestId;
//   //   _lastD1 = d1;
//   //   _lastD2 = d2;
//   //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
//   //
//   //
//   //   await _logEvent({
//   //     'event': 'recognize',
//   //     'decision': 'REJECT',
//   //     'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
//   //     'bestId': bestId,
//   //     'd1': d1,
//   //     'd2': d2,
//   //     'delta': d2 - d1,
//   //     'ratio': (d2 > 0 ? d1 / d2 : 1.0),
//   //     'good': good,
//   //     'bad': bad,
//   //   });
//   //   return null;
//   // }
//
//   Future<String?> recognizeFace(XFile liveImage) async {
//     await _ensureReady();
//     lastDecisionIsStrong = false;
//
//     // 1) Live embeddings (sets _liveFloatEmb and _liveLegacyEmb internally)
//     final liveFloat = await getEmbeddingFromLiveImage(liveImage);
//     if (liveFloat == null || _liveLegacyEmb == null || _liveFloatEmb == null) {
//       await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
//       return null;
//     }
//     final dim = liveFloat.length;
//     debugPrint('[LIVE] embedding dim=$dim');
//
//     // 2) Gallery (employeeId -> list of templates) built from DB
//     final gallery = await _ensureGallery();
//     if (gallery.isEmpty) {
//       await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
//       return null;
//     }
//
//     // 3) Top-2 *employees* (not vectors)
//     final r = _top2ByEmployee(
//       gallery,
//       _liveFloatEmb!,
//       _liveLegacyEmb,
//       _looksLegacy,
//       _euclideanDistance,
//     );
//     if (r.id1 == null) {
//       await _logEvent({'event': 'recognize', 'reason': 'NO_VALID_VECTORS'});
//       return null;
//     }
//
//     // 4) Decide space & base thresholds
//     double thrFloat = 1.12;   // baseline for float space
//     double thrLegacy = 0.40;  // baseline for legacy space
//     double sepAbs = 0.020;    // min absolute gap
//     double sepRatio = 0.985;  // d1/d2 must be <= this
//
//     // Heuristic: legacy d1 ~ 0.3; float d1 ~ 1.x
//     final bool seemsLegacy = r.d1 < 0.75;
//     double thr = seemsLegacy ? thrLegacy : thrFloat;
//
//     // 5) Adaptive nudges by quality (re-use your metrics)
//     final sharp = _lastSharpness ?? 0.0;
//     final boxMin = (_lastBoxW != null && _lastBoxH != null) ? min(_lastBoxW!, _lastBoxH!) : 0.0;
//
//     if (!seemsLegacy) {
//       // float space
//       if (sharp > 1200 && boxMin > 130) { thr = 1.15; sepAbs = 0.020; sepRatio = 0.985; }
//       if (sharp < 500  || boxMin <  90) { thr = 1.00; sepAbs = 0.030; sepRatio = 0.980; }
//     } else {
//       // legacy space
//       if (sharp > 1200 && boxMin > 130) { thr = 0.40; sepAbs = 0.020; sepRatio = 0.990; }
//       if (sharp < 500  || boxMin <  90) { thr = 0.36; sepAbs = 0.030; sepRatio = 0.985; }
//     }
//
//     // 6) Decide by threshold + separation vs NEXT-BEST EMPLOYEE
//     final passThr = r.d1 < thr;
//     final passSep = (r.id2 != null) && ( ((r.d2 - r.d1) >= sepAbs) || (r.d2 > 0 && (r.d1 / r.d2) <= sepRatio) );
//
//     // Telemetry
//     _lastBestId = r.id1;
//     _lastD1 = r.d1;
//     _lastD2 = r.d2;
//     _lastLiveEmb = seemsLegacy ? _liveLegacyEmb : _liveFloatEmb;
//     _lastBestEmb = null; // (optional) set if you also track/store best vector
//
//     if (passThr && passSep) {
//       lastDecisionIsStrong = (r.d1 < thr * 0.85) && ((r.d2 - r.d1) > sepAbs * 1.3);
//       await _logEvent({
//         'event':'recognize','decision':'ACCEPT',
//         'bestId': r.id1, 'd1': r.d1, 'd2': r.d2, 'delta': r.d2 - r.d1,
//         'ratio': (r.d2 > 0 ? r.d1 / r.d2 : 1.0)
//       });
//       return r.id1;
//     }
//
//     // 7) Borderline? Try your existing landmark-aligned refinement
//     final bool borderline = (passThr && !passSep) || (!passThr && r.d1 < thr * 1.10);
//     if (borderline) {
//       final aligned = await _getAlignedLiveEmbeddingFromXFile(liveImage);
//       if (aligned != null && _liveFloatEmb != null) {
//         // Re-run top-2 by employee with the aligned embedding (fields are already updated by _getEmbeddingFromImage)
//         final r2 = _top2ByEmployee(
//           gallery,
//           _liveFloatEmb!, _liveLegacyEmb,
//           _looksLegacy, _euclideanDistance,
//         );
//
//         if (r2.id1 != null) {
//           double thr2 = seemsLegacy ? max(0.36, thr - 0.02) : max(1.00, thr - 0.05);
//           final pass2 = (r2.d1 < thr2) && (r2.id2 != null) && ((r2.d2 - r2.d1) >= sepAbs);
//
//           if (pass2) {
//             _lastBestId = r2.id1; _lastD1 = r2.d1; _lastD2 = r2.d2; _lastLiveEmb = _liveFloatEmb;
//             lastDecisionIsStrong = lastDecisionIsStrong || (r2.d1 < thr2 * 0.88 && (r2.d2 - r2.d1) > sepAbs * 1.3);
//             await _logEvent({
//               'event':'recognize','decision':'ACCEPT_REFINED',
//               'bestId': r2.id1, 'd1': r2.d1, 'd2': r2.d2, 'delta': r2.d2 - r2.d1
//             });
//             return r2.id1;
//           }
//         }
//       }
//     }
//
//     await _logEvent({
//       'event':'recognize','decision':'REJECT',
//       'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
//       'bestId': r.id1, 'd1': r.d1, 'd2': r.d2,
//       'delta': r.d2 - r.d1, 'ratio': (r.d2 > 0 ? r.d1 / r.d2 : 1.0)
//     });
//     return null;
//   }
//
//   //old
//   // Future<String?> recognizeFace(XFile liveImage) async {
//   //   await _ensureReady();//change
//   //   lastDecisionIsStrong = false; // reset every call
//   //
//   //   final liveFloat = await getEmbeddingFromLiveImage(liveImage);
//   //   if (liveFloat == null || _liveLegacyEmb == null) {
//   //     await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
//   //     return null;
//   //   }
//   //   final dim = liveFloat.length;
//   //   debugPrint('[LIVE] embedding dim=$dim');
//   //
//   //   final rows = await DatabaseService.instance.getAllEmployeeProfiles();
//   //   if (rows.isEmpty) {
//   //     await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
//   //     return null;
//   //   }
//   //
//   //   // ----- Stage 1: your existing float+legacy scoring (unchanged) -----
//   //   String? bestIdF, bestIdL;
//   //   double d1F = double.infinity, d2F = double.infinity;
//   //   double d1L = double.infinity, d2L = double.infinity;
//   //   List<double>? bestEmbF, bestEmbL;
//   //   int good = 0, bad = 0;
//   //
//   //   for (final r in rows) {
//   //     final raw = r['image_data'];
//   //     if (raw is! String || raw.isEmpty) { bad++; continue; }
//   //     try {
//   //       final parsed = jsonDecode(raw);
//   //       final Iterable<List<double>> vectors =
//   //       (parsed is List && parsed.isNotEmpty && parsed.first is List)
//   //           ? (parsed as List).map<List<double>>((v) => (v as List).map((e) => (e as num).toDouble()).toList())
//   //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
//   //
//   //       for (final v in vectors) {
//   //         if (v.length != dim) { bad++; continue; }
//   //         final stored = _l2Normalize(v);
//   //         final isLegacy = _looksLegacy(stored);
//   //
//   //         if (isLegacy) {
//   //           final d = _euclideanDistance(_liveLegacyEmb!, stored);
//   //           if (d < d1L) { d2L = d1L; d1L = d; bestIdL = r['employee_id'] as String?; bestEmbL = stored; }
//   //           else if (d < d2L) { d2L = d; }
//   //         } else {
//   //           final d = _euclideanDistance(liveFloat, stored);
//   //           if (d < d1F) { d2F = d1F; d1F = d; bestIdF = r['employee_id'] as String?; bestEmbF = stored; }
//   //           else if (d < d2F) { d2F = d; }
//   //         }
//   //         good++;
//   //       }
//   //     } catch (_) { bad++; }
//   //   }
//   //
//   //   // pick space by normalized score
//   //   String? bestId; double d1 = double.infinity, d2 = double.infinity;
//   //   double thr, sepAbs, sepRatio; List<double>? bestEmb;
//   //
//   //   final okFloat = d1F.isFinite;
//   //   final okLegacy = d1L.isFinite;
//   //   double scoreF = okFloat ? d1F / 1.10 : double.infinity; // thrFloat ~1.10
//   //   double scoreL = okLegacy ? d1L / 0.40 : double.infinity; // thrLegacy ~0.40
//   //
//   //   if (scoreF <= scoreL) {
//   //     bestId = bestIdF; d1 = d1F; d2 = d2F; bestEmb = bestEmbF;
//   //     // Tweak these values to be more lenient
//   //     thr = 1.15; // Increased from 1.10
//   //     sepAbs = 0.08; // Decreased from 0.10
//   //     sepRatio = 0.94; // Increased from 0.92
//   //   } else {
//   //     bestId = bestIdL; d1 = d1L; d2 = d2L; bestEmb = bestEmbL;
//   //     // Tweak these values for legacy space
//   //     thr = 0.42; // Increased from 0.40
//   //     sepAbs = 0.035; // Decreased from 0.04
//   //     sepRatio = 0.94; // Increased from 0.92
//   //   }
//   //
//   //   if (bestId == null) {
//   //     await _logEvent({'event':'recognize','reason':'NO_VALID_VECTORS','good':good,'bad':bad});
//   //     return null;
//   //   }
//   //
//   //   // adaptive nudges by quality
//   //   final sharp = _lastSharpness ?? 0.0;
//   //   final boxMin = (_lastBoxW != null && _lastBoxH != null) ? min(_lastBoxW!, _lastBoxH!) : 0.0;
//   //   if (thr >= 1.0) { // float space
//   //     if (sharp > 1200 && boxMin > 130) { thr = 1.15; sepAbs = 0.08; sepRatio = 0.93; }
//   //     if (sharp < 500  || boxMin < 90 ) { thr = 1.00; sepAbs = 0.12; sepRatio = 0.90; }
//   //   } else {          // legacy space
//   //     if (sharp > 1200 && boxMin > 130) { thr = 0.40; sepAbs = 0.025; sepRatio = 0.96; }
//   //     if (sharp < 500  || boxMin < 90 ) { thr = 0.36; sepAbs = 0.035; sepRatio = 0.94; }
//   //   }
//   //
//   //   final passThr = d1 < thr;
//   //   final passSep = ((d2 - d1) >= sepAbs) || (d2 > 0 && (d1 / d2) <= sepRatio);
//   //
//   //   _lastLiveEmb = (thr >= 1.0) ? liveFloat : _liveLegacyEmb;
//   //   _lastBestEmb = bestEmb;
//   //   _lastBestId  = bestId;
//   //   _lastD1 = d1; _lastD2 = d2;
//   //
//   //   // mark strong BEFORE any early return (fixes the dead branch)
//   //   if (passThr && passSep && (d1 < thr * 0.82) && ((d2 - d1) > (sepAbs * 1.5))) {
//   //     lastDecisionIsStrong = true;
//   //     // We still fall through to your ACCEPT path below
//   //   }
//   //
//   //   debugPrint('[MATCH] best=$bestId d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} '
//   //       'Δ=${(d2-d1).toStringAsFixed(3)} thr=$thr abs=$sepAbs ratio=$sepRatio '
//   //       'passThr=$passThr passSep=$passSep good=$good bad=${bad}');
//   //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
//   //
//   //   if (passThr && passSep) {
//   //     await _logEvent({'event':'recognize','decision':'ACCEPT','bestId':bestId,'d1':d1,'d2':d2,
//   //       'delta':d2-d1,'ratio': (d2>0? d1/d2:1.0),'good':good,'bad':bad});
//   //     return bestId;
//   //   }
//   //
//   //   // ----- Stage 2 (borderline only): eye-aligned refinement -----
//   //   final bool borderline = (passThr && !passSep) || (!passThr && d1 < thr * 1.10);
//   //   if (borderline) {
//   //     final aligned = await _getAlignedLiveEmbeddingFromXFile(liveImage);
//   //     if (aligned != null) {
//   //       final alignedLive = aligned.emb;
//   //
//   //       double r1 = double.infinity, r2 = double.infinity;
//   //       String? rid;
//   //       List<double>? rBestEmb;
//   //
//   //       for (final r in rows) {
//   //         final raw = r['image_data'];
//   //         if (raw is! String || raw.isEmpty) continue;
//   //         try {
//   //           final parsed = jsonDecode(raw);
//   //           final Iterable<List<double>> vectors =
//   //           (parsed is List && parsed.isNotEmpty && parsed.first is List)
//   //               ? (parsed as List).map<List<double>>((v) => (v as List).map((e) => (e as num).toDouble()).toList())
//   //               : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
//   //
//   //           for (final v in vectors) {
//   //             if (v.length != alignedLive.length) continue;
//   //             final stored = _l2Normalize(v);
//   //             final d = _euclideanDistance(alignedLive, stored);
//   //             if (d < r1) { r2 = r1; r1 = d; rid = r['employee_id'] as String?; rBestEmb = stored; }
//   //             else if (d < r2) { r2 = d; }
//   //           }
//   //         } catch (_) {}
//   //       }
//   //
//   //       if (rid != null) {
//   //         double thr2 = (thr >= 1.0) ? max(1.00, thr - 0.05) : max(0.36, thr - 0.02);
//   //         final bool pass2 = (r1 < thr2) && ((r2 - r1) >= sepAbs);
//   //
//   //         if (pass2) {
//   //           _lastLiveEmb = alignedLive; _lastBestEmb = rBestEmb; _lastBestId = rid; _lastD1 = r1; _lastD2 = r2;
//   //           lastDecisionIsStrong = lastDecisionIsStrong || (r1 < thr2 * 0.88 && (r2 - r1) > sepAbs * 1.3);
//   //           await _logEvent({'event':'recognize','decision':'ACCEPT_REFINED','bestId':rid,'d1':r1,'d2':r2,'delta':r2-r1});
//   //           return rid;
//   //         }
//   //
//   //         // Optional: fuse with shape (only if gallery stores shape)
//   //         if (aligned.shape != null) {
//   //           try {
//   //             final row = rows.firstWhere((e) => (e['employee_id'] as String?) == rid, orElse: () => {});
//   //             final raw = row['image_data'];
//   //             double? bestShapeDist;
//   //             if (raw is String && raw.isNotEmpty) {
//   //               final parsed = jsonDecode(raw);
//   //               if (parsed is List && parsed.isNotEmpty) {
//   //                 for (final item in parsed) {
//   //                   if (item is Map && item['shape'] is List) {
//   //                     final s = (item['shape'] as List).map((e) => (e as num).toDouble()).toList();
//   //                     if (s.length == 10) {
//   //                       final ds = _shapeDistance(aligned.shape!, s);
//   //                       bestShapeDist = (bestShapeDist == null) ? ds : min(bestShapeDist!, ds);
//   //                     }
//   //                   }
//   //                 }
//   //               }
//   //             }
//   //             if (bestShapeDist != null) {
//   //               const double W_EMB = 0.75, W_SHAPE = 0.25;
//   //               final fused1 = W_EMB * r1 + W_SHAPE * bestShapeDist!;
//   //               final fused2 = W_EMB * r2; // second-best has no shape fusion
//   //               const double FUSED_THR = 0.95;
//   //               const double FUSED_MARGIN = 0.08;
//   //               final passFused = (fused1 < FUSED_THR) && ((fused2 - fused1) >= FUSED_MARGIN);
//   //               if (passFused) {
//   //                 _lastLiveEmb = alignedLive; _lastBestEmb = rBestEmb; _lastBestId = rid; _lastD1 = r1; _lastD2 = r2;
//   //                 lastDecisionIsStrong = true;
//   //                 await _logEvent({'event':'recognize','decision':'ACCEPT_FUSED','bestId':rid,'d1':r1,'d2':r2,
//   //                   'delta':r2-r1,'shape':bestShapeDist});
//   //                 return rid;
//   //               }
//   //             }
//   //           } catch (_) {}
//   //         }
//   //       }
//   //     }
//   //   }
//   //   await _ensureCentroids();
//   //
//   //   await _logEvent({'event':'recognize','decision':'REJECT',
//   //     'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
//   //     'bestId':bestId,'d1':d1,'d2':d2,'delta':d2-d1,
//   //     'ratio': (d2>0? d1/d2:1.0),'good':good,'bad':bad});
//   //   return null;
//   // }
//
//
//
//   // Future<String?> recognizeFace(XFile liveImage) async {
//   //   final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
//   //   if (liveEmbedding == null) {
//   //     await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
//   //     return null;
//   //   }
//   //   _lastLiveEmb = liveEmbedding;
//   //   final dim = liveEmbedding.length;
//   //   debugPrint('[LIVE] embedding dim=$dim');
//   //
//   //   final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
//   //   if (allProfiles.isEmpty) {
//   //     debugPrint('Database is empty. No faces to compare against.');
//   //     await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
//   //     return null;
//   //   }
//   //
//   //   // Thresholds tuned for L2-NORMALIZED 512-D float embeddings.
//   //   // Start conservative to avoid wrong IDs. You can relax later after logs.
//   //   const double THR      = 0.90;  // absolute max distance
//   //   const double SEP_ABS  = 0.15;  // min gap d2 - d1
//   //   const double SEP_RATIO= 0.85;  // d1/d2 <= 0.85
//   //
//   //   String? bestId;
//   //   double d1 = double.infinity, d2 = double.infinity;
//   //   int good = 0, bad = 0;
//   //
//   //   for (final profile in allProfiles) {
//   //     final raw = profile['image_data'];
//   //     if (raw is! String || raw.isEmpty) { bad++; continue; }
//   //
//   //     try {
//   //       final parsed = jsonDecode(raw);
//   //
//   //       final Iterable<List<double>> vectors =
//   //       (parsed is List && parsed.isNotEmpty && parsed.first is List)
//   //           ? (parsed as List).map<List<double>>(
//   //               (v) => (v as List).map((e) => (e as num).toDouble()).toList())
//   //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
//   //
//   //       for (final vec in vectors) {
//   //         if (vec.length != dim) { bad++; continue; }
//   //
//   //         // Defensive L2 on stored vectors in case legacy rows weren’t normalized
//   //         final stored = _l2Normalize(vec);
//   //
//   //         // Optional: reject degenerate templates (too sparse)
//   //         final nonZero = stored.where((x) => x.abs() > 1e-6).length / stored.length;
//   //         if (nonZero < 0.1) { bad++; continue; } // ~10% non-zeros min
//   //
//   //         final d = _euclideanDistance(liveEmbedding, stored);
//   //         if (d < d1) {
//   //           d2 = d1; d1 = d;
//   //           bestId = profile['employee_id'] as String?;
//   //           _lastBestEmb = stored;
//   //         } else if (d < d2) {
//   //           d2 = d;
//   //         }
//   //         good++;
//   //       }
//   //     } catch (_) { bad++; }
//   //   }
//   //
//   //   if (bestId == null) {
//   //     await _logEvent({'event': 'recognize', 'reason': 'NO_VALID_VECTORS', 'good': good, 'bad': bad});
//   //     return null;
//   //   }
//   //
//   //   final bool passThr   = d1 < THR;
//   //   final bool passSep   = ((d2 - d1) >= SEP_ABS) || (d2 > 0 && (d1 / d2) <= SEP_RATIO);
//   //
//   //   debugPrint('[MATCH] best=$bestId d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} '
//   //       'Δ=${(d2-d1).toStringAsFixed(3)} thr=$THR abs=$SEP_ABS ratio=$SEP_RATIO '
//   //       'passThr=$passThr passSep=$passSep good=$good bad=$bad');
//   //
//   //   _lastBestId = bestId;
//   //   _lastD1 = d1;
//   //   _lastD2 = d2;
//   //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
//   //
//   //   if (passThr && passSep) {
//   //     await _logEvent({
//   //       'event': 'recognize',
//   //       'decision': 'ACCEPT',
//   //       'bestId': bestId,
//   //       'd1': d1, 'd2': d2,
//   //       'delta': d2 - d1,
//   //       'ratio': (d2 > 0 ? d1 / d2 : 1.0),
//   //       'good': good, 'bad': bad,
//   //     });
//   //     return bestId;
//   //   }
//   //
//   //   await _logEvent({
//   //     'event': 'recognize',
//   //     'decision': 'REJECT',
//   //     'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
//   //     'bestId': bestId,
//   //     'd1': d1, 'd2': d2,
//   //     'delta': d2 - d1,
//   //     'ratio': (d2 > 0 ? d1 / d2 : 1.0),
//   //     'good': good, 'bad': bad,
//   //   });
//   //   return null;
//   // }
//
//
//   // Future<String?> recognizeFace(XFile liveImage) async {
//   //   // 1) Live probe (already L2 in your pipeline)
//   //   final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
//   //   if (liveEmbedding == null) {
//   //     debugPrint("Could not generate embedding from live image.");
//   //     return null;
//   //   }
//   //   // 👉 ADD THESE TWO LINES HERE
//   //   final dim = liveEmbedding.length;
//   //   debugPrint('[LIVE] embedding dim=$dim');
//   //   // 👈
//   //
//   //   // 2) Gallery
//   //   final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
//   //   if (allProfiles.isEmpty) {
//   //     debugPrint('Database is empty. No faces to compare against.');
//   //     return null;
//   //   }
//   //
//   //   // # 3) clear attributes & delete build caches
//   //   // attrib -R -S -H .\build\* /S /D 2>$null
//   //   // Remove-Item -Recurse -Force .\build, .\android\app\build, .\.dart_tool -ErrorAction SilentlyContinue
//   //   //
//   //   // # 4) fresh resolve & run
//   //   // flutter pub get
//   //   // flutter runTunables for 512-D L2 embeddings (your model outputs 512 dims)
//   //   final double threshold = (dim >= 512) ? 1.0 : 0.75; // keep generous at first
//   //   const double margin = 0.02;                      // was ~0.20–0.25 → too strict for your data
//   //   const double ratioThr  = 0.985;                      // new: ratio-based fallback (d1/d2 ≤ 0.985)
//   //
//   //   String? bestId;
//   //   double d1 = double.infinity, d2 = double.infinity;
//   //
//   //   for (final profile in allProfiles) {
//   //     final raw = profile['image_data'];
//   //     if (raw is! String || raw.isEmpty) continue;
//   //
//   //     try {
//   //       final parsed = jsonDecode(raw);
//   //
//   //       // Support both single template [..] and multi-template [[..],[..],..]
//   //       final Iterable<List<double>> vectors = (parsed is List && parsed.isNotEmpty && parsed.first is List)
//   //           ? (parsed as List).map<List<double>>((v) => (v as List).map((e) => (e as num).toDouble()).toList())
//   //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
//   //
//   //       for (final vec in vectors) {
//   //         // Defensive L2 on stored vectors
//   //         final stored = _l2Normalize(vec);
//   //         final d = _euclideanDistance(liveEmbedding, stored);
//   //         if (d < d1) { d2 = d1; d1 = d; bestId = profile['employee_id'] as String?; }
//   //         else if (d < d2) { d2 = d; }
//   //       }
//   //     } catch (_) {
//   //       // skip malformed rows
//   //       continue;
//   //     }
//   //   }
//   //
//   //
//   //
//   //
//   //   if (bestId == null) return null;
//   //
//   //   final bool passThr = d1 < threshold;
//   //   final bool passSep   = ((d2 - d1) >= margin) || (d2 > 0 && (d1 / d2) <= ratioThr);
//   //   debugPrint('[MATCH] d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} Δ=${(d2-d1).toStringAsFixed(3)} '
//   //       'passThr=${d1 < threshold} passMar=${(d2 - d1) >= margin} bestId=$bestId');
//   //
//   //   if (passThr && passSep) {
//   //     debugPrint('✅ Matched $bestId | d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} Δ=${(d2-d1).toStringAsFixed(3)}');
//   //     return bestId;
//   //   } else {
//   //     debugPrint('❌ Unknown | d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} Δ=${(d2-d1).toStringAsFixed(3)}');
//   //     return null; // Unknown; your K-of-N gate will suppress punches
//   //   }
//   //
//   // }
//
//
//   /// Calculates the Euclidean distance between two embeddings.
//   double _euclideanDistance(List<double> e1, List<double> e2) {
//     double s = 0.0;
//     for (int i = 0; i < e1.length; i++) {
//       final double d = e1[i] - e2[i];
//       s += d * d;
//     }
//     return sqrt(s);
//   }
//
//   // double _euclideanDistance(List<double> e1, List<double> e2) {
//   //   double sum = 0.0;
//   //   for (int i = 0; i < e1.length; i++) {
//   //     sum += pow(e1[i] - e2[i], 2);
//   //   }
//   //   return sqrt(sum);
//   // }
//
//   /// Disposes of the resources used by the service.
//   void dispose() {
//     _faceDetector.close();
//     _liveDetector.close(); // <-- add
//     _interpreter.close();
//   }
// }

// thirds
import 'dart:convert';
import 'dart:typed_data';
import 'dart:io' as io;
import 'dart:math';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;
import 'package:kiosk/app/core/services/database_service.dart'; // Assuming this is your database service
import 'package:path_provider/path_provider.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

class FaceRecognitionService {
  // --- Debug state for last recognition ---
  List<double>? _lastLiveEmb;
  List<double>? _lastBestEmb;
  String? _lastBestId;
  double? _lastD1;
  double? _lastD2;
  double? _lastMeanLuma, _lastSharpness; // from _qualityMetrics
  double? _lastBoxW, _lastBoxH;          // from the selected face bbox
  // in FaceRecognitionService fields:
  List<double>? _liveFloatEmb;   // de-quantized -> L2 (correct modern form)
  List<double>? _liveLegacyEmb;  // raw int -> L2 (legacy form to match old DB rows)

// Flag the punch screen can read for early-accept (optional)
  bool lastDecisionIsStrong = false;

// FAST detector just for live recognition (skip landmarks; cheaper)
  final FaceDetector _liveDetector = FaceDetector(
    options: FaceDetectorOptions(
      performanceMode: FaceDetectorMode.fast,
      enableLandmarks: false,
      enableContours: false,
      enableClassification: false,
      minFaceSize: 0.15, // ignore tiny faces
    ),
  );

// Toggle: set true to dump full 512 floats to the log file (big!)
// Default keeps only a short sample (first 16 dims) to keep logs small.
  bool _logFullEmbeddings = false;

  late Interpreter _interpreter;
  final FaceDetector _faceDetector = FaceDetector(
    options: FaceDetectorOptions(
      performanceMode: FaceDetectorMode.fast,
      enableLandmarks: true,   // we need eyes/nose/mouth for alignment/shape
      enableContours: true,
      enableClassification: false,
      minFaceSize: 0.15,
    ),
  );

  // ---------- geometric descriptor (optional fusion) ----------
  // Replace your _shapeDescriptor with this version
  List<double>? _shapeDescriptor(Face f) {
    final le = f.landmarks[FaceLandmarkType.leftEye]?.position;
    final re = f.landmarks[FaceLandmarkType.rightEye]?.position;
    final nose = f.landmarks[FaceLandmarkType.noseBase]?.position;
    if (le == null || re == null || nose == null) return null;

    final leftAnchor  = f.landmarks[FaceLandmarkType.leftEar]?.position
        ?? f.landmarks[FaceLandmarkType.leftCheek]?.position;
    final rightAnchor = f.landmarks[FaceLandmarkType.rightEar]?.position
        ?? f.landmarks[FaceLandmarkType.rightCheek]?.position;

    final bb = f.boundingBox;

    // Force everything to double
    final double leX = le.x.toDouble(), leY = le.y.toDouble();
    final double reX = re.x.toDouble(), reY = re.y.toDouble();
    final double noseX = nose.x.toDouble(), noseY = nose.y.toDouble();
    final double lx = (leftAnchor?.x ?? bb.left).toDouble();
    final double ly = (leftAnchor?.y ?? bb.center.dy).toDouble();
    final double rx = (rightAnchor?.x ?? bb.right).toDouble();
    final double ry = (rightAnchor?.y ?? bb.center.dy).toDouble();

    // Normalize to eye center, level the eyes, scale by inter-ocular distance
    final double cx = (leX + reX) / 2.0;
    final double cy = (leY + reY) / 2.0;
    final double dx = reX - leX;
    final double dy = reY - leY;
    final double ang = atan2(dy, dx);
    final double dist = sqrt(dx * dx + dy * dy);
    if (dist < 1e-6) return null;

    double normX(double x, double y) {
      final double tx = x - cx;
      final double ty = y - cy;
      final double rx2 =  tx * cos(-ang) - ty * sin(-ang);
      return rx2 / dist;
    }
    double normY(double x, double y) {
      final double tx = x - cx;
      final double ty = y - cy;
      final double ry2 =  tx * sin(-ang) + ty * cos(-ang);
      return ry2 / dist;
    }

    // 5 points × (x,y) = 10 dims (same length as before)
    return [
      normX(leX, leY),   normY(leX, leY),
      normX(reX, reY),   normY(reX, reY),
      normX(noseX, noseY), normY(noseX, noseY),
      normX(lx, ly),     normY(lx, ly),
      normX(rx, ry),     normY(rx, ry),
    ];
  }
  // Low-cost lighting normalization for tough frames.
// Keeps quantized input (uint8) but spreads contrast a bit in dark/bright conditions.
  img.Image _lightNormalize(img.Image im) {
    final qm = _qualityMetrics(im);
    final mean = qm['meanLuma'] ?? 128.0;
    _lastMeanLuma = mean;
    _lastSharpness = qm['sobelEnergy'];
    // Slight gamma & contrast nudges only at extremes
    if (mean < 55) {
      return img.adjustColor(im, gamma: 1.10, contrast: 0.05);
    } else if (mean > 200) {
      return img.adjustColor(im, gamma: 0.90, contrast: -0.05);
    }
    return im;
  }

  // ---------- aligned live embedding (uses _faceDetector with landmarks) ----------
  Future<({List<double> emb, List<double>? shape})?> _getAlignedLiveEmbeddingFromXFile(XFile xf) async {
    try {
      final input = InputImage.fromFilePath(xf.path);
      final faces = await _faceDetector.processImage(input); // has landmarks=true
      if (faces.isEmpty) return null;

      faces.sort((a, b) {
        final aa = a.boundingBox.width * a.boundingBox.height;
        final bb = b.boundingBox.width * b.boundingBox.height;
        return bb.compareTo(aa);
      });
      final face = faces.first;
      if (!_passesQuality(face)) return null;

      final bytes = await xf.readAsBytes();
      final orig = img.decodeImage(bytes);
      if (orig == null) return null;

      final crop = _cropFaceWithMargin(orig, face, margin: 0.22);
      final aligned = _alignByEyesIfAvailable(crop, face);

      final qm = _qualityMetrics(aligned);
      _lastMeanLuma = qm['meanLuma'];
      _lastSharpness = qm['sobelEnergy'];
      _lastBoxW = face.boundingBox.width;
      _lastBoxH = face.boundingBox.height;

      final emb = _getEmbeddingFromImage(aligned);
      final shp = _shapeDescriptor(face);
      return (emb: emb, shape: shp);
    } catch (e) {
      debugPrint('❌ _getAlignedLiveEmbeddingFromXFile error: $e');
      return null;
    }
  }


  double _shapeDistance(List<double> a, List<double> b) {
    double s = 0.0;
    for (int i = 0; i < a.length; i++) { final d = a[i] - b[i]; s += d * d; }
    return sqrt(s);
  }


  FaceRecognitionService() {
    _loadModel();
  }

  /// Loads the TFLite model from assets.
  Future<void> _loadModel() async {
    try {
      final options = InterpreterOptions()
        ..threads = 4
        ..useNnApiForAndroid = true; // NNAPI when available

      // Optional GPU delegate (silently ignored if not available)
      try {
        final gpuDelegateV2 = GpuDelegateV2();
        options.addDelegate(gpuDelegateV2);
      } catch (_) {}

      _interpreter = await Interpreter.fromAsset('assets/facenet.tflite', options: options);

      // Warm-up to avoid first-inference stall
      final warmIn = List.filled(1 * 160 * 160 * 3, 0).reshape([1, 160, 160, 3]);
      final warmOut = List.filled(1 * 512, 0).reshape([1, 512]);
      _interpreter.run(warmIn, warmOut);

      debugPrint('✅ FaceNet model loaded + warmed.');
    } catch (e) {
      debugPrint('❌ Failed to load FaceNet model: $e');
    }
  }

  // Future<void> _loadModel() async {
  //   try {
  //     _interpreter = await Interpreter.fromAsset('assets/facenet.tflite');
  //     debugPrint('✅ FaceNet model loaded successfully.');
  //   } catch (e) {
  //     debugPrint('❌ Failed to load FaceNet model: $e');
  //   }
  // }
  List<double>? _sample(List<double>? v, [int k = 16]) {
    if (v == null) return null;
    if (v.length <= k) return List<double>.from(v);
    return v.sublist(0, k);
  }

// Public wrapper so UI code can trigger a punch log with op type
  Future<void> logPunchDecision(String op, {String? employeeId}) async {
    await _logEvent({
      'event': 'punch',
      'op': op,                                  // e.g., IN / OUT (or your enum string)
      'employeeId': employeeId ?? _lastBestId,   // who did we punch for
      'd1': _lastD1,
      'd2': _lastD2,
      'delta': (_lastD1 != null && _lastD2 != null) ? (_lastD2! - _lastD1!) : null,
      'liveEmbLen': _lastLiveEmb?.length,
      'bestEmbLen': _lastBestEmb?.length,
      'liveEmbSample': _sample(_lastLiveEmb),    // first 16 dims
      'bestEmbSample': _sample(_lastBestEmb),
      'note': _logFullEmbeddings ? 'full_embeddings_included' : 'samples_only',
      'liveEmbedding': _logFullEmbeddings ? _lastLiveEmb : null,
      'bestEmbedding': _logFullEmbeddings ? _lastBestEmb : null,
    });
  }

  Future<String?> getPHashForRegistration(String base64Image) async {
    try {
      final cleaned = base64Image.split(',').last.trim();
      final bytes = base64Decode(base64.normalize(cleaned));
      final original = img.decodeImage(bytes);
      if (original == null) return null;

      // Use ML Kit detector you already configured
      final tempDir = await getTemporaryDirectory();
      final tmp = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
      await tmp.writeAsBytes(bytes, flush: true);
      final input = InputImage.fromFilePath(tmp.path);
      final faces = await _faceDetector.processImage(input);
      await tmp.delete();

      if (faces.isEmpty) return null;

      // pick largest face
      faces.sort((a, b) {
        final aa = a.boundingBox.width * a.boundingBox.height;
        final bb = b.boundingBox.width * b.boundingBox.height;
        return bb.compareTo(aa);
      });
      final face = faces.first;
      if (!_passesQuality(face)) return null;

      final cropped = _cropFaceWithMargin(original, face, margin: 0.25);
      final aligned = _alignByEyesIfAvailable(cropped, face);
      return _aHashHex(aligned); // helper below
    } catch (_) {
      return null;
    }
  }
  String _aHashHex(img.Image face) {
    final g = img.grayscale(face);
    final small = img.copyResize(g, width: 8, height: 8);
    int sum = 0;
    final vals = List<int>.filled(64, 0);
    int k = 0;
    for (int y = 0; y < 8; y++) {
      for (int x = 0; x < 8; x++) {
        final lum = img.getLuminance(small.getPixel(x, y)).toInt(); // ← cast
        vals[k++] = lum;
        sum += lum;
      }
    }
    final avg = sum ~/ 64;

    int hi = 0, lo = 0;
    for (int i = 0; i < 64; i++) {
      if (vals[i] >= avg) {
        if (i < 32) {
          hi |= (1 << (31 - i));
        } else {
          lo |= (1 << (63 - i));
        }
      }
    }
    final hiHex = hi.toRadixString(16).padLeft(8, '0');
    final loHex = lo.toRadixString(16).padLeft(8, '0');
    return '$hiHex$loHex';
  }


  // int _hammingHex(String a, String b) {
  //   final ai = BigInt.parse(a, radix: 16);
  //   final bi = BigInt.parse(b, radix: 16);
  //   BigInt x = ai ^ bi;
  //   int c = 0;
  //   while (x != BigInt.zero) { x &= (x - BigInt.one); c++; }
  //   return c;
  // }


// public wrapper to your internal logger
  Future<void> logAudit(String event, Map<String, dynamic> extra) async {
    await _logEvent({'event': event, ...extra});
  }


  // L2 normalization helper
  List<double> _l2Normalize(List<double> v) {
    double sum = 0.0;
    for (final x in v) {
      sum += x * x;
    }
    final norm = sqrt(sum);
    if (norm < 1e-12) return v; // avoid div-by-zero; returns as-is
    return List<double>.generate(v.length, (i) => v[i] / norm);
  }

  /// **Use this during employee registration.**
  /// Takes a Base64 image string, computes the face embedding, and returns it.
  // Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
  //   try {
  //     final Uint8List imageBytes = base64Decode(base64.normalize(base64Image));
  //     return await _processImageBytes(imageBytes);
  //   } on FormatException catch (e) {
  //     debugPrint("❌ Invalid Base64 string provided: ${e.message}");
  //     return null;
  //   } catch (e) {
  //     debugPrint("❌ An error occurred during registration embedding: $e");
  //     return null;
  //   }
  // }

  /// ✅ Now returns an L2-normalized embedding.
  Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
    try {
      // Handle both plain base64 and data URIs like "data:image/jpeg;base64,..."
      final cleaned = base64Image.split(',').last.trim();

      final Uint8List imageBytes = base64Decode(base64.normalize(cleaned));

      // Your existing face pipeline should: decode -> detect -> ALIGN -> preprocess -> infer
      final List<double>? rawEmbedding = await _processImageBytes(imageBytes);
      if (rawEmbedding == null) return null;

      // ✅ enforce L2 here as the last step
      return _l2Normalize(rawEmbedding);
    } on FormatException catch (e) {
      debugPrint("❌ Invalid Base64 string provided: ${e.message}");
      return null;
    } catch (e) {
      debugPrint("❌ An error occurred during registration embedding: $e");
      return null;
    }
  }


  /// **Use this for live face recognition.**
  /// Takes a live image from the camera and computes the face embedding.
  Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
    try {
      // Use the file path directly with ML Kit (no temp write)
      final inputImage = InputImage.fromFilePath(imageFile.path);
      final faces = await _liveDetector.processImage(inputImage);
      if (faces.isEmpty) {
        debugPrint('No face detected in live image.');
        return null;
      }

      // Pick largest face
      faces.sort((a, b) {
        final aa = a.boundingBox.width * a.boundingBox.height;
        final bb = b.boundingBox.width * b.boundingBox.height;
        return bb.compareTo(aa);
      });
      final face = faces.first;

      if (!_passesQuality(face)) {
        await _logEvent({
          'event': 'detect',
          'reason': 'FACE_TOO_SMALL',
          'boxW': face.boundingBox.width,
          'boxH': face.boundingBox.height,
        });
        return null;
      }

      // Decode once for crop/resize
      final bytes = await imageFile.readAsBytes();
      final original = img.decodeImage(bytes);
      if (original == null) return null;

      // Fast path: skip eye alignment (no landmarks in fast detector)
      final crop = _cropFaceWithMargin(original, face, margin: 0.20);

      // Track quality metrics for adaptive thresholds/logging
      final qm = _qualityMetrics(crop);
      _lastMeanLuma = qm['meanLuma'];
      _lastSharpness = qm['sobelEnergy'];
      _lastBoxW = face.boundingBox.width;
      _lastBoxH = face.boundingBox.height;

      return _getEmbeddingFromImage(crop);
    } catch (e) {
      debugPrint('❌ getEmbeddingFromLiveImage error: $e');
      return null;
    }
  }

  // Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
  //   try {
  //     final imageBytes = await imageFile.readAsBytes();
  //     return await _processImageBytes(imageBytes);
  //   } catch (e) {
  //     debugPrint("❌ An error occurred during live image embedding: $e");
  //     return null;
  //   }
  // }

  /// Centralized function to process image bytes (from Base64 or XFile).
  Future<List<double>?> _processImageBytes(Uint8List imageBytes) async {
    io.File? tempFile;
    try {
      // Decode image to use with the 'image' package for cropping
      final originalImage = img.decodeImage(imageBytes);
      if (originalImage == null) {
        debugPrint('❌ Failed to decode image bytes for cropping.');
        return null;
      }

      // --- Use a temporary file for ML Kit for better reliability ---
      final tempDir = await getTemporaryDirectory();
      tempFile = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
      await tempFile.writeAsBytes(imageBytes, flush: true);

      final inputImage = InputImage.fromFilePath(tempFile.path);
      final faces = await _faceDetector.processImage(inputImage);

      if (faces.isEmpty) {
        debugPrint('No face detected in the image.');
        return null;
      }

      // --- FIX: Select the largest face if multiple are detected ---
      Face selectedFace;
      if (faces.length > 1) {
        debugPrint("Multiple faces detected. Selecting the largest one.");
        // Sort faces by the area of their bounding box in descending order
        faces.sort((a, b) {
          final aSize = a.boundingBox.width * a.boundingBox.height;
          final bSize = b.boundingBox.width * b.boundingBox.height;
          return bSize.compareTo(aSize);
        });
        selectedFace = faces.first; // The largest face is now the first in the list
      } else {
        selectedFace = faces.first; // Only one face was detected
      }

      debugPrint('✅ Face selected successfully! Cropping and processing.');
      final croppedFace = _cropFaceWithMargin(originalImage, selectedFace, margin: 0.25);
      if (!_passesQuality(selectedFace)) {
        debugPrint('⛔ Rejected by quality gate (face too small).');
        await _logEvent({
          'event': 'detect',
          'reason': 'FACE_TOO_SMALL',
          'boxW': selectedFace.boundingBox.width,
          'boxH': selectedFace.boundingBox.height,
        });
        return null;
      }



// Optional: reject tiny faces before embedding (quality gate)
      if (!_passesQuality(selectedFace)) {
        debugPrint('Frame rejected by quality gate (size).');
        return null;
      }

      final alignedFace = _alignByEyesIfAvailable(croppedFace, selectedFace);
      final qm = _qualityMetrics(alignedFace);
      await _logEvent({
        'event': 'quality',
        'meanLuma': qm['meanLuma'],
        'sobel': qm['sobelEnergy'],
        'boxW': selectedFace.boundingBox.width,
        'boxH': selectedFace.boundingBox.height,
      });


      await _logEvent({
        'event': 'quality',
        'meanLuma': _lastMeanLuma,
        'sobel': _lastSharpness,
        'boxW': _lastBoxW,
        'boxH': _lastBoxH,
      });


      return _getEmbeddingFromImage(alignedFace);


    } catch (e) {
      debugPrint("❌ Error in _processImageBytes: $e");
      return null;
    } finally {
      // Clean up the temporary file
      await tempFile?.delete();
    }
  }
  Map<String, double> _qualityMetrics(img.Image face) {
    // grayscale + 64x64 downsample for cheap metrics
    final g = img.grayscale(face);
    final s = img.copyResize(g, width: 64, height: 64);

    // brightness (mean luminance)
    double sum = 0;
    for (int y = 0; y < s.height; y++) {
      for (int x = 0; x < s.width; x++) {
        sum += img.getLuminance(s.getPixel(x, y));
      }
    }
    final mean = sum / (s.width * s.height);

    // very light blur proxy: Sobel energy (larger = sharper)
    double energy = 0;
    const sx = [
      [-1, 0, 1],
      [-2, 0, 2],
      [-1, 0, 1],
    ];
    const sy = [
      [-1, -2, -1],
      [ 0,  0,  0],
      [ 1,  2,  1],
    ];
    for (int y = 1; y < s.height - 1; y++) {
      for (int x = 1; x < s.width - 1; x++) {
        double gx = 0, gy = 0;
        for (int j = -1; j <= 1; j++) {
          for (int i = -1; i <= 1; i++) {
            final lum = img.getLuminance(s.getPixel(x + i, y + j)).toDouble();
            gx += sx[j + 1][i + 1] * lum;
            gy += sy[j + 1][i + 1] * lum;
          }
        }
        energy += (gx * gx + gy * gy);
      }
    }
    energy /= ((s.width - 2) * (s.height - 2));
    return {'meanLuma': mean, 'sobelEnergy': energy};
  }
  Future<io.File> _logFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return io.File('${dir.path}/face_debug.log');
  }

  Future<void> _logEvent(Map<String, dynamic> m) async {
    try {
      final f = await _logFile();
      final rec = {
        'ts': DateTime.now().toIso8601String(),
        ...m,
      };
      await f.writeAsString('${jsonEncode(rec)}\n', mode: io.FileMode.append, flush: true);
      // simple rotate if >512KB
      if (await f.length() > 512 * 1024) {
        final rotated = io.File('${f.path}.1');
        if (await rotated.exists()) await rotated.delete();
        await f.rename(rotated.path);
      }
    } catch (_) { /* ignore */ }
  }


  img.Image _cropFaceWithMargin(img.Image original, Face face, {double margin = 0.25}) {
    final bb = face.boundingBox;
    final cx = bb.left + bb.width / 2;
    final cy = bb.top + bb.height / 2;
    final size = max(bb.width, bb.height) * (1.0 + margin);

    final int left   = max(0, (cx - size / 2).floor());
    final int top    = max(0, (cy - size / 2).floor());
    final int right  = min(original.width,  (cx + size / 2).ceil()).toInt();
    final int bottom = min(original.height, (cy + size / 2).ceil()).toInt();

    final int w = max(1, right - left).toInt();
    final int h = max(1, bottom - top).toInt();
    return img.copyCrop(original, x: left, y: top, width: w, height: h);
  }
  img.Image _alignByEyesIfAvailable(img.Image faceCrop, Face face) {
    final leftEye = face.landmarks[FaceLandmarkType.leftEye]?.position;
    final rightEye = face.landmarks[FaceLandmarkType.rightEye]?.position;
    if (leftEye == null || rightEye == null) return faceCrop; // no landmarks → skip

    // rotate so the eyes are level
    final dy = rightEye.y - leftEye.y;
    final dx = rightEye.x - leftEye.x;
    final angleRad = atan2(dy, dx);
    final angleDeg = -angleRad * 180 / pi; // negative to un-tilt
    return img.copyRotate(faceCrop, angle: angleDeg);
  }

  bool _passesQuality(Face face) {
    // Temporarily relaxed; raise to 112px after you calibrate thresholds.
    return face.boundingBox.width >= 80 && face.boundingBox.height >= 80;
  }



  /// Crops the face from the full image.
  img.Image _cropFace(img.Image originalImage, Face face) {
    final boundingBox = face.boundingBox;
    return img.copyCrop(
      originalImage,
      x: boundingBox.left.toInt(),
      y: boundingBox.top.toInt(),
      width: boundingBox.width.toInt(),
      height: boundingBox.height.toInt(),
    );
  }

  /// Prepares the cropped face and runs the TFLite model to get the embedding.
  // List<double> _getEmbeddingFromImage(img.Image image) {
  //   final resizedImage = img.copyResize(image, width: 160, height: 160);
  //
  //   // Create a Uint8List to hold the raw pixel data for the quantized model.
  //   final imageBytes = Uint8List(1 * 160 * 160 * 3);
  //   int pixelIndex = 0;
  //
  //   // Iterate over the pixels and store their raw RGB integer values.
  //   for (int y = 0; y < 160; y++) {
  //     for (int x = 0; x < 160; x++) {
  //       final pixel = resizedImage.getPixel(x, y);
  //       imageBytes[pixelIndex++] = pixel.r.toInt();
  //       imageBytes[pixelIndex++] = pixel.g.toInt();
  //       imageBytes[pixelIndex++] = pixel.b.toInt();
  //     }
  //   }
  //
  //   // Reshape the flat list into the format [1, 160, 160, 3] required by the model.
  //   final input = imageBytes.reshape([1, 160, 160, 3]);
  //
  //   // The output buffer should also be integer-based for a quantized model.
  //   final output = List.filled(1 * 512, 0).reshape([1, 512]);
  //
  //   _interpreter.run(input, output);
  //
  //   // Convert the integer output from the model to a List<double> for distance calculation.
  //   final embedding = (output[0] as List<int>).map((e) => e.toDouble()).toList();
  //
  //   return embedding;
  // }

  /// Prepares the cropped face and runs the TFLite model to get the embedding.
  // List<double> _getEmbeddingFromImage(img.Image image) {
  //   // keep your current resize
  //   final resizedImage = img.copyResize(image, width: 160, height: 160);
  //
  //   // keep your current uint8 input construction (works with your quantized model)
  //   final imageBytes = Uint8List(1 * 160 * 160 * 3);
  //   int pixelIndex = 0;
  //   for (int y = 0; y < 160; y++) {
  //     for (int x = 0; x < 160; x++) {
  //       final pixel = resizedImage.getPixel(x, y);
  //       imageBytes[pixelIndex++] = pixel.r.toInt();
  //       imageBytes[pixelIndex++] = pixel.g.toInt();
  //       imageBytes[pixelIndex++] = pixel.b.toInt();
  //     }
  //   }
  //
  //   // run the model
  //   final input = imageBytes.reshape([1, 160, 160, 3]);
  //   final output = List.filled(1 * 512, 0).reshape([1, 512]); // your current output shape
  //   _interpreter.run(input, output);
  //
  //   // convert to doubles
  //   final raw = (output[0] as List<int>).map((e) => e.toDouble()).toList();
  //
  //   // ✅ L2-normalize here
  //   final normalized = _l2Normalize(raw);
  //   return normalized;
  // }

  List<double> _getEmbeddingFromImage(img.Image image) {
    // 1) Resize to 160x160
    final resized = img.copyResize(image, width: 160, height: 160);

    // 2) Build uint8 input tensor (RGB)
    final inputBytes = Uint8List(1 * 160 * 160 * 3);
    int p = 0;
    for (int y = 0; y < 160; y++) {
      for (int x = 0; x < 160; x++) {
        final px = resized.getPixel(x, y);
        inputBytes[p++] = px.r.toInt();
        inputBytes[p++] = px.g.toInt();
        inputBytes[p++] = px.b.toInt();
      }
    }
    final input = inputBytes.reshape([1, 160, 160, 3]);

    // 3) Run model into INT buffer (quantized model)
    final out = List.filled(1 * 512, 0).reshape([1, 512]);
    _interpreter.run(input, out);
    final q = (out[0] as List<int>);

    // 4) Legacy live embedding (matches *old* DB rows)
    final legacy = List<double>.generate(q.length, (i) => q[i].toDouble());
    _liveLegacyEmb = _l2Normalize(legacy);

    // 5) Proper de-quantized live embedding (matches *new* rows)
    final t = _interpreter.getOutputTensor(0);
    final scale = t.params.scale;     // float
    final zp    = t.params.zeroPoint; // int
    List<double> floats;
    if (scale != 0.0) {
      floats = List<double>.generate(q.length, (i) => scale * (q[i] - zp));
    } else {
      // non-quantized fallback
      floats = (out[0] as List).map((e) => (e as num).toDouble()).toList();
    }
    _liveFloatEmb = _l2Normalize(floats);

    // return modern float embedding by default
    return _liveFloatEmb!;
  }
  bool _looksLegacy(List<double> v) {
    // Legacy int-L2 rows are non-negative and capped ~<=0.14 (because 255/L2norm)
    double maxv = double.negativeInfinity, minv = double.infinity;
    for (final x in v) { if (x > maxv) maxv = x; if (x < minv) minv = x; }
    return minv >= 0.0 && maxv <= 0.20; // generous cap
  }





  /// Recognizes a face by comparing its live embedding to stored profiles.
  /// Recognizes a face by comparing its live embedding to stored profiles (L2 + margin).
  // Future<String?> recognizeFace(XFile liveImage) async {
  //   final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
  //   if (liveEmbedding == null) {
  //     await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
  //     return null;
  //   }
  //   _lastLiveEmb = liveEmbedding; // <-- store the live embedding for later punch log
  //   final dim = liveEmbedding.length;
  //   debugPrint('[LIVE] embedding dim=$dim');
  //
  //   final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
  //   if (allProfiles.isEmpty) {
  //     debugPrint('Database is empty. No faces to compare against.');
  //     await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
  //     return null;
  //   }
  //
  //   // Tunables (start generous; tighten with logs)
  //   final double threshold = (dim >= 512) ? 1.20 : 1.0;
  //   const double marginAbs = 0.10;   // absolute separation
  //   const double ratioThr  = 0.96;  // ratio separation (d1/d2 <= 0.985)
  //
  //   String? bestId;
  //   double d1 = double.infinity, d2 = double.infinity;
  //   int good = 0, bad = 0;
  //
  //   for (final profile in allProfiles) {
  //     final raw = profile['image_data'];
  //     if (raw is! String || raw.isEmpty) { bad++; continue; }
  //     try {
  //       final parsed = jsonDecode(raw);
  //
  //       final Iterable<List<double>> vectors =
  //       (parsed is List && parsed.isNotEmpty && parsed.first is List)
  //           ? (parsed as List).map<List<double>>(
  //               (v) => (v as List).map((e) => (e as num).toDouble()).toList())
  //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
  //
  //       for (final vec in vectors) {
  //         if (vec.length != dim) { bad++; continue; }
  //         final stored = _l2Normalize(vec);
  //         final d = _euclideanDistance(liveEmbedding, stored);
  //         if (d < d1) {
  //           d2 = d1; d1 = d;
  //           bestId = profile['employee_id'] as String?;
  //           _lastBestEmb = stored;       // <-- add this line
  //         } else if (d < d2) {
  //           d2 = d;
  //         }
  //         good++;
  //       }
  //     } catch (_) { bad++; }
  //   }
  //
  //   if (bestId == null) {
  //     await _logEvent({'event': 'recognize', 'reason': 'NO_VALID_VECTORS', 'good': good, 'bad': bad});
  //     return null;
  //   }
  //
  //   final bool passThr = d1 < threshold;
  //   final bool passSep = ((d2 - d1) >= marginAbs) || (d2 > 0 && (d1 / d2) <= ratioThr);
  //
  //   debugPrint('[MATCH] best=$bestId d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} '
  //       'Δ=${(d2-d1).toStringAsFixed(3)} thr=$threshold abs=$marginAbs ratio=$ratioThr '
  //       'passThr=$passThr passSep=$passSep good=$good bad=$bad');
  //
  //   _lastBestId = bestId;
  //   _lastD1 = d1;
  //   _lastD2 = d2;
  //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
  //
  //
  //   if (passThr && passSep) {
  //     await _logEvent({
  //       'event': 'recognize',
  //       'decision': 'ACCEPT',
  //       'bestId': bestId,
  //       'd1': d1,
  //       'd2': d2,
  //       'delta': d2 - d1,
  //       'ratio': (d2 > 0 ? d1 / d2 : 1.0),
  //       'good': good,
  //       'bad': bad,
  //     });
  //     return bestId;
  //   }
  //
  //   _lastBestId = bestId;
  //   _lastD1 = d1;
  //   _lastD2 = d2;
  //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
  //
  //
  //   await _logEvent({
  //     'event': 'recognize',
  //     'decision': 'REJECT',
  //     'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
  //     'bestId': bestId,
  //     'd1': d1,
  //     'd2': d2,
  //     'delta': d2 - d1,
  //     'ratio': (d2 > 0 ? d1 / d2 : 1.0),
  //     'good': good,
  //     'bad': bad,
  //   });
  //   return null;
  // }


  //old
  Future<String?> recognizeFace(XFile liveImage) async {
    lastDecisionIsStrong = false; // reset every call

    final liveFloat = await getEmbeddingFromLiveImage(liveImage);
    if (liveFloat == null || _liveLegacyEmb == null) {
      await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
      return null;
    }
    final dim = liveFloat.length;
    debugPrint('[LIVE] embedding dim=$dim');

    final rows = await DatabaseService.instance.getAllEmployeeProfiles();
    if (rows.isEmpty) {
      await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
      return null;
    }

    // ----- Stage 1: your existing float+legacy scoring (unchanged) -----
    String? bestIdF, bestIdL;
    double d1F = double.infinity, d2F = double.infinity;
    double d1L = double.infinity, d2L = double.infinity;
    List<double>? bestEmbF, bestEmbL;
    int good = 0, bad = 0;

    for (final r in rows) {
      final raw = r['image_data'];
      if (raw is! String || raw.isEmpty) { bad++; continue; }
      try {
        final parsed = jsonDecode(raw);
        final Iterable<List<double>> vectors =
        (parsed is List && parsed.isNotEmpty && parsed.first is List)
            ? (parsed as List).map<List<double>>((v) => (v as List).map((e) => (e as num).toDouble()).toList())
            : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];

        for (final v in vectors) {
          if (v.length != dim) { bad++; continue; }
          final stored = _l2Normalize(v);
          final isLegacy = _looksLegacy(stored);

          if (isLegacy) {
            final d = _euclideanDistance(_liveLegacyEmb!, stored);
            if (d < d1L) { d2L = d1L; d1L = d; bestIdL = r['employee_id'] as String?; bestEmbL = stored; }
            else if (d < d2L) { d2L = d; }
          } else {
            final d = _euclideanDistance(liveFloat, stored);
            if (d < d1F) { d2F = d1F; d1F = d; bestIdF = r['employee_id'] as String?; bestEmbF = stored; }
            else if (d < d2F) { d2F = d; }
          }
          good++;
        }
      } catch (_) { bad++; }
    }

    // pick space by normalized score
    String? bestId; double d1 = double.infinity, d2 = double.infinity;
    double thr, sepAbs, sepRatio; List<double>? bestEmb;

    final okFloat = d1F.isFinite;
    final okLegacy = d1L.isFinite;
    double scoreF = okFloat ? d1F / 1.10 : double.infinity; // thrFloat ~1.10
    double scoreL = okLegacy ? d1L / 0.40 : double.infinity; // thrLegacy ~0.40

    if (scoreF <= scoreL) {
      bestId = bestIdF; d1 = d1F; d2 = d2F; bestEmb = bestEmbF;
      thr = 1.10; sepAbs = 0.10; sepRatio = 0.92;
    } else {
      bestId = bestIdL; d1 = d1L; d2 = d2L; bestEmb = bestEmbL;
      thr = 0.40; sepAbs = 0.04; sepRatio = 0.92;
    }

    if (bestId == null) {
      await _logEvent({'event':'recognize','reason':'NO_VALID_VECTORS','good':good,'bad':bad});
      return null;
    }

    // adaptive nudges by quality
    final sharp = _lastSharpness ?? 0.0;
    final boxMin = (_lastBoxW != null && _lastBoxH != null) ? min(_lastBoxW!, _lastBoxH!) : 0.0;
    if (thr >= 1.0) { // float space
      if (sharp > 1200 && boxMin > 130) { thr = 1.15; sepAbs = 0.08; sepRatio = 0.93; }
      if (sharp < 500  || boxMin < 90 ) { thr = 1.00; sepAbs = 0.12; sepRatio = 0.90; }
    } else {          // legacy space
      if (sharp > 1200 && boxMin > 130) { thr = 0.40; sepAbs = 0.025; sepRatio = 0.96; }
      if (sharp < 500  || boxMin < 90 ) { thr = 0.36; sepAbs = 0.035; sepRatio = 0.94; }
    }

    final passThr = d1 < thr;
    final passSep = ((d2 - d1) >= sepAbs) || (d2 > 0 && (d1 / d2) <= sepRatio);

    _lastLiveEmb = (thr >= 1.0) ? liveFloat : _liveLegacyEmb;
    _lastBestEmb = bestEmb;
    _lastBestId  = bestId;
    _lastD1 = d1; _lastD2 = d2;

    // mark strong BEFORE any early return (fixes the dead branch)
    if (passThr && passSep && (d1 < thr * 0.82) && ((d2 - d1) > (sepAbs * 1.5))) {
      lastDecisionIsStrong = true;
      // We still fall through to your ACCEPT path below
    }

    debugPrint('[MATCH] best=$bestId d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} '
        'Δ=${(d2-d1).toStringAsFixed(3)} thr=$thr abs=$sepAbs ratio=$sepRatio '
        'passThr=$passThr passSep=$passSep good=$good bad=${bad}');
    debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');

    if (passThr && passSep) {
      await _logEvent({'event':'recognize','decision':'ACCEPT','bestId':bestId,'d1':d1,'d2':d2,
        'delta':d2-d1,'ratio': (d2>0? d1/d2:1.0),'good':good,'bad':bad});
      return bestId;
    }

    // ----- Stage 2 (borderline only): eye-aligned refinement -----
    final bool borderline = (passThr && !passSep) || (!passThr && d1 < thr * 1.10);
    if (borderline) {
      final aligned = await _getAlignedLiveEmbeddingFromXFile(liveImage);
      if (aligned != null) {
        final alignedLive = aligned.emb;

        double r1 = double.infinity, r2 = double.infinity;
        String? rid;
        List<double>? rBestEmb;

        for (final r in rows) {
          final raw = r['image_data'];
          if (raw is! String || raw.isEmpty) continue;
          try {
            final parsed = jsonDecode(raw);
            final Iterable<List<double>> vectors =
            (parsed is List && parsed.isNotEmpty && parsed.first is List)
                ? (parsed as List).map<List<double>>((v) => (v as List).map((e) => (e as num).toDouble()).toList())
                : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];

            for (final v in vectors) {
              if (v.length != alignedLive.length) continue;
              final stored = _l2Normalize(v);
              final d = _euclideanDistance(alignedLive, stored);
              if (d < r1) { r2 = r1; r1 = d; rid = r['employee_id'] as String?; rBestEmb = stored; }
              else if (d < r2) { r2 = d; }
            }
          } catch (_) {}
        }

        if (rid != null) {
          double thr2 = (thr >= 1.0) ? max(1.00, thr - 0.05) : max(0.36, thr - 0.02);
          final bool pass2 = (r1 < thr2) && ((r2 - r1) >= sepAbs);

          if (pass2) {
            _lastLiveEmb = alignedLive; _lastBestEmb = rBestEmb; _lastBestId = rid; _lastD1 = r1; _lastD2 = r2;
            lastDecisionIsStrong = lastDecisionIsStrong || (r1 < thr2 * 0.88 && (r2 - r1) > sepAbs * 1.3);
            await _logEvent({'event':'recognize','decision':'ACCEPT_REFINED','bestId':rid,'d1':r1,'d2':r2,'delta':r2-r1});
            return rid;
          }

          // Optional: fuse with shape (only if gallery stores shape)
          if (aligned.shape != null) {
            try {
              final row = rows.firstWhere((e) => (e['employee_id'] as String?) == rid, orElse: () => {});
              final raw = row['image_data'];
              double? bestShapeDist;
              if (raw is String && raw.isNotEmpty) {
                final parsed = jsonDecode(raw);
                if (parsed is List && parsed.isNotEmpty) {
                  for (final item in parsed) {
                    if (item is Map && item['shape'] is List) {
                      final s = (item['shape'] as List).map((e) => (e as num).toDouble()).toList();
                      if (s.length == 10) {
                        final ds = _shapeDistance(aligned.shape!, s);
                        bestShapeDist = (bestShapeDist == null) ? ds : min(bestShapeDist!, ds);
                      }
                    }
                  }
                }
              }
              if (bestShapeDist != null) {
                const double W_EMB = 0.75, W_SHAPE = 0.25;
                final fused1 = W_EMB * r1 + W_SHAPE * bestShapeDist!;
                final fused2 = W_EMB * r2; // second-best has no shape fusion
                const double FUSED_THR = 0.95;
                const double FUSED_MARGIN = 0.08;
                final passFused = (fused1 < FUSED_THR) && ((fused2 - fused1) >= FUSED_MARGIN);
                if (passFused) {
                  _lastLiveEmb = alignedLive; _lastBestEmb = rBestEmb; _lastBestId = rid; _lastD1 = r1; _lastD2 = r2;
                  lastDecisionIsStrong = true;
                  await _logEvent({'event':'recognize','decision':'ACCEPT_FUSED','bestId':rid,'d1':r1,'d2':r2,
                    'delta':r2-r1,'shape':bestShapeDist});
                  return rid;
                }
              }
            } catch (_) {}
          }
        }
      }
    }

    await _logEvent({'event':'recognize','decision':'REJECT',
      'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
      'bestId':bestId,'d1':d1,'d2':d2,'delta':d2-d1,
      'ratio': (d2>0? d1/d2:1.0),'good':good,'bad':bad});
    return null;
  }



  // Future<String?> recognizeFace(XFile liveImage) async {
  //   final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
  //   if (liveEmbedding == null) {
  //     await _logEvent({'event': 'recognize', 'reason': 'NO_LIVE_EMBEDDING'});
  //     return null;
  //   }
  //   _lastLiveEmb = liveEmbedding;
  //   final dim = liveEmbedding.length;
  //   debugPrint('[LIVE] embedding dim=$dim');
  //
  //   final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
  //   if (allProfiles.isEmpty) {
  //     debugPrint('Database is empty. No faces to compare against.');
  //     await _logEvent({'event': 'recognize', 'reason': 'EMPTY_GALLERY'});
  //     return null;
  //   }
  //
  //   // Thresholds tuned for L2-NORMALIZED 512-D float embeddings.
  //   // Start conservative to avoid wrong IDs. You can relax later after logs.
  //   const double THR      = 0.90;  // absolute max distance
  //   const double SEP_ABS  = 0.15;  // min gap d2 - d1
  //   const double SEP_RATIO= 0.85;  // d1/d2 <= 0.85
  //
  //   String? bestId;
  //   double d1 = double.infinity, d2 = double.infinity;
  //   int good = 0, bad = 0;
  //
  //   for (final profile in allProfiles) {
  //     final raw = profile['image_data'];
  //     if (raw is! String || raw.isEmpty) { bad++; continue; }
  //
  //     try {
  //       final parsed = jsonDecode(raw);
  //
  //       final Iterable<List<double>> vectors =
  //       (parsed is List && parsed.isNotEmpty && parsed.first is List)
  //           ? (parsed as List).map<List<double>>(
  //               (v) => (v as List).map((e) => (e as num).toDouble()).toList())
  //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
  //
  //       for (final vec in vectors) {
  //         if (vec.length != dim) { bad++; continue; }
  //
  //         // Defensive L2 on stored vectors in case legacy rows weren’t normalized
  //         final stored = _l2Normalize(vec);
  //
  //         // Optional: reject degenerate templates (too sparse)
  //         final nonZero = stored.where((x) => x.abs() > 1e-6).length / stored.length;
  //         if (nonZero < 0.1) { bad++; continue; } // ~10% non-zeros min
  //
  //         final d = _euclideanDistance(liveEmbedding, stored);
  //         if (d < d1) {
  //           d2 = d1; d1 = d;
  //           bestId = profile['employee_id'] as String?;
  //           _lastBestEmb = stored;
  //         } else if (d < d2) {
  //           d2 = d;
  //         }
  //         good++;
  //       }
  //     } catch (_) { bad++; }
  //   }
  //
  //   if (bestId == null) {
  //     await _logEvent({'event': 'recognize', 'reason': 'NO_VALID_VECTORS', 'good': good, 'bad': bad});
  //     return null;
  //   }
  //
  //   final bool passThr   = d1 < THR;
  //   final bool passSep   = ((d2 - d1) >= SEP_ABS) || (d2 > 0 && (d1 / d2) <= SEP_RATIO);
  //
  //   debugPrint('[MATCH] best=$bestId d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} '
  //       'Δ=${(d2-d1).toStringAsFixed(3)} thr=$THR abs=$SEP_ABS ratio=$SEP_RATIO '
  //       'passThr=$passThr passSep=$passSep good=$good bad=$bad');
  //
  //   _lastBestId = bestId;
  //   _lastD1 = d1;
  //   _lastD2 = d2;
  //   debugPrint('[EMB] live[0:8]=${_sample(_lastLiveEmb, 8)} best[0:8]=${_sample(_lastBestEmb, 8)} id=$bestId');
  //
  //   if (passThr && passSep) {
  //     await _logEvent({
  //       'event': 'recognize',
  //       'decision': 'ACCEPT',
  //       'bestId': bestId,
  //       'd1': d1, 'd2': d2,
  //       'delta': d2 - d1,
  //       'ratio': (d2 > 0 ? d1 / d2 : 1.0),
  //       'good': good, 'bad': bad,
  //     });
  //     return bestId;
  //   }
  //
  //   await _logEvent({
  //     'event': 'recognize',
  //     'decision': 'REJECT',
  //     'reason': passThr ? 'LOW_MARGIN' : 'ABOVE_THRESHOLD',
  //     'bestId': bestId,
  //     'd1': d1, 'd2': d2,
  //     'delta': d2 - d1,
  //     'ratio': (d2 > 0 ? d1 / d2 : 1.0),
  //     'good': good, 'bad': bad,
  //   });
  //   return null;
  // }


  // Future<String?> recognizeFace(XFile liveImage) async {
  //   // 1) Live probe (already L2 in your pipeline)
  //   final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
  //   if (liveEmbedding == null) {
  //     debugPrint("Could not generate embedding from live image.");
  //     return null;
  //   }
  //   // 👉 ADD THESE TWO LINES HERE
  //   final dim = liveEmbedding.length;
  //   debugPrint('[LIVE] embedding dim=$dim');
  //   // 👈
  //
  //   // 2) Gallery
  //   final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
  //   if (allProfiles.isEmpty) {
  //     debugPrint('Database is empty. No faces to compare against.');
  //     return null;
  //   }
  //
  //   // # 3) clear attributes & delete build caches
  //   // attrib -R -S -H .\build\* /S /D 2>$null
  //   // Remove-Item -Recurse -Force .\build, .\android\app\build, .\.dart_tool -ErrorAction SilentlyContinue
  //   //
  //   // # 4) fresh resolve & run
  //   // flutter pub get
  //   // flutter runTunables for 512-D L2 embeddings (your model outputs 512 dims)
  //   final double threshold = (dim >= 512) ? 1.0 : 0.75; // keep generous at first
  //   const double margin = 0.02;                      // was ~0.20–0.25 → too strict for your data
  //   const double ratioThr  = 0.985;                      // new: ratio-based fallback (d1/d2 ≤ 0.985)
  //
  //   String? bestId;
  //   double d1 = double.infinity, d2 = double.infinity;
  //
  //   for (final profile in allProfiles) {
  //     final raw = profile['image_data'];
  //     if (raw is! String || raw.isEmpty) continue;
  //
  //     try {
  //       final parsed = jsonDecode(raw);
  //
  //       // Support both single template [..] and multi-template [[..],[..],..]
  //       final Iterable<List<double>> vectors = (parsed is List && parsed.isNotEmpty && parsed.first is List)
  //           ? (parsed as List).map<List<double>>((v) => (v as List).map((e) => (e as num).toDouble()).toList())
  //           : [ (parsed as List).map((e) => (e as num).toDouble()).toList() ];
  //
  //       for (final vec in vectors) {
  //         // Defensive L2 on stored vectors
  //         final stored = _l2Normalize(vec);
  //         final d = _euclideanDistance(liveEmbedding, stored);
  //         if (d < d1) { d2 = d1; d1 = d; bestId = profile['employee_id'] as String?; }
  //         else if (d < d2) { d2 = d; }
  //       }
  //     } catch (_) {
  //       // skip malformed rows
  //       continue;
  //     }
  //   }
  //
  //
  //
  //
  //   if (bestId == null) return null;
  //
  //   final bool passThr = d1 < threshold;
  //   final bool passSep   = ((d2 - d1) >= margin) || (d2 > 0 && (d1 / d2) <= ratioThr);
  //   debugPrint('[MATCH] d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} Δ=${(d2-d1).toStringAsFixed(3)} '
  //       'passThr=${d1 < threshold} passMar=${(d2 - d1) >= margin} bestId=$bestId');
  //
  //   if (passThr && passSep) {
  //     debugPrint('✅ Matched $bestId | d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} Δ=${(d2-d1).toStringAsFixed(3)}');
  //     return bestId;
  //   } else {
  //     debugPrint('❌ Unknown | d1=${d1.toStringAsFixed(3)} d2=${d2.toStringAsFixed(3)} Δ=${(d2-d1).toStringAsFixed(3)}');
  //     return null; // Unknown; your K-of-N gate will suppress punches
  //   }
  //
  // }


  /// Calculates the Euclidean distance between two embeddings.
  double _euclideanDistance(List<double> e1, List<double> e2) {
    double s = 0.0;
    for (int i = 0; i < e1.length; i++) {
      final double d = e1[i] - e2[i];
      s += d * d;
    }
    return sqrt(s);
  }

  // double _euclideanDistance(List<double> e1, List<double> e2) {
  //   double sum = 0.0;
  //   for (int i = 0; i < e1.length; i++) {
  //     sum += pow(e1[i] - e2[i], 2);
  //   }
  //   return sqrt(sum);
  // }

  /// Disposes of the resources used by the service.
  void dispose() {
    _faceDetector.close();
    _liveDetector.close(); // <-- add
    _interpreter.close();
  }
}






// and let me know if there is also a possiblity of adding a functionality of printing the messag eon the screen while user trying to to capture that os poor lighting, blurry, side angle as per the situation .



// import 'dart:convert';
// import 'dart:io' as io;
//
// import 'dart:math';
//
// import 'package:camera/camera.dart';
// import 'package:flutter/foundation.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:image/image.dart' as img;
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:tflite_flutter/tflite_flutter.dart';
//
// class FaceRecognitionService {
//   late Interpreter _interpreter;
//   final FaceDetector _faceDetector = FaceDetector(
//     options: FaceDetectorOptions(
//       performanceMode: FaceDetectorMode.accurate,
//     ),
//   );
//
//   FaceRecognitionService() {
//     _loadModel();
//   }
//
//   /// Loads the TFLite model from assets.
//   Future<void> _loadModel() async {
//     try {
//       _interpreter = await Interpreter.fromAsset('assets/facenet.tflite');
//       debugPrint('✅ FaceNet model loaded successfully.');
//     } catch (e) {
//       debugPrint('❌ Failed to load FaceNet model: $e');
//     }
//   }
//
//   /// **Use this during employee registration.**
//   /// Takes a Base64 image string, computes the face embedding, and returns it.
//   Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
//     try {
//       final Uint8List imageBytes = base64Decode(base64.normalize(base64Image));
//       return await _processImageBytes(imageBytes);
//     } on FormatException catch (e) {
//       debugPrint("❌ Invalid Base64 string provided: ${e.message}");
//       return null;
//     } catch (e) {
//       debugPrint("❌ An error occurred during registration embedding: $e");
//       return null;
//     }
//   }
//
//   /// **Use this for live face recognition.**
//   /// Takes a live image from the camera and computes the face embedding.
//   Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
//     try {
//       final imageBytes = await imageFile.readAsBytes();
//       return await _processImageBytes(imageBytes);
//     } catch (e) {
//       debugPrint("❌ An error occurred during live image embedding: $e");
//       return null;
//     }
//   }
//
//   /// Centralized function to process image bytes (from Base64 or XFile).
//   Future<List<double>?> _processImageBytes(Uint8List imageBytes) async {
//     io.File? tempFile;
//     try {
//       // Decode image to use with the 'image' package for cropping
//       final originalImage = img.decodeImage(imageBytes);
//       if (originalImage == null) {
//         debugPrint('❌ Failed to decode image bytes for cropping.');
//         return null;
//       }
//
//       // --- ROBUST FIX: Use a temporary file for ML Kit ---
//       // 1. Save the image bytes to a temporary file
//       final tempDir = await getTemporaryDirectory();
//       tempFile = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tempFile.writeAsBytes(imageBytes, flush: true);
//
//       // 2. Create InputImage from the file path
//       final inputImage = InputImage.fromFilePath(tempFile.path);
//
//       // 3. Process the image
//       final faces = await _faceDetector.processImage(inputImage);
//
//       if (faces.isEmpty) {
//         debugPrint('No face detected in the image.');
//         return null;
//       }
//
//       debugPrint('✅ Face detected successfully!');
//       // Crop the face and get the embedding
//       final croppedFace = _cropFace(originalImage, faces.first);
//       return _getEmbeddingFromImage(croppedFace);
//
//     } catch (e) {
//       debugPrint("❌ Error in _processImageBytes: $e");
//       return null;
//     } finally {
//       // 4. Clean up the temporary file
//       await tempFile?.delete();
//     }
//   }
//
//   /// Crops the face from the full image.
//   img.Image _cropFace(img.Image originalImage, Face face) {
//     final boundingBox = face.boundingBox;
//     return img.copyCrop(
//       originalImage,
//       x: boundingBox.left.toInt(),
//       y: boundingBox.top.toInt(),
//       width: boundingBox.width.toInt(),
//       height: boundingBox.height.toInt(),
//     );
//   }
//
//   /// Prepares the cropped face and runs the TFLite model to get the embedding.
//   List<double> _getEmbeddingFromImage(img.Image image) {
//     final resizedImage = img.copyResize(image, width: 160, height: 160);
//
//     // --- FIX FOR QUANTIZED MODEL ---
//     // Create a Uint8List to hold the raw pixel data for the quantized model.
//     final imageBytes = Uint8List(1 * 160 * 160 * 3);
//     int pixelIndex = 0;
//
//     // Iterate over the pixels and store their raw RGB integer values.
//     for (int y = 0; y < 160; y++) {
//       for (int x = 0; x < 160; x++) {
//         final pixel = resizedImage.getPixel(x, y);
//         imageBytes[pixelIndex++] = pixel.r.toInt();
//         imageBytes[pixelIndex++] = pixel.g.toInt();
//         imageBytes[pixelIndex++] = pixel.b.toInt();
//       }
//     }
//
//     // Reshape the flat list into the format [1, 160, 160, 3] required by the model.
//     final input = imageBytes.reshape([1, 160, 160, 3]);
//
//     // The output buffer should also be integer-based for a quantized model.
//     final output = List.filled(1 * 512, 0).reshape([1, 512]);
//
//     _interpreter.run(input, output);
//
//     // Convert the integer output from the model to a List<double> for distance calculation.
//     final embedding = (output[0] as List<int>).map((e) => e.toDouble()).toList();
//
//     return embedding;
//   }
//
//   /// Recognizes a face by comparing its live embedding to stored profiles.
//   Future<String?> recognizeFace(XFile liveImage) async {
//     final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
//     if (liveEmbedding == null) {
//       debugPrint("Could not generate embedding from live image.");
//       return null;
//     }
//
//     final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
//     if (allProfiles.isEmpty) {
//       debugPrint('Database is empty. No faces to compare against.');
//       return null;
//     }
//
//     double minDistance = double.infinity;
//     String? matchedEmployeeId;
//
//     for (var profile in allProfiles) {
//       if (profile['image_data'] != null && profile['image_data'] is String) {
//         try {
//           final storedEmbedding = (jsonDecode(profile['image_data'] as String) as List).cast<double>();
//           final distance = _euclideanDistance(liveEmbedding, storedEmbedding);
//
//           if (distance < minDistance) {
//             minDistance = distance;
//             matchedEmployeeId = profile['employee_id'] as String?;
//           }
//         } on FormatException {
//           debugPrint("Skipping profile for ${profile['employee_id']} due to invalid embedding format.");
//           continue;
//         }
//       }
//     }
//
//     // --- THE FIX IS HERE ---
//     // Increased the threshold to a more reasonable value for quantized models.
//     // const double recognitionThreshold = 350.0;
//     const double recognitionThreshold = 450.0;
//     if (minDistance < recognitionThreshold) {
//       debugPrint('✅ Face matched with Employee ID: $matchedEmployeeId, Distance: $minDistance');
//       return matchedEmployeeId;
//     } else {
//       debugPrint('❌ No match found. Minimum distance: $minDistance');
//       return null;
//     }
//   }
//
//   /// Calculates the Euclidean distance between two embeddings.
//   double _euclideanDistance(List<double> e1, List<double> e2) {
//     double sum = 0.0;
//     for (int i = 0; i < e1.length; i++) {
//       sum += pow(e1[i] - e2[i], 2);
//     }
//     return sqrt(sum);
//   }
//
//   void dispose() {
//     _faceDetector.close();
//     _interpreter.close();
//   }
// }
//
// import 'dart:convert';
// import 'dart:io' as io;
// import 'dart:math';
// import 'package:camera/camera.dart';
// import 'package:flutter/foundation.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:image/image.dart' as img;
// import 'package:kiosk/app/core/services/database_service.dart'; // Assuming this is your database service
// import 'package:path_provider/path_provider.dart';
// import 'package:tflite_flutter/tflite_flutter.dart';
//
// class FaceRecognitionService {
//   late Interpreter _interpreter;
//   final FaceDetector _faceDetector = FaceDetector(
//     options: FaceDetectorOptions(
//       performanceMode: FaceDetectorMode.accurate,
//     ),
//   );
//
//   FaceRecognitionService() {
//     _loadModel();
//   }
//
//   /// Loads the TFLite model from assets.
//   Future<void> _loadModel() async {
//     try {
//       _interpreter = await Interpreter.fromAsset('assets/facenet.tflite');
//       debugPrint('✅ FaceNet model loaded successfully.');
//     } catch (e) {
//       debugPrint('❌ Failed to load FaceNet model: $e');
//     }
//   }
//
//   /// **Use this during employee registration.**
//   /// Takes a Base64 image string, computes the face embedding, and returns it.
//   Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
//     try {
//       final Uint8List imageBytes = base64Decode(base64.normalize(base64Image));
//       return await _processImageBytes(imageBytes);
//     } on FormatException catch (e) {
//       debugPrint("❌ Invalid Base64 string provided: ${e.message}");
//       return null;
//     } catch (e) {
//       debugPrint("❌ An error occurred during registration embedding: $e");
//       return null;
//     }
//   }
//
//   /// **Use this for live face recognition.**
//   /// Takes a live image from the camera and computes the face embedding.
//   Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
//     try {
//       final imageBytes = await imageFile.readAsBytes();
//       return await _processImageBytes(imageBytes);
//     } catch (e) {
//       debugPrint("❌ An error occurred during live image embedding: $e");
//       return null;
//     }
//   }
//
//   /// Centralized function to process image bytes (from Base64 or XFile).
//   Future<List<double>?> _processImageBytes(Uint8List imageBytes) async {
//     io.File? tempFile;
//     try {
//       // Decode image to use with the 'image' package for cropping
//       final originalImage = img.decodeImage(imageBytes);
//       if (originalImage == null) {
//         debugPrint('❌ Failed to decode image bytes for cropping.');
//         return null;
//       }
//
//       // --- Use a temporary file for ML Kit for better reliability ---
//       final tempDir = await getTemporaryDirectory();
//       tempFile = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tempFile.writeAsBytes(imageBytes, flush: true);
//
//       final inputImage = InputImage.fromFilePath(tempFile.path);
//       final faces = await _faceDetector.processImage(inputImage);
//
//       if (faces.isEmpty) {
//         debugPrint('No face detected in the image.');
//         return null;
//       }
//
//       // --- FIX: Select the largest face if multiple are detected ---
//       Face selectedFace;
//       if (faces.length > 1) {
//         debugPrint("Multiple faces detected. Selecting the largest one.");
//         // Sort faces by the area of their bounding box in descending order
//         faces.sort((a, b) {
//           final aSize = a.boundingBox.width * a.boundingBox.height;
//           final bSize = b.boundingBox.width * b.boundingBox.height;
//           return bSize.compareTo(aSize);
//         });
//         selectedFace = faces.first; // The largest face is now the first in the list
//       } else {
//         selectedFace = faces.first; // Only one face was detected
//       }
//
//       debugPrint('✅ Face selected successfully! Cropping and processing.');
//       final croppedFace = _cropFace(originalImage, selectedFace); // Use the selected face
//       return _getEmbeddingFromImage(croppedFace);
//
//     } catch (e) {
//       debugPrint("❌ Error in _processImageBytes: $e");
//       return null;
//     } finally {
//       // Clean up the temporary file
//       await tempFile?.delete();
//     }
//   }
//
//   /// Crops the face from the full image.
//   img.Image _cropFace(img.Image originalImage, Face face) {
//     final boundingBox = face.boundingBox;
//     return img.copyCrop(
//       originalImage,
//       x: boundingBox.left.toInt(),
//       y: boundingBox.top.toInt(),
//       width: boundingBox.width.toInt(),
//       height: boundingBox.height.toInt(),
//     );
//   }
//
//   /// Prepares the cropped face and runs the TFLite model to get the embedding.
//   List<double> _getEmbeddingFromImage(img.Image image) {
//     final resizedImage = img.copyResize(image, width: 160, height: 160);
//
//     // Create a Uint8List to hold the raw pixel data for the quantized model.
//     final imageBytes = Uint8List(1 * 160 * 160 * 3);
//     int pixelIndex = 0;
//
//     // Iterate over the pixels and store their raw RGB integer values.
//     for (int y = 0; y < 160; y++) {
//       for (int x = 0; x < 160; x++) {
//         final pixel = resizedImage.getPixel(x, y);
//         imageBytes[pixelIndex++] = pixel.r.toInt();
//         imageBytes[pixelIndex++] = pixel.g.toInt();
//         imageBytes[pixelIndex++] = pixel.b.toInt();
//       }
//     }
//
//     // Reshape the flat list into the format [1, 160, 160, 3] required by the model.
//     final input = imageBytes.reshape([1, 160, 160, 3]);
//
//     // The output buffer should also be integer-based for a quantized model.
//     final output = List.filled(1 * 512, 0).reshape([1, 512]);
//
//     _interpreter.run(input, output);
//
//     // Convert the integer output from the model to a List<double> for distance calculation.
//     final embedding = (output[0] as List<int>).map((e) => e.toDouble()).toList();
//
//     return embedding;
//   }
//
//   /// Recognizes a face by comparing its live embedding to stored profiles.
//   Future<String?> recognizeFace(XFile liveImage) async {
//     final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
//     if (liveEmbedding == null) {
//       debugPrint("Could not generate embedding from live image.");
//       return null;
//     }
//
//     final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
//     if (allProfiles.isEmpty) {
//       debugPrint('Database is empty. No faces to compare against.');
//       return null;
//     }
//
//     double minDistance = double.infinity;
//     String? matchedEmployeeId;
//
//     for (var profile in allProfiles) {
//       if (profile['image_data'] != null && profile['image_data'] is String) {
//         try {
//           final storedEmbedding = (jsonDecode(profile['image_data'] as String) as List).cast<double>();
//           final distance = _euclideanDistance(liveEmbedding, storedEmbedding);
//
//           if (distance < minDistance) {
//             minDistance = distance;
//             matchedEmployeeId = profile['employee_id'] as String?;
//           }
//         } on FormatException {
//           debugPrint("Skipping profile for ${profile['employee_id']} due to invalid embedding format.");
//           continue;
//         }
//       }
//     }
//
//     // A reasonable threshold for quantized FaceNet models
//     const double recognitionThreshold = 550.0;
//     if (minDistance < recognitionThreshold) {
//       debugPrint('✅ Face matched with Employee ID: $matchedEmployeeId, Distance: $minDistance');
//       return matchedEmployeeId;
//     } else {
//       debugPrint('❌ No match found. Minimum distance: $minDistance');
//       return null;
//     }
//   }
//
//   /// Calculates the Euclidean distance between two embeddings.
//   double _euclideanDistance(List<double> e1, List<double> e2) {
//     double sum = 0.0;
//     for (int i = 0; i < e1.length; i++) {
//       sum += pow(e1[i] - e2[i], 2);
//     }
//     return sqrt(sum);
//   }
//
//   /// Disposes of the resources used by the service.
//   void dispose() {
//     _faceDetector.close();
//     _interpreter.close();
//   }
// }



// import 'dart:convert';
// import 'dart:typed_data';
// import 'dart:collection';
// import 'dart:io' as io;
// import 'dart:math';
// import 'package:camera/camera.dart';
// import 'package:flutter/foundation.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:image/image.dart' as img;
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:tflite_flutter/tflite_flutter.dart';
//
// class FaceRecognitionService {
//   // ---- Tunables (safe defaults; calibrate later) ----
//   static const double _threshold = 1.05;   // L2 distance threshold (128D FaceNet/MobileFaceNet start)
//   static const double _margin    = 0.25;   // top-2 separation margin
//
//   late Interpreter _interpreter;
//   final FaceDetector _faceDetector = FaceDetector(
//     options: FaceDetectorOptions(performanceMode: FaceDetectorMode.accurate),
//   );
//
//   FaceRecognitionService() { _loadModel(); }
//
//   // Loads the TFLite model from assets.
//   Future<void> _loadModel() async {
//     try {
//       _interpreter = await Interpreter.fromAsset('assets/facenet.tflite');
//       debugPrint('✅ FaceNet model loaded successfully.');
//     } catch (e) {
//       debugPrint('❌ Failed to load FaceNet model: $e');
//     }
//   }
//
//   // ---------- L2 normalization helpers ----------
//   List<double> _l2Normalize(List<double> v) {
//     double sum = 0.0; for (final x in v) sum += x * x;
//     final norm = sqrt(sum);
//     if (norm < 1e-12) return v;
//     return List<double>.generate(v.length, (i) => v[i] / norm);
//   }
//
//   Float32List _l2NormalizeF32(Float32List v) {
//     double sum = 0.0; for (final x in v) sum += x * x;
//     final norm = sqrt(sum <= 1e-12 ? 1e-12 : sum);
//     return Float32List.fromList(v.map((x) => x / norm).toList());
//   }
//
//   // ---------- Registration: returns L2-normalized embedding ----------
//   Future<List<double>?> getEmbeddingForRegistration(String base64Image) async {
//     try {
//       final cleaned = base64Image.split(',').last.trim(); // supports data URI
//       final Uint8List imageBytes = base64Decode(base64.normalize(cleaned));
//       final List<double>? rawEmbedding = await _processImageBytes(imageBytes);
//       if (rawEmbedding == null) return null;
//       return _l2Normalize(rawEmbedding); // enforce unit-norm
//     } on FormatException catch (e) {
//       debugPrint("❌ Invalid Base64 string provided: ${e.message}");
//       return null;
//     } catch (e) {
//       debugPrint("❌ An error occurred during registration embedding: $e");
//       return null;
//     }
//   }
//
//   // Live image -> embedding (L2-normalized; used by recognition)
//   Future<List<double>?> getEmbeddingFromLiveImage(XFile imageFile) async {
//     try {
//       final imageBytes = await imageFile.readAsBytes();
//       return await _processImageBytes(imageBytes); // already L2 (see _getEmbeddingFromImage)
//     } catch (e) {
//       debugPrint("❌ An error occurred during live image embedding: $e");
//       return null;
//     }
//   }
//
//   // ---------- Decode -> detect -> crop -> embed ----------
//   Future<List<double>?> _processImageBytes(Uint8List imageBytes) async {
//     io.File? tempFile;
//     try {
//       final originalImage = img.decodeImage(imageBytes);
//       if (originalImage == null) {
//         debugPrint('❌ Failed to decode image bytes for cropping.');
//         return null;
//       }
//
//       final tempDir = await getTemporaryDirectory();
//       tempFile = io.File('${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
//       await tempFile.writeAsBytes(imageBytes, flush: true);
//
//       final inputImage = InputImage.fromFilePath(tempFile.path);
//       final faces = await _faceDetector.processImage(inputImage);
//       if (faces.isEmpty) {
//         debugPrint('No face detected in the image.');
//         return null;
//       }
//
//       // Select largest face
//       Face selectedFace;
//       if (faces.length > 1) {
//         faces.sort((a, b) {
//           final aSize = a.boundingBox.width * a.boundingBox.height;
//           final bSize = b.boundingBox.width * b.boundingBox.height;
//           return bSize.compareTo(aSize);
//         });
//         selectedFace = faces.first;
//       } else {
//         selectedFace = faces.first;
//       }
//
//       // Safe crop (clamp bbox to image bounds to avoid exceptions)
//       final croppedFace = _safeCropFace(originalImage, selectedFace);
//       return _getEmbeddingFromImage(croppedFace); // returns L2-normalized
//     } catch (e) {
//       debugPrint("❌ Error in _processImageBytes: $e");
//       return null;
//     } finally {
//       await tempFile?.delete();
//     }
//   }
//
//   // Crop with bounds clamping
//   img.Image _safeCropFace(img.Image original, Face face) {
//     final bb = face.boundingBox;
//     final x = max(0, bb.left.floor());
//     final y = max(0, bb.top.floor());
//     final w = min(original.width - x, bb.width.ceil());
//     final h = min(original.height - y, bb.height.ceil());
//     final cw = max(1, w);
//     final ch = max(1, h);
//     return img.copyCrop(original, x: x, y: y, width: cw, height: ch);
//   }
//
//   // ---------- Model inference: returns L2-normalized embedding ----------
//   List<double> _getEmbeddingFromImage(img.Image image) {
//     // Resize to model input (your model uses 160x160x3)
//     final resizedImage = img.copyResize(image, width: 160, height: 160);
//
//     // Quantized uint8 input (as you had)
//     final imageBytes = Uint8List(1 * 160 * 160 * 3);
//     int idx = 0;
//     for (int y = 0; y < 160; y++) {
//       for (int x = 0; x < 160; x++) {
//         final p = resizedImage.getPixel(x, y);
//         imageBytes[idx++] = p.r.toInt();
//         imageBytes[idx++] = p.g.toInt();
//         imageBytes[idx++] = p.b.toInt();
//       }
//     }
//
//     // Run the interpreter
//     final input = imageBytes.reshape([1, 160, 160, 3]);
//     final output = List.filled(1 * 512, 0).reshape([1, 512]); // keep your current output shape
//     _interpreter.run(input, output);
//
//     // Convert to doubles and L2-normalize
//     final raw = (output[0] as List).map((e) => (e as num).toDouble()).toList();
//     return _l2Normalize(raw);
//   }
//
//   // ---------- Recognition with threshold + top-2 margin ----------
//   Future<String?> recognizeFace(XFile liveImage) async {
//     final liveEmbedding = await getEmbeddingFromLiveImage(liveImage);
//     if (liveEmbedding == null) {
//       debugPrint("Could not generate embedding from live image.");
//       return null;
//     }
//
//     final allProfiles = await DatabaseService.instance.getAllEmployeeProfiles();
//     if (allProfiles.isEmpty) {
//       debugPrint('Database is empty. No faces to compare against.');
//       return null;
//     }
//
//     // Find best and second-best L2 distances against stored (normalize stored defensively)
//     double best = double.infinity, second = double.infinity;
//     String? bestId;
//
//     for (final profile in allProfiles) {
//       final raw = profile['image_data'];
//       if (raw is! String || raw.isEmpty) continue;
//
//       try {
//         final List<dynamic> arr = jsonDecode(raw);
//         final stored = _l2Normalize(arr.map((e) => (e as num).toDouble()).toList());
//
//         final d = _euclideanDistance(liveEmbedding, stored);
//         if (d < best) { second = best; best = d; bestId = profile['employee_id'] as String?; }
//         else if (d < second) { second = d; }
//       } catch (_) {
//         // skip bad rows silently to avoid breaking flow
//         continue;
//       }
//     }
//
//     if (bestId == null) {
//       debugPrint('❌ No valid embeddings found to compare.');
//       return null;
//     }
//
//     // Gate with threshold + margin (DO NOT force a match)
//     final passThr = best < _threshold;
//     final passMar = (second - best) >= _margin;
//
//     if (passThr && passMar) {
//       debugPrint('✅ Matched $bestId | d1=$best, d2=$second (Δ=${(second - best).toStringAsFixed(3)})');
//       return bestId;
//     } else {
//       debugPrint('❌ Unknown | d1=$best, d2=$second (Δ=${(second - best).toStringAsFixed(3)})');
//       return null;
//     }
//   }
//
//   // Euclidean distance for L2-normalized vectors
//   double _euclideanDistance(List<double> e1, List<double> e2) {
//     double sum = 0.0;
//     final n = min(e1.length, e2.length);
//     for (int i = 0; i < n; i++) {
//       final d = e1[i] - e2[i];
//       sum += d * d;
//     }
//     return sqrt(sum);
//   }
//
//   void dispose() {
//     _faceDetector.close();
//     _interpreter.close();
//   }
// }


