// import 'dart:async';
// import 'package:intl/intl.dart';
// import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';
//
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models/punch_event.dart';
// import '../../core/models/timesheet.dart';
// import 'home_screen.dart';
//
// // /// Put this class near the top of punch_camera_screen.dart (or in a utils file)
// class ConsensusGate {
//   final int N, K;
//   final Duration cooldown;
//
//   DateTime _lastCommit = DateTime.fromMillisecondsSinceEpoch(0);
//   final List<String?> _win = [];
//
//   ConsensusGate({
//     this.N = 7,
//     this.K = 5,
//     this.cooldown = const Duration(seconds: 4),
//   });
//
//   bool get inCooldown => DateTime.now().difference(_lastCommit) < cooldown;
//
//   String? push(String? candidate) {
//     if (candidate == null || inCooldown) return null;
//     _win.add(candidate);
//     if (_win.length > N) _win.removeAt(0);
//
//
//     final c = _win.where((x) => x == candidate).length;
//     if (c >= K) {
//       _lastCommit = DateTime.now();
//       _win.clear();
//       return candidate;
//     }
//     return null;
//   }
// }
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen>
// {
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//
//   // after:
//   final ConsensusGate _gate = ConsensusGate(N: 7, K: 5, cooldown: const Duration(seconds: 4));
//   bool _captureBusy = false; // NEW
//
//
//   final FaceRecognitionService _faceRecognitionService =
//   FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//
//   bool _isProcessing = false;
//   bool _isClosing = false; // prevents double-dispose
//
//
//   @override
//   void initState() {
//     super.initState();
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     _cameraController?.dispose();
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _teardownCamera() async {
//     if (_isClosing) return;
//     _isClosing = true;
//     try {
//       final c = _cameraController;
//       if (c != null) {
//         // If you ever enable image stream, always stop it first
//         if (c.value.isInitialized && c.value.isStreamingImages) {
//           try { await c.stopImageStream(); } catch (_) {}
//         }
//         try { await c.dispose(); } catch (_) {}
//       }
//     } finally {
//       _cameraController = null;
//       _isClosing = false;
//     }
//   }
//
//   /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
//   Future<void> _showOverlayThenGoHome({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // 2) make sure camera surfaces are gone (prevents a black preview underneath)
//     await _teardownCamera();
//
//     // 3) show result overlay
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId, // printed on success
//     );
//
//     if (!mounted) return;
//
//     // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
//     Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
//       MaterialPageRoute(builder: (_) => const HomeScreen()),
//           (route) => false,
//     );
//   }
//
//
//   Future<void> _initializeCamera() async {
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.medium,
//         enableAudio: false,
//       );
//
//       await _cameraController!.initialize();
//
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error initializing camera: $e');
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//       }
//     }
//   }
//
//   /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC ---
//   Future<void> _takePictureAndProcess() async {
//     // ---- hard guards FIRST (prevents overlapping calls) ----
//     if (_captureBusy ||
//         _isProcessing ||
//         _cameraController == null ||
//         !_cameraController!.value.isInitialized) {
//       return;
//     }
//     _captureBusy = true;                    // acquire
//     setState(() => _isProcessing = true);   // show overlay
//
//     final started = DateTime.now();
//     const totalBudget = Duration(seconds: 4);
//     const interFrame  = Duration(milliseconds: 200);
//
//     try {
//       String? committedId;
//
//       // keep capturing until consensus or time budget is exhausted
//       while (committedId == null &&
//           DateTime.now().difference(started) < totalBudget) {
//
//         // 1) still capture (PAUSE → takePicture → RESUME)
//         await _cameraController!.pausePreview();
//         XFile image;
//         try {
//           image = await _cameraController!.takePicture();
//         } finally {
//           try { await _cameraController!.resumePreview(); } catch (_) {}
//         }
//
//         // 2) recognize
//         String? candidate = await _faceRecognitionService.recognizeFace(image);
//
//         // 3) one-shot retry if we still have time
//         if (candidate == null) {
//           const retryDelay = Duration(milliseconds: 250);
//           if (DateTime.now().difference(started) + retryDelay < totalBudget) {
//             await Future.delayed(retryDelay);
//
//             // PAUSE → takePicture (retry) → RESUME
//             await _cameraController!.pausePreview();
//             XFile retry;
//             try {
//               retry = await _cameraController!.takePicture();
//             } finally {
//               try { await _cameraController!.resumePreview(); } catch (_) {}
//             }
//
//             candidate = await _faceRecognitionService.recognizeFace(retry);
//           }
//         }
//
//         // 4) vote into consensus window
//         committedId = _gate.push(candidate);
//
//         // brief spacing between frames (but don't exceed time budget)
//         if (committedId == null) {
//           final elapsed = DateTime.now().difference(started);
//           if (elapsed + interFrame >= totalBudget) break;
//           await Future.delayed(interFrame);
//         }
//       }
//
//       // No consensus within budget → soft fail and exit via overlay
//       if (committedId == null) {
//         _showErrorMessage('Authentication inconclusive—hold steady and try again.');
//         await _showOverlayThenExit(success: false, when: DateTime.now());
//         return;
//       }
//
//       // ===== existing punch logic (unchanged) =====
//       final employeeId = committedId;
//       final position = await _getCurrentLocation();
//
//       final punchEvent = PunchEvent(
//         employeeId: employeeId,
//         eventTime: DateTime.now(),
//         punchType: widget.punchType,
//         status: 'VALID',
//         deviceId: 'KIOSK01',
//         latitude: position?.latitude,
//         longitude: position?.longitude,
//       );
//
//       await _faceRecognitionService.logPunchDecision(
//         widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//         employeeId: employeeId,
//       );
//
//       final connectivityResult = await Connectivity().checkConnectivity();
//       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//           connectivityResult.contains(ConnectivityResult.wifi);
//
//       if (isOnline) {
//         final timesheet = Timesheet(
//           employeeId: punchEvent.employeeId,
//           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//           punchEvents: [
//             PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!),
//           ],
//         );
//
//         final success = await _apiService.sendBulkTimsheets([timesheet]);
//
//         if (success) {
//           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//           await _showOverlayThenExit(
//             success: true,
//             when: punchEvent.eventTime,
//             employeeId: employeeId,
//           );
//           return;
//         } else {
//           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//           await _showOverlayThenExit(
//             success: true,
//             when: punchEvent.eventTime,
//             employeeId: employeeId,
//           );
//           return;
//         }
//       } else {
//         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//         await _showOverlayThenExit(
//           success: true,
//           when: punchEvent.eventTime,
//           employeeId: employeeId,
//         );
//         return;
//       }
//       // ===== end unchanged logic =====
//     } catch (e) {
//       // keep your logging + graceful exit
//       // ignore: avoid_print
//       print('Error during face recognition or punch processing: $e');
//       _showErrorMessage('An error occurred. Please try again.');
//       await _showOverlayThenExit(success: false, when: DateTime.now());
//     } finally {
//       // ---- ALWAYS release busy flag, even on early returns/errors ----
//       _captureBusy = false;
//     }
//   }
//
//
//
//
//   // void _takePictureAndProcess() async {
//   //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
//   //   setState(() => _isProcessing = true);
//   //
//   //
//   //   try {
//   //     final image = await _cameraController!.takePicture();
//   //
//   //     var employeeId = await _faceRecognitionService.recognizeFace(image);
//   //     if (employeeId == null) {
//   //       await Future.delayed(const Duration(milliseconds: 250));
//   //       final retry = await _cameraController!.takePicture();
//   //       employeeId = await _faceRecognitionService.recognizeFace(retry);
//   //     }
//   //
//   //     if (employeeId != null) {
//   //       final position = await _getCurrentLocation();
//   //
//   //       final punchEvent = PunchEvent(
//   //         employeeId: employeeId,
//   //         eventTime: DateTime.now(),
//   //         punchType: widget.punchType,
//   //         status: 'VALID',
//   //         deviceId: 'KIOSK01', // Example device ID
//   //         latitude: position?.latitude,
//   //         longitude: position?.longitude,
//   //       );
//   //
//   //       await _faceRecognitionService.logPunchDecision(
//   //         widget.punchType.toString(),
//   //         employeeId: employeeId,
//   //       );
//   //
//   //
//   //       final connectivityResult = await Connectivity().checkConnectivity();
//   //       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//   //           connectivityResult.contains(ConnectivityResult.wifi);
//   //
//   //       if (isOnline) {
//   //         // Try direct sync
//   //         // ignore: avoid_print
//   //         print('Device is online. Attempting to send punch event directly.');
//   //
//   //         final timesheet = Timesheet(
//   //           employeeId: punchEvent.employeeId,
//   //           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//   //           punchEvents: [
//   //             PunchEventPayload.fromPunchEvent(
//   //               punchEvent,
//   //               punchEvent.deviceId!,
//   //             ),
//   //           ],
//   //         );
//   //
//   //         await _faceRecognitionService.logPunchDecision(
//   //           widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
//   //           employeeId: employeeId,
//   //         );
//   //
//   //         final success = await _apiService.sendBulkTimsheets([timesheet]);
//   //
//   //         if (success) {
//   //           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         } else {
//   //           // Fallback to queue
//   //           // ignore: avoid_print
//   //           print("Direct sync failed. Queuing punch event for later.");
//   //           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
//   //           await _showOverlayThenExit(
//   //             success: true,
//   //             when: punchEvent.eventTime,
//   //             employeeId: employeeId,
//   //           );
//   //           return;
//   //
//   //         }
//   //       } else {
//   //         // Offline: queue it
//   //         // ignore: avoid_print
//   //         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//   //         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
//   //         await _showOverlayThenExit(
//   //           success: true,
//   //           when: punchEvent.eventTime,
//   //           employeeId: employeeId,
//   //         );
//   //         return;
//   //
//   //       }
//   //     } else {
//   //       _showErrorMessage('Authentication Failed. Please try again.');
//   //       await _showOverlayThenExit(
//   //         success: false,
//   //         when: DateTime.now(),
//   //       );
//   //       return;
//   //     }
//   //   } catch (e) {
//   //     // ignore: avoid_print
//   //     print('Error during face recognition or punch processing: $e');
//   //     _showErrorMessage('An error occurred. Please try again.');
//   //     await _showOverlayThenExit(
//   //       success: false,
//   //       when: DateTime.now(),
//   //     );
//   //     return;
//   //   }
//   //   // finally {
//   //   //   if (mounted) {
//   //   //     Navigator.of(context).pop();
//   //   //   }
//   //   // }
//   // }
//
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       final serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         // ignore: avoid_print
//         print('Location services are disabled.');
//         return null;
//       }
//
//       var permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           // ignore: avoid_print
//           print('Location permission denied.');
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         // ignore: avoid_print
//         print('Location permissions are permanently denied.');
//         return null;
//       }
//
//       return Geolocator.getCurrentPosition();
//     } catch (e) {
//       // ignore: avoid_print
//       print('Error getting location: $e');
//       return null;
//     }
//   }
//
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message),
//       ),
//     );
//   }
//
//
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message),
//       ),
//     );
//   }
//   Future<void> _showOverlayThenExit({
//     required bool success,
//     required DateTime when,
//     String? employeeId,
//   }) async {
//     if (!mounted) return;
//     // 1) remove the black processing mask so the dialog is visible
//     setState(() => _isProcessing = false);
//
//     // Make sure your black processing veil is gone so the overlay is visible
//     // if (mounted) setState(() => _isProcessing = false);
//
//     // Map your existing punch type to the overlay enum
//     final kind = (widget.punchType.toString().toLowerCase().contains('out'))
//         ? PunchResultKind.outPunch
//         : PunchResultKind.inPunch;
//
//     await showPunchResult(
//       context,
//       success: success,
//       kind: kind,
//       punchedAt: when,
//       employeeId: employeeId,
//     );
//
//     if (!mounted) return;
//     // 4) go back to Home (first route). If you use named routes, adjust to your home route.
//     Navigator.of(context).popUntil((route) => route.isFirst);// return to previous screen AFTER overlay closes
//   }
//
//
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(child: CameraPreview(_cameraController!))
//           else
//             const Center(child: CircularProgressIndicator()),
//
//           // Capture button
//           Positioned(
//             bottom: 40,
//             child: FloatingActionButton(
//               onPressed: _isProcessing ? null : _takePictureAndProcess,
//               backgroundColor:
//               _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
//               child: const Icon(Icons.camera_alt),
//             ),
//           ),
//
//           // Processing overlay
//           if (_isProcessing)
//             Positioned.fill(
//               child: Container(
//                 color: Colors.black.withOpacity(0.5),
//                 child: const Center(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       CircularProgressIndicator(),
//                       SizedBox(height: 16),
//                       Text(
//                         'Recognizing face...',
//                         style: TextStyle(color: Colors.white, fontSize: 16),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }

//older version
// lib/app/presentation/screens/punch_camera_screen.dart
import 'dart:async';
import 'package:intl/intl.dart';
import 'package:kiosk/app/presentation/screens/punch_result_screen.dart';

import 'package:camera/camera.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'package:kiosk/app/core/services/api_service.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:kiosk/app/core/services/face_recognition_service.dart';

import '../../core/models/punch_event.dart';
import '../../core/models/timesheet.dart';
import 'home_screen.dart';

// /// Put this class near the top of punch_camera_screen.dart (or in a utils file)
class ConsensusGate {
  final int N, K;
  final Duration cooldown;

  DateTime _lastCommit = DateTime.fromMillisecondsSinceEpoch(0);
  final List<String?> _win = [];

  ConsensusGate({
    this.N = 7,
    this.K = 5,
    this.cooldown = const Duration(seconds: 4),
  });

  bool get inCooldown => DateTime.now().difference(_lastCommit) < cooldown;

  String? push(String? candidate) {
    _win.add(candidate);
    if (_win.length > N) _win.removeAt(0);

    if (candidate == null || inCooldown) return null;

    final c = _win.where((x) => x == candidate).length;
    if (c >= K) {
      _lastCommit = DateTime.now();
      _win.clear();
      return candidate;
    }
    return null;
  }
}

class PunchCameraScreen extends StatefulWidget {
  final PunchType punchType;

  const PunchCameraScreen({super.key, required this.punchType});

  @override
  State<PunchCameraScreen> createState() => _PunchCameraScreenState();
}

class _PunchCameraScreenState extends State<PunchCameraScreen>
{
  CameraController? _cameraController;
  bool _isCameraInitialized = false;

  // after:
  final ConsensusGate _gate = ConsensusGate(N: 5, K: 3, cooldown: const Duration(seconds: 4));

  final FaceRecognitionService _faceRecognitionService =
  FaceRecognitionService();
  final ApiService _apiService = ApiService();

  bool _isProcessing = false;
  bool _isClosing = false; // prevents double-dispose


  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    _faceRecognitionService.dispose();
    super.dispose();
  }

  Future<void> _teardownCamera() async {
    if (_isClosing) return;
    _isClosing = true;
    try {
      final c = _cameraController;
      if (c != null) {
        // If you ever enable image stream, always stop it first
        if (c.value.isInitialized && c.value.isStreamingImages) {
          try { await c.stopImageStream(); } catch (_) {}
        }
        try { await c.dispose(); } catch (_) {}
      }
    } finally {
      _cameraController = null;
      _isClosing = false;
    }
  }

  /// Show the overlay (green/red), then go to Home no matter what the stack looks like.
  Future<void> _showOverlayThenGoHome({
    required bool success,
    required DateTime when,
    String? employeeId,
  }) async {
    if (!mounted) return;

    // 1) remove the black processing mask so the dialog is visible
    setState(() => _isProcessing = false);

    // 2) make sure camera surfaces are gone (prevents a black preview underneath)
    await _teardownCamera();

    // 3) show result overlay
    final kind = (widget.punchType.toString().toLowerCase().contains('out'))
        ? PunchResultKind.outPunch
        : PunchResultKind.inPunch;

    await showPunchResult(
      context,
      success: success,
      kind: kind,
      punchedAt: when,
      employeeId: employeeId, // printed on success
    );

    if (!mounted) return;

    // 4) HARD navigate to Home (wipe stack so we can’t get stuck behind dialogs)
    Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const HomeScreen()),
          (route) => false,
    );
  }


  Future<void> _initializeCamera() async {
    try {
      final cameras = await availableCameras();
      final frontCamera = cameras.firstWhere(
            (camera) => camera.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );

      _cameraController = CameraController(
        frontCamera,
        ResolutionPreset.medium,
        enableAudio: false,
      );

      await _cameraController!.initialize();

      if (!mounted) return;
      setState(() {
        _isCameraInitialized = true;
      });
    } catch (e) {
      // ignore: avoid_print
      print('Error initializing camera: $e');
      if (mounted) {
        _showErrorMessage('Failed to initialize camera.');
      }
    }
  }

  /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC ---
  /// --- UPDATED OFFLINE-FIRST PUNCH LOGIC WITH CONSENSUS ---
  Future<void> _takePictureAndProcess() async {
    if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
    setState(() => _isProcessing = true);

    final started = DateTime.now();
    const totalBudget = Duration(seconds: 3);      // hard cap for recognition
    const interFrame = Duration(milliseconds: 160); // spacing between frames

    try {
      String? committedId;

      // Keep capturing until we either get consensus or run out of time
      while (committedId == null && DateTime.now().difference(started) < totalBudget) {
        // 1) capture a frame
        final image = await _cameraController!.takePicture();

        // 2) run recognition
        String? candidate = await _faceRecognitionService.recognizeFace(image);

        // 3) one-shot retry (preserved), only if we still have time left
        if (candidate == null) {
          const retryDelay = Duration(milliseconds: 250);
          if (DateTime.now().difference(started) + retryDelay < totalBudget) {
            await Future.delayed(retryDelay);
            final retry = await _cameraController!.takePicture();
            candidate = await _faceRecognitionService.recognizeFace(retry);
          }
        }

        // 4) vote into the consensus window
        committedId = _gate.push(candidate);

        // brief spacing between frames so the user can steady their face,
        // but don't exceed the total time budget
        if (committedId == null) {
          final elapsed = DateTime.now().difference(started);
          if (elapsed + interFrame >= totalBudget) break;
          await Future.delayed(interFrame);
        }
      }

      // No consensus within the time budget → soft fail and exit via overlay
      if (committedId == null) {
        _showErrorMessage('Authentication inconclusive—hold steady and try again.');
        await _showOverlayThenExit(
          success: false,
          when: DateTime.now(),
        );
        return;
      }

      // ===== From here down: your existing offline-first punch code (unchanged) =====
      final employeeId = committedId;
      final position = await _getCurrentLocation();

      final punchEvent = PunchEvent(
        employeeId: employeeId,
        eventTime: DateTime.now(),
        punchType: widget.punchType,
        status: 'VALID',
        deviceId: 'KIOSK01', // Example device ID
        latitude: position?.latitude,
        longitude: position?.longitude,
      );

      await _faceRecognitionService.logPunchDecision(
        widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
        employeeId: employeeId,
      );

      final connectivityResult = await Connectivity().checkConnectivity();
      final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
          connectivityResult.contains(ConnectivityResult.wifi);

      if (isOnline) {
        // Try direct sync
        final timesheet = Timesheet(
          employeeId: punchEvent.employeeId,
          workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
          punchEvents: [
            PunchEventPayload.fromPunchEvent(
              punchEvent,
              punchEvent.deviceId!,
            ),
          ],
        );

        final success = await _apiService.sendBulkTimsheets([timesheet]);

        if (success) {
          _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
          await _showOverlayThenExit(
            success: true,
            when: punchEvent.eventTime,
            employeeId: employeeId,
          );
          return;
        } else {
          // Fallback to queue
          await DatabaseService.instance.addPunchEventToQueue(punchEvent);
          _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
          await _showOverlayThenExit(
            success: true,
            when: punchEvent.eventTime,
            employeeId: employeeId,
          );
          return;
        }
      } else {
        // Offline: queue it
        await DatabaseService.instance.addPunchEventToQueue(punchEvent);
        _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
        await _showOverlayThenExit(
          success: true,
          when: punchEvent.eventTime,
          employeeId: employeeId,
        );
        return;
      }
      // ===== end unchanged logic =====
    } catch (e) {
      // ignore: avoid_print
      print('Error during face recognition or punch processing: $e');
      _showErrorMessage('An error occurred. Please try again.');
      await _showOverlayThenExit(
        success: false,
        when: DateTime.now(),
      );
      return;
    }
  }


  // void _takePictureAndProcess() async {
  //   if (_isProcessing || _cameraController == null || !_cameraController!.value.isInitialized) return;
  //   setState(() => _isProcessing = true);
  //
  //
  //   try {
  //     final image = await _cameraController!.takePicture();
  //
  //     var employeeId = await _faceRecognitionService.recognizeFace(image);
  //     if (employeeId == null) {
  //       await Future.delayed(const Duration(milliseconds: 250));
  //       final retry = await _cameraController!.takePicture();
  //       employeeId = await _faceRecognitionService.recognizeFace(retry);
  //     }
  //
  //     if (employeeId != null) {
  //       final position = await _getCurrentLocation();
  //
  //       final punchEvent = PunchEvent(
  //         employeeId: employeeId,
  //         eventTime: DateTime.now(),
  //         punchType: widget.punchType,
  //         status: 'VALID',
  //         deviceId: 'KIOSK01', // Example device ID
  //         latitude: position?.latitude,
  //         longitude: position?.longitude,
  //       );
  //
  //       await _faceRecognitionService.logPunchDecision(
  //         widget.punchType.toString(),
  //         employeeId: employeeId,
  //       );
  //
  //
  //       final connectivityResult = await Connectivity().checkConnectivity();
  //       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
  //           connectivityResult.contains(ConnectivityResult.wifi);
  //
  //       if (isOnline) {
  //         // Try direct sync
  //         // ignore: avoid_print
  //         print('Device is online. Attempting to send punch event directly.');
  //
  //         final timesheet = Timesheet(
  //           employeeId: punchEvent.employeeId,
  //           workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
  //           punchEvents: [
  //             PunchEventPayload.fromPunchEvent(
  //               punchEvent,
  //               punchEvent.deviceId!,
  //             ),
  //           ],
  //         );
  //
  //         await _faceRecognitionService.logPunchDecision(
  //           widget.punchType == PunchType.inPunch ? 'IN' : 'OUT',
  //           employeeId: employeeId,
  //         );
  //
  //         final success = await _apiService.sendBulkTimsheets([timesheet]);
  //
  //         if (success) {
  //           _showSuccessMessage('Welcome, $employeeId! Punch synced successfully.');
  //           await _showOverlayThenExit(
  //             success: true,
  //             when: punchEvent.eventTime,
  //             employeeId: employeeId,
  //           );
  //           return;
  //
  //         } else {
  //           // Fallback to queue
  //           // ignore: avoid_print
  //           print("Direct sync failed. Queuing punch event for later.");
  //           await DatabaseService.instance.addPunchEventToQueue(punchEvent);
  //           _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync later.');
  //           await _showOverlayThenExit(
  //             success: true,
  //             when: punchEvent.eventTime,
  //             employeeId: employeeId,
  //           );
  //           return;
  //
  //         }
  //       } else {
  //         // Offline: queue it
  //         // ignore: avoid_print
  //         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
  //         _showSuccessMessage('Welcome, $employeeId! Punch saved. Will sync when online.');
  //         await _showOverlayThenExit(
  //           success: true,
  //           when: punchEvent.eventTime,
  //           employeeId: employeeId,
  //         );
  //         return;
  //
  //       }
  //     } else {
  //       _showErrorMessage('Authentication Failed. Please try again.');
  //       await _showOverlayThenExit(
  //         success: false,
  //         when: DateTime.now(),
  //       );
  //       return;
  //     }
  //   } catch (e) {
  //     // ignore: avoid_print
  //     print('Error during face recognition or punch processing: $e');
  //     _showErrorMessage('An error occurred. Please try again.');
  //     await _showOverlayThenExit(
  //       success: false,
  //       when: DateTime.now(),
  //     );
  //     return;
  //   }
  //   // finally {
  //   //   if (mounted) {
  //   //     Navigator.of(context).pop();
  //   //   }
  //   // }
  // }

  Future<Position?> _getCurrentLocation() async {
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        // ignore: avoid_print
        print('Location services are disabled.');
        return null;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission != LocationPermission.whileInUse &&
            permission != LocationPermission.always) {
          // ignore: avoid_print
          print('Location permission denied.');
          return null;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        // ignore: avoid_print
        print('Location permissions are permanently denied.');
        return null;
      }

      return Geolocator.getCurrentPosition();
    } catch (e) {
      // ignore: avoid_print
      print('Error getting location: $e');
      return null;
    }
  }

  void _showSuccessMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.green,
        content: Text(message),
      ),
    );
  }


  void _showErrorMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.red,
        content: Text(message),
      ),
    );
  }
  Future<void> _showOverlayThenExit({
    required bool success,
    required DateTime when,
    String? employeeId,
  }) async {
    if (!mounted) return;
    // 1) remove the black processing mask so the dialog is visible
    setState(() => _isProcessing = false);

    // Make sure your black processing veil is gone so the overlay is visible
    // if (mounted) setState(() => _isProcessing = false);

    // Map your existing punch type to the overlay enum
    final kind = (widget.punchType.toString().toLowerCase().contains('out'))
        ? PunchResultKind.outPunch
        : PunchResultKind.inPunch;

    await showPunchResult(
      context,
      success: success,
      kind: kind,
      punchedAt: when,
      employeeId: employeeId,
    );

    if (!mounted) return;
    // 4) go back to Home (first route). If you use named routes, adjust to your home route.
    Navigator.of(context).popUntil((route) => route.isFirst);// return to previous screen AFTER overlay closes
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        alignment: Alignment.center,
        children: [
          if (_isCameraInitialized && _cameraController != null)
            Center(child: CameraPreview(_cameraController!))
          else
            const Center(child: CircularProgressIndicator()),

          // Capture button
          Positioned(
            bottom: 40,
            child: FloatingActionButton(
              onPressed: _isProcessing ? null : _takePictureAndProcess,
              backgroundColor:
              _isProcessing ? Colors.grey : Theme.of(context).primaryColor,
              child: const Icon(Icons.camera_alt),
            ),
          ),

          // Processing overlay
          if (_isProcessing)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.5),
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 16),
                      Text(
                        'Recognizing face...',
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// lib/app/presentation/screens/punch_camera_screen.dart

// import 'dart:async';
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
// import 'package:intl/intl.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// import '../../core/models /punch_event.dart';
// import '../../core/models /timesheet.dart';
// import 'camera_utils.dart'; // Helper for image conversion
//
// class PunchCameraScreen extends StatefulWidget {
//   final PunchType punchType;
//   const PunchCameraScreen({super.key, required this.punchType});
//
//   @override
//   State<PunchCameraScreen> createState() => _PunchCameraScreenState();
// }
//
// class _PunchCameraScreenState extends State<PunchCameraScreen> {
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//   bool _isProcessing = false;
//
//   // --- SERVICES & DETECTORS ---
//   final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//   late final FaceDetector _faceDetector;
//
//   // --- DETECTION STATE ---
//   bool _isDetecting = false;
//   bool _faceDetected = false; // For UI feedback
//
//   @override
//   void initState() {
//     super.initState();
//     // Initialize with flexible options for better real-world detection
//     _faceDetector = FaceDetector(
//       options: FaceDetectorOptions(
//         performanceMode: FaceDetectorMode.fast,
//         enableClassification: true, // Required for blink detection
//         enableLandmarks: true,
//         enableContours: true, // Helps with angled faces
//         minFaceSize: 0.1, // Detect faces that are further away
//       ),
//     );
//     _initializeCamera();
//   }
//
//   @override
//   void dispose() {
//     // Gracefully dispose all resources
//     _cameraController?.stopImageStream();
//     _cameraController?.dispose();
//     _faceDetector.close();
//     _faceRecognitionService.dispose();
//     super.dispose();
//   }
//
//   Future<void> _initializeCamera() async {
//     try {
//       final cameras = await availableCameras();
//       final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         frontCamera,
//         ResolutionPreset.medium,
//         enableAudio: false,
//         imageFormatGroup: ImageFormatGroup.nv21, // Format for ML Kit
//       );
//
//       await _cameraController!.initialize();
//       if (!mounted) return;
//
//       // Start processing the camera feed for blinks
//       await _cameraController!.startImageStream(_processCameraImage);
//
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     } catch (e) {
//       debugPrint("Error initializing camera: $e");
//       if (mounted) {
//         _showErrorMessage('Failed to initialize camera.');
//         Navigator.of(context).pop();
//       }
//     }
//   }
//
//   /// Processes each frame from the camera to detect a face and a subsequent blink.
//   Future<void> _processCameraImage(CameraImage image) async {
//     if (_isDetecting || _isProcessing) return;
//
//     _isDetecting = true;
//     try {
//       final inputImage = InputImage.fromBytes(
//         bytes: image.planes[0].bytes,
//         metadata: CameraUtils.buildImageMetadata(image, _cameraController!),
//       );
//
//       final faces = await _faceDetector.processImage(inputImage);
//
//       if (faces.isNotEmpty) {
//         if (!_faceDetected) {
//           setState(() => _faceDetected = true);
//         }
//
//         final face = faces.first;
//         // Check if both eyes are closed
//         if ((face.leftEyeOpenProbability ?? 1.0) < 0.3 &&
//             (face.rightEyeOpenProbability ?? 1.0) < 0.3) {
//           if (!_isProcessing) {
//             setState(() => _isProcessing = true);
//             // Stop stream and capture a high-quality image for recognition
//             await _cameraController?.stopImageStream();
//             await _captureAndProcess();
//           }
//         }
//       } else {
//         if (_faceDetected) {
//           setState(() => _faceDetected = false);
//         }
//       }
//     } catch (e) {
//       debugPrint("Error processing image stream: $e");
//     } finally {
//       _isDetecting = false;
//     }
//   }
//
//   /// Captures image, runs recognition, and handles both success and failure cases.
//   Future<void> _captureAndProcess() async {
//     if (!_cameraController!.value.isInitialized) {
//       await _resetForRetry('Camera not ready. Please try again.');
//       return;
//     }
//
//     try {
//       final image = await _cameraController!.takePicture();
//       final employeeId = await _faceRecognitionService.recognizeFace(image);
//
//       if (employeeId != null) {
//         // --- SUCCESS CASE ---
//         Position? position = await _getCurrentLocation();
//         final punchEvent = PunchEvent(
//           employeeId: employeeId,
//           eventTime: DateTime.now(),
//           punchType: widget.punchType,
//           status: 'VALID',
//           deviceId: 'KIOSK01',
//           latitude: position?.latitude,
//           longitude: position?.longitude,
//         );
//
//         await _handlePunchEvent(punchEvent);
//
//         // Pop screen after a delay to show the success message
//         await Future.delayed(const Duration(seconds: 2));
//         if (mounted) {
//           Navigator.of(context).pop();
//         }
//       } else {
//         // --- FAILURE CASE: Face not recognized ---
//         await _resetForRetry('Face not recognized. Please try again.');
//       }
//     } catch (e) {
//       debugPrint("Error during capture/recognition: $e");
//       await _resetForRetry('An error occurred. Please try again.');
//     }
//   }
//
//   /// Resets the state to allow the user to attempt recognition again.
//   Future<void> _resetForRetry(String message) async {
//     _showErrorMessage(message);
//     await Future.delayed(const Duration(seconds: 2)); // Let user read message
//
//     if (mounted) {
//       setState(() {
//         _isProcessing = false;
//         _faceDetected = false;
//       });
//       // Restart the stream to look for a face and blink again
//       if (_cameraController != null && _cameraController!.value.isInitialized) {
//         await _cameraController!.startImageStream(_processCameraImage);
//       }
//     }
//   }
//
//   /// Handles the logic for sending or queueing the punch event.
//   Future<void> _handlePunchEvent(PunchEvent punchEvent) async {
//     final connectivityResult = await Connectivity().checkConnectivity();
//     final isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//         connectivityResult.contains(ConnectivityResult.wifi);
//
//     if (isOnline) {
//       debugPrint("Online. Attempting to sync punch event.");
//       final timesheet = Timesheet(
//         employeeId: punchEvent.employeeId,
//         workDate: DateFormat('yyyy-MM-dd').format(punchEvent.eventTime),
//         punchEvents: [
//           PunchEventPayload.fromPunchEvent(punchEvent, punchEvent.deviceId!)
//         ],
//       );
//       final success = await _apiService.sendBulkTimsheets([timesheet]);
//       if (success) {
//         _showSuccessMessage('Welcome, ${punchEvent.employeeId}! Punch synced.');
//       } else {
//         debugPrint("Direct sync failed. Queuing punch event.");
//         await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//         _showSuccessMessage(
//             'Welcome, ${punchEvent.employeeId}! Punch saved, will sync later.');
//       }
//     } else {
//       debugPrint("Offline. Queuing punch event.");
//       await DatabaseService.instance.addPunchEventToQueue(punchEvent);
//       _showSuccessMessage(
//           'Welcome, ${punchEvent.employeeId}! Punch saved, will sync when online.');
//     }
//   }
//
//   /// Helper method to get the current GPS location.
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         debugPrint("Location services are disabled.");
//         return null;
//       }
//
//       LocationPermission permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission != LocationPermission.whileInUse &&
//             permission != LocationPermission.always) {
//           debugPrint("Location permissions were denied.");
//           return null;
//         }
//       }
//       if (permission == LocationPermission.deniedForever) {
//         debugPrint("Location permissions are permanently denied, we cannot request permissions.");
//         return null;
//       }
//
//       return await Geolocator.getCurrentPosition();
//     } catch (e) {
//       debugPrint("Error getting location: $e");
//       return null;
//     }
//   }
//
//   /// Helper method to show a green success message.
//   void _showSuccessMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message, style: const TextStyle(color: Colors.white)),
//       ),
//     );
//   }
//
//   /// Helper method to show a red error message.
//   void _showErrorMessage(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.red,
//         content: Text(message, style: const TextStyle(color: Colors.white)),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.black,
//       body: Stack(
//         alignment: Alignment.center,
//         children: [
//           if (_isCameraInitialized && _cameraController != null)
//             Center(child: CameraPreview(_cameraController!))
//           else
//             const Center(child: CircularProgressIndicator(color: Colors.white)),
//
//           // Dynamic UI prompt for the user
//           Positioned(
//             bottom: 60,
//             child: Container(
//               padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
//               decoration: BoxDecoration(
//                 color: Colors.black.withOpacity(0.6),
//                 borderRadius: BorderRadius.circular(30),
//               ),
//               child: Text(
//                 _isProcessing
//                     ? 'Processing...'
//                     : (_faceDetected ? 'Blink to Punch' : 'Position Face in Frame'),
//                 style: TextStyle(
//                   color: _faceDetected && !_isProcessing
//                       ? Colors.greenAccent
//                       : Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           ),
//
//           // Loading overlay during processing
//           if (_isProcessing)
//             Container(
//               color: Colors.black.withOpacity(0.5),
//               child: const Center(
//                 child: CircularProgressIndicator(color: Colors.white),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }