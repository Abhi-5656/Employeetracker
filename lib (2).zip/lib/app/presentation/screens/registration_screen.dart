// import 'dart:convert';
// import 'dart:io';
//
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
//
// import 'package:kiosk/app/core/models/employee_profile_registration.dart';
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
// import 'package:kiosk/app/core/services/storage_service.dart';
//
// class RegistrationScreen extends StatefulWidget {
//   const RegistrationScreen({super.key});
//
//   @override
//   State<RegistrationScreen> createState() => _RegistrationScreenState();
// }
//
// class _RegistrationScreenState extends State<RegistrationScreen> {
//   // --- Form / Controllers ---
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController _employeeIdController = TextEditingController();
//
//   // --- Services ---
//   final FaceRecognitionService _faceRecognitionService =
//   FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//
//   // --- Camera / Capture State ---
//   CameraController? _cameraController;
//   bool _isCameraInitialized = false;
//
//   // Single-shot legacy path (preserved)
//   XFile? _capturedImage;
//
//   // Multi-shot enrollment
//   final List<XFile> _multiImages = [];
//   final List<List<double>> _multiEmbeddings = [];
//   int _targetSamples = 5; // 5..10
//   int _capturedCount = 0;
//   String _currentInstruction = '';
//   bool _multiCaptureRunning = false;
//
//   // UI state
//   bool _isRegistering = false;
//   bool _isSuccessOverlayVisible = false;
//
//   // ------- LIFECYCLE -------
//   @override
//   void dispose() {
//     _employeeIdController.dispose();
//     _cameraController?.dispose();
//     super.dispose();
//   }
//
//   // ------- CAMERA HELPERS -------
//   Future<void> _initializeCamera() async {
//     if (_cameraController != null && _cameraController!.value.isInitialized) {
//       setState(() => _isCameraInitialized = true);
//       return;
//     }
//
//     try {
//       final cameras = await availableCameras();
//       final front = cameras.firstWhere(
//             (c) => c.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first,
//       );
//
//       _cameraController = CameraController(
//         front,
//         ResolutionPreset.veryHigh, // or .ultraHigh if device supports it
//         enableAudio: false,
//         imageFormatGroup: ImageFormatGroup.jpeg, // helps some Android devices
//       );
//
//       await _cameraController!.initialize();
//       if (!mounted) return;
//
//       setState(() => _isCameraInitialized = true);
//     } catch (e) {
//       debugPrint('❌ Camera init failed: $e');
//       if (mounted) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Camera failed to initialize.')),
//         );
//       }
//     }
//   }
//
//   Future<void> _disposeCamera() async {
//     try {
//       await _cameraController?.dispose();
//     } catch (_) {}
//     _cameraController = null;
//     if (mounted) setState(() => _isCameraInitialized = false);
//   }
//
//   // ------- SINGLE-SHOT (LEGACY) -------
//   Future<void> _takePicture() async {
//     if (_cameraController == null || !_cameraController!.value.isInitialized) {
//       await _initializeCamera();
//       if (_cameraController == null || !_cameraController!.value.isInitialized) {
//         return;
//       }
//     }
//
//     try {
//       final pic = await _cameraController!.takePicture();
//       setState(() {
//         _capturedImage = pic;
//       });
//     } catch (e) {
//       debugPrint('❌ takePicture failed: $e');
//       if (mounted) {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(content: Text('Failed to capture image.')),
//         );
//       }
//     }
//   }
//
//   void _retakePicture() {
//     setState(() {
//       _capturedImage = null;
//     });
//   }
//
//   // ------- MULTI-SHOT ENROLLMENT -------
//   static const List<String> _instructionPool = [
//     'Look straight with neutral face',
//     'Turn head slightly LEFT',
//     'Turn head slightly RIGHT',
//     'Tilt head slightly UP',
//     'Tilt head slightly DOWN',
//     'Smile softly',
//     'Neutral face (again)',
//     'Blink once naturally',
//     'Turn head a bit LEFT + slight smile',
//     'Turn head a bit RIGHT + slight smile',
//   ];
//
//   List<String> _buildInstructionPlan(int n) {
//     // Use first N instructions; guarantees 5..10 coverage with varied poses/expressions
//     return _instructionPool.take(n).toList(growable: false);
//   }
//
//   Future<bool> _captureOneSample(String instruction, {int retries = 3}) async {
//     // Show the instruction promptly
//     if (mounted) setState(() => _currentInstruction = instruction);
//
//     // Ensure camera
//     if (_cameraController == null || !_cameraController!.value.isInitialized) {
//       await _initializeCamera();
//       if (_cameraController == null ||
//           !_cameraController!.value.isInitialized) {
//         return false;
//       }
//     }
//
//     // A short settle time so user can pose
//     await Future.delayed(const Duration(milliseconds: 900));
//
//     for (int attempt = 1; attempt <= retries; attempt++) {
//       try {
//         final shot = await _cameraController!.takePicture();
//         final bytes = await shot.readAsBytes();
//         final b64 = base64Encode(bytes);
//
//         // Uses your registration embedding path (with l2 norm + quality gates)
//         final emb = await _faceRecognitionService.getEmbeddingForRegistration(
//           b64,
//         );
//
//         if (emb == null) {
//           if (attempt == retries) {
//             if (mounted) {
//               ScaffoldMessenger.of(context).showSnackBar(
//                 const SnackBar(
//                   content:
//                   Text('No face detected or poor quality. Please try again.'),
//                 ),
//               );
//             }
//             return false;
//           }
//           // small wait and retry same step
//           await Future.delayed(const Duration(milliseconds: 500));
//           continue;
//         }
//
//         // Success: store
//         _multiImages.add(shot);
//         _multiEmbeddings.add(emb);
//         if (mounted) {
//           setState(() => _capturedCount = _multiEmbeddings.length);
//         }
//         return true;
//       } catch (e) {
//         debugPrint('❌ Capture sample failed (attempt $attempt): $e');
//         if (attempt == retries) {
//           if (mounted) {
//             ScaffoldMessenger.of(context).showSnackBar(
//               SnackBar(content: Text('Capture failed: $e')),
//             );
//           }
//           return false;
//         }
//         await Future.delayed(const Duration(milliseconds: 400));
//       }
//     }
//     return false;
//   }
//
//   Future<void> _startMultiCapture() async {
//     FocusScope.of(context).unfocus();
//     if (!_validateEmployeeIdField()) return;
//
//     setState(() {
//       _multiCaptureRunning = true;
//       _multiImages.clear();
//       _multiEmbeddings.clear();
//       _capturedCount = 0;
//       _currentInstruction = '';
//     });
//
//     await _initializeCamera();
//     final plan = _buildInstructionPlan(_targetSamples);
//
//     for (final step in plan) {
//       if (!_multiCaptureRunning) break; // user may cancel
//
//       final ok = await _captureOneSample(step);
//       if (!ok) {
//         // Give the user the option to retry the failed step
//         final retry = await showDialog<bool>(
//           context: context,
//           barrierDismissible: false,
//           builder: (_) => AlertDialog(
//             title: const Text('Capture failed'),
//             content: const Text('Could not capture a usable face. Try this step again?'),
//             actions: [
//               TextButton(
//                 onPressed: () => Navigator.of(context).pop(false),
//                 child: const Text('Skip'),
//               ),
//               FilledButton(
//                 onPressed: () => Navigator.of(context).pop(true),
//                 child: const Text('Retry'),
//               ),
//             ],
//           ),
//         );
//
//         if (retry == true) {
//           if (!await _captureOneSample(step)) {
//             // still failed – continue to next step
//           }
//         }
//       }
//     }
//
//     if (!_multiCaptureRunning) return;
//
//     if (_multiEmbeddings.length < 5) {
//       // Not enough usable samples
//       if (mounted) {
//         setState(() => _multiCaptureRunning = false);
//       }
//       ScaffoldMessenger.of(context).showSnackBar(
//         const SnackBar(content: Text('Need at least 5 good samples. Please try again.')),
//       );
//       return;
//     }
//
//     // Auto-proceed to registration with collected embeddings
//     await _registerWithEmbeddings(
//       _multiEmbeddings,
//       firstImageForPHash: _multiImages.first,
//     );
//
//     if (mounted) {
//       setState(() => _multiCaptureRunning = false);
//     }
//   }
//
//   void _cancelMultiCapture() {
//     setState(() {
//       _multiCaptureRunning = false;
//       _currentInstruction = '';
//     });
//   }
//
//   // ------- REGISTRATION PIPELINE -------
//   bool _validateEmployeeIdField() {
//     if ((_employeeIdController.text).trim().isEmpty) {
//       _showError('Enter Employee ID.');
//       return false;
//     }
//     return true;
//   }
//
//   Future<void> registerEmployee() async {
//     // Legacy single-shot path preserved
//     if (!_validateEmployeeIdField() || _capturedImage == null) {
//       _showError('Please enter an Employee ID and capture an image.');
//       return;
//     }
//
//     setState(() => _isRegistering = true);
//
//     try {
//       final employeeId = _employeeIdController.text.trim();
//
//       // Verify employee exists locally
//       final exists = await DatabaseService.instance.employeeExists(employeeId);
//       if (!exists) {
//         _showError('Employee ID not found. Please sync data or enter a valid ID.');
//         return;
//       }
//
//       // Build one embedding from the single capture
//       final bytes = await _capturedImage!.readAsBytes();
//       final base64Image = base64Encode(bytes);
//       final emb =
//       await _faceRecognitionService.getEmbeddingForRegistration(base64Image);
//
//       if (emb == null) {
//         _showError('No face detected. Please retake the picture.');
//         return;
//       }
//
//       // Store as single vector (keeps backward compatibility)
//       await _registerWithEmbeddings(
//         [emb],
//         firstImageForPHash: _capturedImage,
//       );
//
//       // reset single-shot after success path
//       _capturedImage = null;
//     } catch (e) {
//       debugPrint('❌ Error during registration: $e');
//       _showError('An error occurred during registration.');
//     } finally {
//       if (mounted) setState(() => _isRegistering = false);
//     }
//   }
//
//   Future<void> _registerWithEmbeddings(
//       List<List<double>> embeddings, {
//         XFile? firstImageForPHash,
//       }) async {
//     final employeeId = _employeeIdController.text.trim();
//
//     // Persist embeddings: supports single OR multi
//     final jsonEmbedding = jsonEncode(embeddings);
//
//     // Save phash (keep previous behavior – single pHash stored; use first image)
//     if (firstImageForPHash != null) {
//       try {
//         final phash = await _faceRecognitionService.getPHashForRegistration(
//           base64Encode(await firstImageForPHash.readAsBytes()),
//         );
//
//         if (phash != null) {
//           await StorageService().saveFaceHash(employeeId, phash);
//         }
//
//         await _faceRecognitionService.logAudit('register', {
//           'employeeId': employeeId,
//           'hasEmbedding': true,
//           'hasPHash': phash != null,
//           'samples': embeddings.length,
//         });
//       } catch (e) {
//         debugPrint('⚠️ pHash save failed: $e');
//       }
//     } else {
//       await _faceRecognitionService.logAudit('register', {
//         'employeeId': employeeId,
//         'hasEmbedding': true,
//         'hasPHash': false,
//         'samples': embeddings.length,
//       });
//     }
//
//     // Update local employee record with embedding(s)
//     await DatabaseService.instance.updateEmployeeEmbedding(
//       employeeId,
//       jsonEmbedding,
//     );
//
//     // Ensure live recognition uses fresh gallery/centroids
//     _faceRecognitionService.invalidateClustersCache();
//
//     // Also update local profile row and attempt sync (preserves your previous flow)
//     final Position? position = await _getCurrentLocation();
//
//     final apiProfile = EmployeeProfileRegistration(
//       employeeId: employeeId,
//       employeeImageData: jsonEmbedding, // now can be [ [..], [..], ... ]
//     );
//
//     final localProfileData = {
//       'employee_id': employeeId,
//       'name': null, // unchanged: name not collected here
//       'image_data': jsonEmbedding,
//       'latitude': position?.latitude,
//       'longitude': position?.longitude,
//       'timestamp': DateTime.now().toIso8601String(),
//     };
//
//     await DatabaseService.instance.updateEmployeeProfile(localProfileData);
//
//     // Try to sync immediately if online; else queue for later (unchanged behavior)
//     final connectivityResult = await Connectivity().checkConnectivity();
//     final isOnline = connectivityResult != ConnectivityResult.none;
//
//     if (isOnline) {
//       final ok = await _apiService.sendBulkProfileData([apiProfile.toMap()]);
//       if (!ok) {
//         await DatabaseService.instance.addProfileToSyncQueue(
//           apiProfile.employeeId,
//         );
//         _showSuccessAndReset('Saved locally. Will sync later.');
//         return;
//       }
//       _showSuccessAndReset('Registration successful and synced.');
//     } else {
//       await DatabaseService.instance.addProfileToSyncQueue(
//         apiProfile.employeeId,
//       );
//       _showSuccessAndReset('Saved locally. Will sync when online.');
//     }
//   }
//
//   // ------- GEO -------
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         _showError('Location services are disabled.');
//         return null;
//       }
//
//       LocationPermission permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission == LocationPermission.denied) {
//           _showError('Location permissions are denied.');
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         _showError('Location permissions are permanently denied.');
//         return null;
//       }
//
//       return await Geolocator.getCurrentPosition(
//         desiredAccuracy: LocationAccuracy.high,
//       );
//     } catch (e) {
//       debugPrint('⚠️ Location error: $e');
//       return null;
//     }
//   }
//
//   // ------- UI HELPERS -------
//   void _showError(String message) {
//     if (!mounted) return;
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text(message)),
//     );
//   }
//
//   void _showSuccessAndReset(String message) {
//     if (!mounted) return;
//
//     setState(() => _isSuccessOverlayVisible = true);
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text(message)),
//     );
//
//     Future.delayed(const Duration(seconds: 2), () {
//       if (!mounted) return;
//       setState(() {
//         _isSuccessOverlayVisible = false;
//         _employeeIdController.clear();
//
//         // Reset single + multi states
//         _capturedImage = null;
//         _multiImages.clear();
//         _multiEmbeddings.clear();
//         _capturedCount = 0;
//         _currentInstruction = '';
//         _multiCaptureRunning = false;
//       });
//     });
//   }
//
//   // ------- UI -------
//   @override
//   Widget build(BuildContext context) {
//     final canRegisterSingle = _capturedImage != null && !_multiCaptureRunning;
//     final canStartMulti = !_multiCaptureRunning;
//
//     return Scaffold(
//       backgroundColor: const Color(0xFFF0F2F5),
//       appBar: AppBar(
//         title: const Text('Face Registration'),
//       ),
//       body: Stack(
//         children: [
//           Center(
//             child: SingleChildScrollView(
//               padding: const EdgeInsets.all(24),
//               child: ConstrainedBox(
//                 constraints: const BoxConstraints(maxWidth: 560),
//                 child: Form(
//                   key: _formKey,
//                   child: Column(
//                     children: [
//                       // Employee ID
//                       TextFormField(
//                         controller: _employeeIdController,
//                         decoration: const InputDecoration(
//                           labelText: 'Employee ID',
//                           border: OutlineInputBorder(),
//                         ),
//                         validator: (v) =>
//                         (v == null || v.trim().isEmpty) ? 'Required' : null,
//                       ),
//                       const SizedBox(height: 16),
//
//                       // Camera / Preview area
//                       AspectRatio(
//                         aspectRatio: 3 / 4,
//                         child: Container(
//                           decoration: BoxDecoration(
//                             color: Colors.black,
//                             borderRadius: BorderRadius.circular(12),
//                           ),
//                           clipBehavior: Clip.antiAlias,
//                           child: _buildCameraArea(),
//                         ),
//                       ),
//                       const SizedBox(height: 12),
//
//                       // Multi-sample controls
//                       Row(
//                         children: [
//                           const Text('Samples:'),
//                           const SizedBox(width: 8),
//                           DropdownButton<int>(
//                             value: _targetSamples,
//                             items: List.generate(6, (i) => 5 + i)
//                                 .map(
//                                   (n) => DropdownMenuItem(
//                                 value: n,
//                                 child: Text('$n'),
//                               ),
//                             )
//                                 .toList(),
//                             onChanged: canStartMulti
//                                 ? (n) {
//                               if (n == null) return;
//                               setState(
//                                     () => _targetSamples = n.clamp(5, 10),
//                               );
//                             }
//                                 : null,
//                           ),
//                           const Spacer(),
//                           if (_multiCaptureRunning)
//                             Text(
//                               '$_capturedCount / $_targetSamples',
//                               style:
//                               const TextStyle(fontWeight: FontWeight.w600),
//                             ),
//                         ],
//                       ),
//                       const SizedBox(height: 8),
//
//                       if (_multiCaptureRunning || _currentInstruction.isNotEmpty)
//                         Align(
//                           alignment: Alignment.centerLeft,
//                           child: Text(
//                             _currentInstruction.isEmpty
//                                 ? 'Capturing...'
//                                 : 'Step: $_currentInstruction',
//                             style: const TextStyle(
//                               fontSize: 13,
//                               color: Colors.blueGrey,
//                             ),
//                           ),
//                         ),
//                       const SizedBox(height: 16),
//
//                       // Action buttons
//                       Row(
//                         children: [
//                           // Single-shot controls (preserved)
//                           Expanded(
//                             child: OutlinedButton.icon(
//                               onPressed:
//                               _multiCaptureRunning ? null : _takePicture,
//                               icon: const Icon(Icons.camera_alt_outlined),
//                               label: const Text('Capture'),
//                             ),
//                           ),
//                           const SizedBox(width: 12),
//                           Expanded(
//                             child: OutlinedButton.icon(
//                               onPressed: (_capturedImage != null &&
//                                   !_multiCaptureRunning)
//                                   ? _retakePicture
//                                   : null,
//                               icon: const Icon(Icons.refresh),
//                               label: const Text('Retake'),
//                             ),
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 12),
//
//                       Row(
//                         children: [
//                           // Start/Cancel multi-sample
//                           Expanded(
//                             child: FilledButton.icon(
//                               onPressed: canStartMulti ? _startMultiCapture : null,
//                               icon: const Icon(Icons.auto_awesome_motion),
//                               label: const Text('Start Multi-Capture'),
//                             ),
//                           ),
//                           const SizedBox(width: 12),
//                           Expanded(
//                             child: OutlinedButton.icon(
//                               onPressed:
//                               _multiCaptureRunning ? _cancelMultiCapture : null,
//                               icon: const Icon(Icons.stop_circle_outlined),
//                               label: const Text('Cancel'),
//                             ),
//                           ),
//                         ],
//                       ),
//                       const SizedBox(height: 12),
//
//                       // Register buttons
//                       Row(
//                         children: [
//                           Expanded(
//                             child: FilledButton.icon(
//                               onPressed: (canRegisterSingle && !_isRegistering)
//                                   ? registerEmployee
//                                   : null,
//                               icon: const Icon(Icons.verified_user),
//                               label: _isRegistering
//                                   ? const Text('Registering...')
//                                   : const Text('Register (Single)'),
//                             ),
//                           ),
//                           const SizedBox(width: 12),
//                           Expanded(
//                             child: FilledButton.icon(
//                               onPressed: (!_multiCaptureRunning &&
//                                   _multiEmbeddings.length >= 5 &&
//                                   !_isRegistering)
//                                   ? () => _registerWithEmbeddings(
//                                 _multiEmbeddings,
//                                 firstImageForPHash: _multiImages.isNotEmpty
//                                     ? _multiImages.first
//                                     : null,
//                               )
//                                   : null,
//                               icon: const Icon(Icons.verified),
//                               label: _isRegistering
//                                   ? const Text('Registering...')
//                                   : const Text('Register (Multi)'),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//
//           // Success overlay
//           if (_isSuccessOverlayVisible)
//             Container(
//               color: Colors.black54,
//               child: const Center(
//                 child: Icon(
//                   Icons.check_circle,
//                   size: 120,
//                   color: Colors.lightGreenAccent,
//                 ),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildCameraArea() {
//     if (_capturedImage != null && !_multiCaptureRunning) {
//       return Image.file(
//         File(_capturedImage!.path),
//         fit: BoxFit.cover,
//       );
//     }
//
//     if (_isCameraInitialized && _cameraController != null) {
//       return CameraPreview(_cameraController!);
//     }
//
//     return const Center(
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Icon(Icons.camera_alt, size: 64, color: Colors.white54),
//           SizedBox(height: 8),
//           Text('Camera not ready', style: TextStyle(color: Colors.white70)),
//         ],
//       ),
//     );
//   }
// }

//older version
import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'package:kiosk/app/core/models/employee_profile_registration.dart';
import 'package:kiosk/app/core/services/api_service.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:kiosk/app/core/services/face_recognition_service.dart';
import 'package:kiosk/app/core/services/storage_service.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  // --- Form / Controllers ---
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _employeeIdController = TextEditingController();

  // --- Services ---
  final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
  final ApiService _apiService = ApiService();

  // --- Camera / Capture State ---
  CameraController? _cameraController;
  bool _isCameraInitialized = false;

  // Single-shot legacy path (preserved)
  XFile? _capturedImage;

  // Multi-shot enrollment
  final List<XFile> _multiImages = [];
  final List<List<double>> _multiEmbeddings = [];
  int _targetSamples = 5; // 5..10
  int _capturedCount = 0;
  String _currentInstruction = '';
  bool _multiCaptureRunning = false;

  // UI state
  bool _isRegistering = false;
  bool _isSuccessOverlayVisible = false;

  // ------- LIFECYCLE -------

  @override
  void dispose() {
    _employeeIdController.dispose();
    _cameraController?.dispose();
    super.dispose();
  }

  // ------- CAMERA HELPERS -------

  Future<void> _initializeCamera() async {
    if (_cameraController != null && _cameraController!.value.isInitialized) {
      setState(() => _isCameraInitialized = true);
      return;
    }
    try {
      final cameras = await availableCameras();
      final front = cameras.firstWhere(
            (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );
      _cameraController = CameraController(front, ResolutionPreset.medium, enableAudio: false);
      await _cameraController!.initialize();
      if (!mounted) return;
      setState(() => _isCameraInitialized = true);
    } catch (e) {
      debugPrint('❌ Camera init failed: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Camera failed to initialize.')),
        );
      }
    }
  }

  Future<void> _disposeCamera() async {
    try {
      await _cameraController?.dispose();
    } catch (_) {}
    _cameraController = null;
    if (mounted) setState(() => _isCameraInitialized = false);
  }

  // ------- SINGLE-SHOT (LEGACY) -------

  Future<void> _takePicture() async {
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      await _initializeCamera();
      if (_cameraController == null || !_cameraController!.value.isInitialized) return;
    }
    try {
      final pic = await _cameraController!.takePicture();
      setState(() {
        _capturedImage = pic;
      });
    } catch (e) {
      debugPrint('❌ takePicture failed: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to capture image.')),
        );
      }
    }
  }

  void _retakePicture() {
    setState(() {
      _capturedImage = null;
    });
  }

  // ------- MULTI-SHOT ENROLLMENT -------

  static const List<String> _instructionPool = [
    'Look straight with neutral face',
    'Turn head slightly LEFT',
    'Turn head slightly RIGHT',
    'Tilt head slightly UP',
    'Tilt head slightly DOWN',
    'Smile softly',
    'Neutral face (again)',
    'Blink once naturally',
    'Turn head a bit LEFT + slight smile',
    'Turn head a bit RIGHT + slight smile',
  ];

  List<String> _buildInstructionPlan(int n) {
    // Use first N instructions; guarantees 5..10 coverage with varied poses/expressions
    return _instructionPool.take(n).toList(growable: false);
  }

  Future<bool> _captureOneSample(String instruction, {int retries = 3}) async {
    // Show the instruction promptly
    if (mounted) setState(() => _currentInstruction = instruction);

    // Ensure camera
    if (_cameraController == null || !_cameraController!.value.isInitialized) {
      await _initializeCamera();
      if (_cameraController == null || !_cameraController!.value.isInitialized) {
        return false;
      }
    }

    // A short settle time so user can pose
    await Future.delayed(const Duration(milliseconds: 600));

    for (int attempt = 1; attempt <= retries; attempt++) {
      try {
        final shot = await _cameraController!.takePicture();
        final bytes = await shot.readAsBytes();
        final b64 = base64Encode(bytes);

        // Uses your registration embedding path (with l2 norm + quality gates)
        final emb = await _faceRecognitionService.getEmbeddingForRegistration(b64);
        if (emb == null) {
          if (attempt == retries) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('No face detected or poor quality. Please try again.')),
              );
            }
            return false;
          }
          // small wait and retry same step
          await Future.delayed(const Duration(milliseconds: 500));
          continue;
        }

        // Success: store
        _multiImages.add(shot);
        _multiEmbeddings.add(emb);
        if (mounted) {
          setState(() => _capturedCount = _multiEmbeddings.length);
        }
        return true;
      } catch (e) {
        debugPrint('❌ Capture sample failed (attempt $attempt): $e');
        if (attempt == retries) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Capture failed: $e')),
            );
          }
          return false;
        }
        await Future.delayed(const Duration(milliseconds: 400));
      }
    }
    return false;
  }

  Future<void> _startMultiCapture() async {
    FocusScope.of(context).unfocus();
    if (!_validateEmployeeIdField()) return;

    setState(() {
      _multiCaptureRunning = true;
      _multiImages.clear();
      _multiEmbeddings.clear();
      _capturedCount = 0;
      _currentInstruction = '';
    });

    await _initializeCamera();
    final plan = _buildInstructionPlan(_targetSamples);

    for (final step in plan) {
      if (!_multiCaptureRunning) break; // user may cancel
      final ok = await _captureOneSample(step);
      if (!ok) {
        // Give the user the option to retry the failed step
        final retry = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: const Text('Capture failed'),
            content: const Text('Could not capture a usable face. Try this step again?'),
            actions: [
              TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Skip')),
              FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Retry')),
            ],
          ),
        );
        if (retry == true) {
          if (!await _captureOneSample(step)) {
            // still failed – continue to next step
          }
        }
      }
    }

    if (!_multiCaptureRunning) return;

    if (_multiEmbeddings.length < 5) {
      // Not enough usable samples
      if (mounted) {
        setState(() => _multiCaptureRunning = false);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Need at least 5 good samples. Please try again.')),
      );
      return;
    }

    // Auto-proceed to registration with collected embeddings
    await _registerWithEmbeddings(_multiEmbeddings, firstImageForPHash: _multiImages.first);
    if (mounted) {
      setState(() => _multiCaptureRunning = false);
    }
  }

  void _cancelMultiCapture() {
    setState(() {
      _multiCaptureRunning = false;
      _currentInstruction = '';
    });
  }

  // ------- REGISTRATION PIPELINE -------

  bool _validateEmployeeIdField() {
    if ((_employeeIdController.text).trim().isEmpty) {
      _showError('Enter Employee ID.');
      return false;
    }
    return true;
  }

  Future<void> registerEmployee() async {
    // Legacy single-shot path preserved
    if (!_validateEmployeeIdField() || _capturedImage == null) {
      _showError('Please enter an Employee ID and capture an image.');
      return;
    }

    setState(() => _isRegistering = true);
    try {
      final employeeId = _employeeIdController.text.trim();

      // Verify employee exists locally
      final exists = await DatabaseService.instance.employeeExists(employeeId);
      if (!exists) {
        _showError('Employee ID not found. Please sync data or enter a valid ID.');
        return;
      }

      // Build one embedding from the single capture
      final bytes = await _capturedImage!.readAsBytes();
      final base64Image = base64Encode(bytes);

      final emb = await _faceRecognitionService.getEmbeddingForRegistration(base64Image);
      if (emb == null) {
        _showError('No face detected. Please retake the picture.');
        return;
      }

      // Store as single vector (keeps backward compatibility)
      await _registerWithEmbeddings([emb], firstImageForPHash: _capturedImage);
      _capturedImage = null; // reset single-shot after success path
    } catch (e) {
      debugPrint('❌ Error during registration: $e');
      _showError('An error occurred during registration.');
    } finally {
      if (mounted) setState(() => _isRegistering = false);
    }
  }

  Future<void> _registerWithEmbeddings(List<List<double>> embeddings, {XFile? firstImageForPHash}) async {
    final employeeId = _employeeIdController.text.trim();

    // Persist embeddings: supports single OR multi (FaceRecognitionService already handles arrays)
    final jsonEmbedding = jsonEncode(embeddings);

    // Save phash (keep previous behavior – single pHash stored; use first image)
    if (firstImageForPHash != null) {
      try {
        final phash = await _faceRecognitionService.getPHashForRegistration(
          base64Encode(await firstImageForPHash.readAsBytes()),
        );
        if (phash != null) {
          await StorageService().saveFaceHash(employeeId, phash);
        }
        await _faceRecognitionService.logAudit('register', {
          'employeeId': employeeId,
          'hasEmbedding': true,
          'hasPHash': phash != null,
          'samples': embeddings.length,
        });
      } catch (e) {
        debugPrint('⚠️ pHash save failed: $e');
      }
    } else {
      await _faceRecognitionService.logAudit('register', {
        'employeeId': employeeId,
        'hasEmbedding': true,
        'hasPHash': false,
        'samples': embeddings.length,
      });
    }

    // Update local employee record with embedding(s)
    await DatabaseService.instance.updateEmployeeEmbedding(employeeId, jsonEmbedding);

    // Also update local profile row and attempt sync (preserves your previous flow)
    final Position? position = await _getCurrentLocation();
    final apiProfile = EmployeeProfileRegistration(
      employeeId: employeeId,
      employeeImageData: jsonEmbedding, // now can be [ [..], [..], ... ]
    );

    final localProfileData = {
      'employee_id': employeeId,
      'name': null, // unchanged: name not collected here
      'image_data': jsonEmbedding,
      'latitude': position?.latitude,
      'longitude': position?.longitude,
      'timestamp': DateTime.now().toIso8601String(),
    };

    await DatabaseService.instance.updateEmployeeProfile(localProfileData);

    // Try to sync immediately if online; else queue for later (unchanged behavior)
    final connectivityResult = await Connectivity().checkConnectivity();
    final isOnline = connectivityResult != ConnectivityResult.none;

    if (isOnline) {
      final ok = await _apiService.sendBulkProfileData([apiProfile.toMap()]);
      if (!ok) {
        await DatabaseService.instance.addProfileToSyncQueue(apiProfile.employeeId);
        _showSuccessAndReset('Saved locally. Will sync later.');
        return;
      }
      _showSuccessAndReset('Registration successful and synced.');
    } else {
      await DatabaseService.instance.addProfileToSyncQueue(apiProfile.employeeId);
      _showSuccessAndReset('Saved locally. Will sync when online.');
    }
  }

  // ------- GEO -------

  Future<Position?> _getCurrentLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showError('Location services are disabled.');
        return null;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _showError('Location permissions are denied.');
          return null;
        }
      }
      if (permission == LocationPermission.deniedForever) {
        _showError('Location permissions are permanently denied.');
        return null;
      }
      return await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    } catch (e) {
      debugPrint('⚠️ Location error: $e');
      return null;
    }
  }

  // ------- UI HELPERS -------

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  void _showSuccessAndReset(String message) {
    if (!mounted) return;
    setState(() => _isSuccessOverlayVisible = true);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));

    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      setState(() {
        _isSuccessOverlayVisible = false;
        _employeeIdController.clear();

        // Reset single + multi states
        _capturedImage = null;
        _multiImages.clear();
        _multiEmbeddings.clear();
        _capturedCount = 0;
        _currentInstruction = '';
        _multiCaptureRunning = false;
      });
    });
  }

  // ------- UI -------

  @override
  Widget build(BuildContext context) {
    final canRegisterSingle = _capturedImage != null && !_multiCaptureRunning;
    final canStartMulti = !_multiCaptureRunning;

    return Scaffold(
      backgroundColor: const Color(0xFFF0F2F5),
      appBar: AppBar(
        title: const Text('Face Registration'),
      ),
      body: Stack(
        children: [
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 560),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      // Employee ID
                      TextFormField(
                        controller: _employeeIdController,
                        decoration: const InputDecoration(
                          labelText: 'Employee ID',
                          border: OutlineInputBorder(),
                        ),
                        validator: (v) => (v == null || v.trim().isEmpty) ? 'Required' : null,
                      ),
                      const SizedBox(height: 16),

                      // Camera / Preview area
                      AspectRatio(
                        aspectRatio: 3 / 4,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: _buildCameraArea(),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Multi-sample controls
                      Row(
                        children: [
                          const Text('Samples:'),
                          const SizedBox(width: 8),
                          DropdownButton<int>(
                            value: _targetSamples,
                            items: List.generate(6, (i) => 5 + i)
                                .map((n) => DropdownMenuItem(value: n, child: Text('$n')))
                                .toList(),
                            onChanged: canStartMulti
                                ? (n) {
                              if (n == null) return;
                              setState(() => _targetSamples = n.clamp(5, 10));
                            }
                                : null,
                          ),
                          const Spacer(),
                          if (_multiCaptureRunning)
                            Text('$_capturedCount / $_targetSamples',
                                style: const TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      if (_multiCaptureRunning || _currentInstruction.isNotEmpty)
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            _currentInstruction.isEmpty
                                ? 'Capturing...'
                                : 'Step: $_currentInstruction',
                            style: const TextStyle(fontSize: 13, color: Colors.blueGrey),
                          ),
                        ),

                      const SizedBox(height: 16),

                      // Action buttons
                      Row(
                        children: [
                          // Single-shot controls (preserved)
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _multiCaptureRunning ? null : _takePicture,
                              icon: const Icon(Icons.camera_alt_outlined),
                              label: const Text('Capture'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: (_capturedImage != null && !_multiCaptureRunning) ? _retakePicture : null,
                              icon: const Icon(Icons.refresh),
                              label: const Text('Retake'),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      Row(
                        children: [
                          // Start/Cancel multi-sample
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: canStartMulti ? _startMultiCapture : null,
                              icon: const Icon(Icons.auto_awesome_motion),
                              label: const Text('Start Multi-Capture'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: _multiCaptureRunning ? _cancelMultiCapture : null,
                              icon: const Icon(Icons.stop_circle_outlined),
                              label: const Text('Cancel'),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      // Register buttons
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: (canRegisterSingle && !_isRegistering) ? registerEmployee : null,
                              icon: const Icon(Icons.verified_user),
                              label: _isRegistering
                                  ? const Text('Registering...')
                                  : const Text('Register (Single)'),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: (!_multiCaptureRunning &&
                                  _multiEmbeddings.length >= 5 &&
                                  !_isRegistering)
                                  ? () => _registerWithEmbeddings(_multiEmbeddings,
                                  firstImageForPHash:
                                  _multiImages.isNotEmpty ? _multiImages.first : null)
                                  : null,
                              icon: const Icon(Icons.verified),
                              label: _isRegistering
                                  ? const Text('Registering...')
                                  : const Text('Register (Multi)'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          if (_isSuccessOverlayVisible)
            Container(
              color: Colors.black54,
              child: const Center(
                child: Icon(Icons.check_circle, size: 120, color: Colors.lightGreenAccent),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCameraArea() {
    if (_capturedImage != null && !_multiCaptureRunning) {
      return Image.file(File(_capturedImage!.path), fit: BoxFit.cover);
    }
    if (_isCameraInitialized && _cameraController != null) {
      return CameraPreview(_cameraController!);
    }
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.camera_alt, size: 64, color: Colors.white54),
          SizedBox(height: 8),
          Text('Camera not ready', style: TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }
}













// // import 'dart:convert';
// // import 'dart:io';
// // import 'package:camera/camera.dart';
// // import 'package:flutter/material.dart';
// // import 'package:kiosk/app/core/services/database_service.dart';
// // import 'package:kiosk/app/core/services/face_recognition_service.dart'; // Import the service
// //
// // class RegistrationScreen extends StatefulWidget {
// //   const RegistrationScreen({super.key});
// //
// //   @override
// //   State<RegistrationScreen> createState() => _RegistrationScreenState();
// // }
// //
// // class _RegistrationScreenState extends State<RegistrationScreen> {
// //   final _formKey = GlobalKey<FormState>();
// //   final TextEditingController _employeeIdController = TextEditingController();
// //
// //   // --- State and Service Variables ---
// //   final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
// //   CameraController? _cameraController;
// //   XFile? _capturedImage;
// //   bool _isCameraInitialized = false;
// //   bool _isRegistering = false; // To show a loading indicator
// //   bool _isSuccessOverlayVisible = false;
// //
// //   @override
// //   void dispose() {
// //     _employeeIdController.dispose();
// //     _cameraController?.dispose();
// //     super.dispose();
// //   }
// //
// //   Future<void> _initializeCamera() async {
// //     final cameras = await availableCameras();
// //     final frontCamera = cameras.firstWhere(
// //             (camera) => camera.lensDirection == CameraLensDirection.front,
// //         orElse: () => cameras.first);
// //
// //     _cameraController = CameraController(
// //       frontCamera,
// //       ResolutionPreset.medium,
// //     );
// //
// //     try {
// //       await _cameraController!.initialize();
// //       if (!mounted) return;
// //       setState(() {
// //         _isCameraInitialized = true;
// //       });
// //     } catch (e) {
// //       print("Error initializing camera: $e");
// //     }
// //   }
// //
// //   void _takePicture() async {
// //     if (!_cameraController!.value.isInitialized) return;
// //
// //     final image = await _cameraController!.takePicture();
// //
// //     setState(() {
// //       _capturedImage = image;
// //       _isCameraInitialized = false;
// //       _cameraController?.dispose();
// //       _cameraController = null;
// //     });
// //   }
// //
// //   void _retakePicture() {
// //     setState(() {
// //       _capturedImage = null;
// //     });
// //     _initializeCamera();
// //   }
// //
// //   // --- UPDATED REGISTRATION LOGIC ---
// //   void _registerEmployee() async {
// //     if (!_formKey.currentState!.validate() || _capturedImage == null) {
// //       _showError('Please enter an Employee ID and capture an image.');
// //       return;
// //     }
// //
// //     setState(() { _isRegistering = true; });
// //
// //     try {
// //       final employeeId = _employeeIdController.text;
// //
// //       // 1. Check if the employee ID exists in the local database
// //       final bool isValidEmployee = await DatabaseService.instance.employeeExists(employeeId);
// //
// //       if (!isValidEmployee) {
// //         _showError('Employee ID not found. Please enter a valid ID.');
// //         return; // Stop the registration if the ID is not valid
// //       }
// //
// //       // 2. Process the image to get the face embedding
// //       final imageBytes = await File(_capturedImage!.path).readAsBytes();
// //       final base64Image = base64Encode(imageBytes);
// //       final List<double>? embedding = await _faceRecognitionService.getEmbeddingForRegistration(base64Image);
// //
// //       if (embedding == null) {
// //         _showError('No face detected or error processing image. Please retake.');
// //         return; // Stop the registration process
// //       }
// //
// //       // 3. Encode the embedding to a JSON string
// //       final jsonEmbedding = jsonEncode(embedding);
// //
// //       // 4. Update the existing employee record with the face embedding
// //       await DatabaseService.instance.updateEmployeeEmbedding(employeeId, jsonEmbedding);
// //       print('Face registered for Employee ID: $employeeId');
// //
// //       // Show success and reset the screen
// //       _showSuccessAndReset();
// //
// //     } catch (e) {
// //       print("Error during registration: $e");
// //       _showError('An error occurred during registration.');
// //     } finally {
// //       if (mounted) {
// //         setState(() { _isRegistering = false; });
// //       }
// //     }
// //   }
// //
// //   void _showError(String message) {
// //     if (mounted) {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         SnackBar(
// //             backgroundColor: Colors.red,
// //             content: Text(message)
// //         ),
// //       );
// //     }
// //   }
// //
// //   void _showSuccessAndReset() {
// //     setState(() { _isSuccessOverlayVisible = true; });
// //     Future.delayed(const Duration(seconds: 2), () {
// //       if (mounted) {
// //         setState(() {
// //           _isSuccessOverlayVisible = false;
// //           _employeeIdController.clear();
// //           _capturedImage = null;
// //         });
// //       }
// //     });
// //   }
// //
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor: const Color(0xFFF0F2F5),
// //       body: Stack(
// //         children: [
// //           Center(
// //             child: SingleChildScrollView(
// //               padding: const EdgeInsets.all(24.0),
// //               child: SizedBox(
// //                 width: 450,
// //                 child: Form(
// //                   key: _formKey,
// //                   child: Column(
// //                     mainAxisAlignment: MainAxisAlignment.center,
// //                     children: [
// //                       const Text(
// //                         'Employee ID',
// //                         style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
// //                       ),
// //                       const SizedBox(height: 8),
// //                       SizedBox(
// //                         height: 70,
// //                         child: TextFormField(
// //                           controller: _employeeIdController,
// //                           autofocus: true,
// //                           textAlignVertical: TextAlignVertical.center,
// //                           style: const TextStyle(
// //                             fontSize: 20.0,
// //                             fontWeight: FontWeight.w500,
// //                           ),
// //                           decoration: InputDecoration(
// //                             hintText: 'Enter Employee ID',
// //                             filled: true,
// //                             fillColor: Colors.white,
// //                             border: OutlineInputBorder(
// //                               borderRadius: BorderRadius.circular(12.0),
// //                               borderSide: const BorderSide(
// //                                 color: Color(0xFFCED4DA),
// //                                 width: 2.0,
// //                               ),
// //                             ),
// //                             enabledBorder: OutlineInputBorder(
// //                               borderRadius: BorderRadius.circular(12.0),
// //                               borderSide: const BorderSide(
// //                                 color: Color(0xFFCED4DA),
// //                                 width: 2.0,
// //                               ),
// //                             ),
// //                             focusedBorder: OutlineInputBorder(
// //                               borderRadius: BorderRadius.circular(12.0),
// //                               borderSide: BorderSide(
// //                                 color: Theme.of(context).primaryColor,
// //                                 width: 2.0,
// //                               ),
// //                             ),
// //                           ),
// //                           validator: (value) {
// //                             if (value == null || value.isEmpty) {
// //                               return 'Please enter an Employee ID';
// //                             }
// //                             return null;
// //                           },
// //                         ),
// //                       ),
// //                       const SizedBox(height: 32),
// //                       _buildCameraSection(),
// //                       const SizedBox(height: 40),
// //                       _buildButtonControls(),
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //             ),
// //           ),
// //           if (_isSuccessOverlayVisible) _buildSuccessOverlay(),
// //           if (_isRegistering) _buildLoadingOverlay(), // Loading overlay
// //         ],
// //       ),
// //     );
// //   }
// //
// //   Widget _buildCameraSection() {
// //     return Material(
// //       elevation: 4.0,
// //       borderRadius: BorderRadius.circular(20.0),
// //       child: ClipRRect(
// //         borderRadius: BorderRadius.circular(20.0),
// //         child: Container(
// //           width: 300,
// //           height: 400,
// //           color: Colors.black,
// //           child: Builder(
// //             builder: (context) {
// //               if (_capturedImage != null) {
// //                 return Image.file(File(_capturedImage!.path), fit: BoxFit.cover);
// //               }
// //               if (_isCameraInitialized && _cameraController != null) {
// //                 return CameraPreview(_cameraController!);
// //               }
// //               return const Center(
// //                 child: Column(
// //                   mainAxisAlignment: MainAxisAlignment.center,
// //                   children: [
// //                     Icon(Icons.camera_alt, size: 64, color: Colors.grey),
// //                     SizedBox(height: 16),
// //                     Text('Camera Preview', style: TextStyle(color: Colors.grey)),
// //                   ],
// //                 ),
// //               );
// //             },
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _buildButtonControls() {
// //     // Disable buttons while registering
// //     final bool isButtonDisabled = _isRegistering;
// //
// //     if (_capturedImage != null) {
// //       return Row(
// //         children: [
// //           Expanded(
// //             child: OutlinedButton(
// //               onPressed: isButtonDisabled ? null : _retakePicture,
// //               style: OutlinedButton.styleFrom(
// //                 padding: const EdgeInsets.symmetric(vertical: 16),
// //               ),
// //               child: const Text('Retake', style: TextStyle(fontSize: 18)),
// //             ),
// //           ),
// //           const SizedBox(width: 16),
// //           Expanded(
// //             child: ElevatedButton(
// //               onPressed: isButtonDisabled ? null : _registerEmployee,
// //               style: ElevatedButton.styleFrom(
// //                 padding: const EdgeInsets.symmetric(vertical: 16),
// //               ),
// //               child: const Text('Register', style: TextStyle(fontSize: 18)),
// //             ),
// //           ),
// //         ],
// //       );
// //     }
// //     if (_isCameraInitialized) {
// //       return ElevatedButton(
// //         onPressed: isButtonDisabled ? null : _takePicture,
// //         style: ElevatedButton.styleFrom(
// //           padding: const EdgeInsets.symmetric(vertical: 16),
// //           minimumSize: const Size(double.infinity, 50),
// //         ),
// //         child: const Text('Take Picture', style: TextStyle(fontSize: 18)),
// //       );
// //     }
// //     return ElevatedButton(
// //       onPressed: isButtonDisabled ? null : _initializeCamera,
// //       style: ElevatedButton.styleFrom(
// //         padding: const EdgeInsets.symmetric(vertical: 16),
// //         minimumSize: const Size(double.infinity, 50),
// //       ),
// //       child: const Text('Capture Image', style: TextStyle(fontSize: 18)),
// //     );
// //   }
// //
// //   Widget _buildSuccessOverlay() {
// //     return Container(
// //       color: Colors.green.withOpacity(0.85),
// //       child: const Center(
// //         child: Icon(
// //           Icons.check_circle,
// //           size: 150,
// //           color: Colors.white,
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _buildLoadingOverlay() {
// //     return Container(
// //       color: Colors.black.withOpacity(0.5),
// //       child: const Center(
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: [
// //             CircularProgressIndicator(color: Colors.white),
// //             SizedBox(height: 20),
// //             Text(
// //               'Processing Face...',
// //               style: TextStyle(color: Colors.white, fontSize: 18, decoration: TextDecoration.none),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// // import 'dart:convert';
// // import 'dart:io';
// // import 'package:camera/camera.dart';
// // import 'package:connectivity_plus/connectivity_plus.dart';
// // import 'package:flutter/material.dart';
// // import 'package:geolocator/geolocator.dart';
// // import 'package:kiosk/app/core/models /employee_profile_registration.dart';
// // import 'package:kiosk/app/core/services/api_service.dart';
// // import 'package:kiosk/app/core/services/database_service.dart';
// // import 'package:kiosk/app/core/services/face_recognition_service.dart';
// //
// // class RegistrationScreen extends StatefulWidget {
// //   const RegistrationScreen({super.key});
// //
// //   @override
// //   State<RegistrationScreen> createState() => _RegistrationScreenState();
// // }
// //
// // class _RegistrationScreenState extends State<RegistrationScreen> {
// //   final _formKey = GlobalKey<FormState>();
// //   final TextEditingController _employeeIdController = TextEditingController();
// //   final TextEditingController _nameController = TextEditingController(); // For employee name
// //
// //   // --- State and Service Variables ---
// //   final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
// //   final ApiService _apiService = ApiService();
// //   CameraController? _cameraController;
// //   XFile? _capturedImage;
// //   bool _isCameraInitialized = false;
// //   bool _isRegistering = false; // To show a loading indicator
// //   bool _isSuccessOverlayVisible = false;
// //
// //   @override
// //   void dispose() {
// //     _employeeIdController.dispose();
// //     _nameController.dispose();
// //     _cameraController?.dispose();
// //     super.dispose();
// //   }
// //
// //   Future<void> _initializeCamera() async {
// //     final cameras = await availableCameras();
// //     final frontCamera = cameras.firstWhere(
// //             (camera) => camera.lensDirection == CameraLensDirection.front,
// //         orElse: () => cameras.first);
// //
// //     _cameraController = CameraController(
// //       frontCamera,
// //       ResolutionPreset.medium,
// //     );
// //
// //     try {
// //       await _cameraController!.initialize();
// //       if (!mounted) return;
// //       setState(() {
// //         _isCameraInitialized = true;
// //       });
// //     } catch (e) {
// //       print("Error initializing camera: $e");
// //     }
// //   }
// //
// //   void _takePicture() async {
// //     if (!_cameraController!.value.isInitialized) return;
// //
// //     final image = await _cameraController!.takePicture();
// //
// //     setState(() {
// //       _capturedImage = image;
// //       _isCameraInitialized = false;
// //       _cameraController?.dispose();
// //       _cameraController = null;
// //     });
// //   }
// //
// //   void _retakePicture() {
// //     setState(() {
// //       _capturedImage = null;
// //     });
// //     _initializeCamera();
// //   }
// //
// //   // --- UPDATED OFFLINE-FIRST REGISTRATION LOGIC ---
// //   void _registerEmployee() async {
// //     if (!_formKey.currentState!.validate() || _capturedImage == null) {
// //       _showError('Please fill all fields and capture an image.');
// //       return;
// //     }
// //
// //     setState(() { _isRegistering = true; });
// //
// //     try {
// //       // 1. Get face embedding
// //       final imageBytes = await File(_capturedImage!.path).readAsBytes();
// //       final base64Image = base64Encode(imageBytes);
// //       final List<double>? embedding = await _faceRecognitionService.getEmbeddingForRegistration(base64Image);
// //
// //       if (embedding == null) {
// //         _showError('No face detected. Please retake the picture.');
// //         return;
// //       }
// //       final jsonEmbedding = jsonEncode(embedding);
// //
// //       // 2. Get Geo-location (optional)
// //       Position? position = await _getCurrentLocation();
// //
// //       // 3. Create the profile object using the correct model
// //       final profile = EmployeeProfileRegistration(
// //         employeeId: _employeeIdController.text,
// //         employeeImageData: jsonEmbedding,
// //       );
// //
// //       // This is the data that will be saved locally, including optional fields
// //       final localProfileData = {
// //         'employee_id': profile.employeeId,
// //         'name': _nameController.text,
// //         'image_data': profile.employeeImageData,
// //         'latitude': position?.latitude,
// //         'longitude': position?.longitude,
// //         'timestamp': DateTime.now().toIso8601String(),
// //       };
// //
// //
// //       // 4. Check connectivity
// //       final connectivityResult = await Connectivity().checkConnectivity();
// //       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) || connectivityResult.contains(ConnectivityResult.wifi);
// //
// //       if (isOnline) {
// //         // REAL-TIME SYNC
// //         print("Device is online. Sending profile directly to server...");
// //         final success = await _apiService.sendBulkProfileData([profile.toMap()]);
// //
// //         // Always save the full profile locally
// //         await DatabaseService.instance.updateEmployeeProfile(localProfileData);
// //
// //         if (success) {
// //           print("Profile sent to server and saved locally.");
// //           _showSuccessAndReset("Registration successful and synced.");
// //         } else {
// //           // If API fails, add to queue for later
// //           print("API call failed. Adding profile to sync queue.");
// //           await DatabaseService.instance.addProfileToSyncQueue(profile.employeeId);
// //           _showSuccessAndReset("Saved locally. Will sync later.");
// //         }
// //       } else {
// //         // OFFLINE REGISTRATION
// //         print("Device is offline. Saving profile to sync queue.");
// //         await DatabaseService.instance.updateEmployeeProfile(localProfileData);
// //         await DatabaseService.instance.addProfileToSyncQueue(profile.employeeId);
// //         _showSuccessAndReset("Saved locally. Will sync when online.");
// //       }
// //
// //     } catch (e) {
// //       print("Error during registration: $e");
// //       _showError('An error occurred during registration.');
// //     } finally {
// //       if (mounted) {
// //         setState(() { _isRegistering = false; });
// //       }
// //     }
// //   }
// //
// //   // Helper to get current location
// //   Future<Position?> _getCurrentLocation() async {
// //     try {
// //       bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
// //       if (!serviceEnabled) {
// //         _showError("Location services are disabled.");
// //         return null;
// //       }
// //
// //       LocationPermission permission = await Geolocator.checkPermission();
// //       if (permission == LocationPermission.denied) {
// //         permission = await Geolocator.requestPermission();
// //         if (permission == LocationPermission.denied) {
// //           _showError("Location permissions are denied.");
// //           return null;
// //         }
// //       }
// //
// //       if (permission == LocationPermission.deniedForever) {
// //         _showError("Location permissions are permanently denied.");
// //         return null;
// //       }
// //
// //       return await Geolocator.getCurrentPosition();
// //     } catch (e) {
// //       print("Error getting location: $e");
// //       return null;
// //     }
// //   }
// //
// //   void _showError(String message) {
// //     if (mounted) {
// //       ScaffoldMessenger.of(context).showSnackBar(
// //         SnackBar(backgroundColor: Colors.red, content: Text(message)),
// //       );
// //     }
// //   }
// //
// //   void _showSuccessAndReset([String? message]) {
// //     ScaffoldMessenger.of(context).showSnackBar(
// //       SnackBar(
// //         backgroundColor: Colors.green,
// //         content: Text(message ?? 'Registration successful!'),
// //       ),
// //     );
// //     setState(() { _isSuccessOverlayVisible = true; });
// //     Future.delayed(const Duration(seconds: 2), () {
// //       if (mounted) {
// //         setState(() {
// //           _isSuccessOverlayVisible = false;
// //           _employeeIdController.clear();
// //           _nameController.clear();
// //           _capturedImage = null;
// //         });
// //       }
// //     });
// //   }
// //
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Scaffold(
// //       backgroundColor: const Color(0xFFF0F2F5),
// //       body: Stack(
// //         children: [
// //           Center(
// //             child: SingleChildScrollView(
// //               padding: const EdgeInsets.all(24.0),
// //               child: SizedBox(
// //                 width: 450,
// //                 child: Form(
// //                   key: _formKey,
// //                   child: Column(
// //                     mainAxisAlignment: MainAxisAlignment.center,
// //                     children: [
// //                       const Text(
// //                         'Employee Registration',
// //                         style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
// //                       ),
// //                       const SizedBox(height: 24),
// //                       // Employee ID Field
// //                       TextFormField(
// //                         controller: _employeeIdController,
// //                         decoration: const InputDecoration(labelText: 'Employee ID'),
// //                         validator: (value) => value!.isEmpty ? 'Please enter an ID' : null,
// //                       ),
// //                       const SizedBox(height: 16),
// //                       // Employee Name Field
// //                       TextFormField(
// //                         controller: _nameController,
// //                         decoration: const InputDecoration(labelText: 'Employee Name'),
// //                         validator: (value) => value!.isEmpty ? 'Please enter a name' : null,
// //                       ),
// //                       const SizedBox(height: 32),
// //                       _buildCameraSection(),
// //                       const SizedBox(height: 40),
// //                       _buildButtonControls(),
// //                     ],
// //                   ),
// //                 ),
// //               ),
// //             ),
// //           ),
// //           if (_isSuccessOverlayVisible) _buildSuccessOverlay(),
// //           if (_isRegistering) _buildLoadingOverlay(), // Loading overlay
// //         ],
// //       ),
// //     );
// //   }
// //
// //   Widget _buildCameraSection() {
// //     return Material(
// //       elevation: 4.0,
// //       borderRadius: BorderRadius.circular(20.0),
// //       child: ClipRRect(
// //         borderRadius: BorderRadius.circular(20.0),
// //         child: Container(
// //           width: 300,
// //           height: 400,
// //           color: Colors.black,
// //           child: Builder(
// //             builder: (context) {
// //               if (_capturedImage != null) {
// //                 return Image.file(File(_capturedImage!.path), fit: BoxFit.cover);
// //               }
// //               if (_isCameraInitialized && _cameraController != null) {
// //                 return CameraPreview(_cameraController!);
// //               }
// //               return const Center(
// //                 child: Column(
// //                   mainAxisAlignment: MainAxisAlignment.center,
// //                   children: [
// //                     Icon(Icons.camera_alt, size: 64, color: Colors.grey),
// //                     SizedBox(height: 16),
// //                     Text('Camera Preview', style: TextStyle(color: Colors.grey)),
// //                   ],
// //                 ),
// //               );
// //             },
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _buildButtonControls() {
// //     final bool isButtonDisabled = _isRegistering;
// //
// //     if (_capturedImage != null) {
// //       return Row(
// //         children: [
// //           Expanded(
// //             child: OutlinedButton(
// //               onPressed: isButtonDisabled ? null : _retakePicture,
// //               style: OutlinedButton.styleFrom(
// //                 padding: const EdgeInsets.symmetric(vertical: 16),
// //               ),
// //               child: const Text('Retake', style: TextStyle(fontSize: 18)),
// //             ),
// //           ),
// //           const SizedBox(width: 16),
// //           Expanded(
// //             child: ElevatedButton(
// //               onPressed: isButtonDisabled ? null : _registerEmployee,
// //               style: ElevatedButton.styleFrom(
// //                 padding: const EdgeInsets.symmetric(vertical: 16),
// //               ),
// //               child: const Text('Register', style: TextStyle(fontSize: 18)),
// //             ),
// //           ),
// //         ],
// //       );
// //     }
// //     if (_isCameraInitialized) {
// //       return ElevatedButton(
// //         onPressed: isButtonDisabled ? null : _takePicture,
// //         style: ElevatedButton.styleFrom(
// //           padding: const EdgeInsets.symmetric(vertical: 16),
// //           minimumSize: const Size(double.infinity, 50),
// //         ),
// //         child: const Text('Take Picture', style: TextStyle(fontSize: 18)),
// //       );
// //     }
// //     return ElevatedButton(
// //       onPressed: isButtonDisabled ? null : _initializeCamera,
// //       style: ElevatedButton.styleFrom(
// //         padding: const EdgeInsets.symmetric(vertical: 16),
// //         minimumSize: const Size(double.infinity, 50),
// //       ),
// //       child: const Text('Capture Image', style: TextStyle(fontSize: 18)),
// //     );
// //   }
// //
// //   Widget _buildSuccessOverlay() {
// //     return Container(
// //       color: Colors.green.withOpacity(0.85),
// //       child: const Center(
// //         child: Icon(
// //           Icons.check_circle,
// //           size: 150,
// //           color: Colors.white,
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget _buildLoadingOverlay() {
// //     return Container(
// //       color: Colors.black.withOpacity(0.5),
// //       child: const Center(
// //         child: Column(
// //           mainAxisAlignment: MainAxisAlignment.center,
// //           children: [
// //             CircularProgressIndicator(color: Colors.white),
// //             SizedBox(height: 20),
// //             Text(
// //               'Processing...',
// //               style: TextStyle(color: Colors.white, fontSize: 18, decoration: TextDecoration.none),
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
//
// import 'dart:convert';
// import 'dart:io';
// import 'package:kiosk/app/core/services/storage_service.dart'; // ADD
// import 'package:camera/camera.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:geolocator/geolocator.dart';
// import 'package:kiosk/app/core/models/employee_profile_registration.dart';
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/face_recognition_service.dart';
//
// class RegistrationScreen extends StatefulWidget {
//   const RegistrationScreen({super.key});
//
//   @override
//   State<RegistrationScreen> createState() => _RegistrationScreenState();
// }
//
// class _RegistrationScreenState extends State<RegistrationScreen> {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController _employeeIdController = TextEditingController();
//
//   // --- State and Service Variables ---
//   final FaceRecognitionService _faceRecognitionService = FaceRecognitionService();
//   final ApiService _apiService = ApiService();
//   CameraController? _cameraController;
//   XFile? _capturedImage;
//   bool _isCameraInitialized = false;
//   bool _isRegistering = false; // To show a loading indicator
//   bool _isSuccessOverlayVisible = false;
//
//   @override
//   void dispose() {
//     _employeeIdController.dispose();
//     _cameraController?.dispose();
//     super.dispose();
//   }
//
//   Future<void> _initializeCamera() async {
//     final cameras = await availableCameras();
//     final frontCamera = cameras.firstWhere(
//             (camera) => camera.lensDirection == CameraLensDirection.front,
//         orElse: () => cameras.first);
//
//     _cameraController = CameraController(
//       frontCamera,
//       ResolutionPreset.medium,
//     );
//
//     try {
//       await _cameraController!.initialize();
//       if (!mounted) return;
//       setState(() {
//         _isCameraInitialized = true;
//       });
//     } catch (e) {
//       print("Error initializing camera: $e");
//     }
//   }
//
//   void _takePicture() async {
//     if (!_cameraController!.value.isInitialized) return;
//
//     final image = await _cameraController!.takePicture();
//
//     setState(() {
//       _capturedImage = image;
//       _isCameraInitialized = false;
//       _cameraController?.dispose();
//       _cameraController = null;
//     });
//   }
//
//   void _retakePicture() {
//     setState(() {
//       _capturedImage = null;
//     });
//     _initializeCamera();
//   }
//
//   // --- UPDATED OFFLINE-FIRST REGISTRATION LOGIC ---
//   void _registerEmployee() async {
//     if (!_formKey.currentState!.validate() || _capturedImage == null) {
//       _showError('Please enter an Employee ID and capture an image.');
//       return;
//     }
//
//     setState(() { _isRegistering = true; });
//
//     try {
//       final employeeId = _employeeIdController.text;
//
//       // 1. Check if the employee ID exists in the local database
//       final bool isValidEmployee = await DatabaseService.instance.employeeExists(employeeId);
//
//       if (!isValidEmployee) {
//         _showError('Employee ID not found. Please sync data or enter a valid ID.');
//         return;
//       }
//
//       // 2. Get face embedding
//       final imageBytes = await File(_capturedImage!.path).readAsBytes();
//       final base64Image = base64Encode(imageBytes);
//       final List<double>? embedding = await _faceRecognitionService.getEmbeddingForRegistration(base64Image);
//
//       if (embedding == null) {
//         _showError('No face detected. Please retake the picture.');
//         return;
//       }
//       // Persist as JSON string into image_data
//       await DatabaseService.instance.updateEmployeeEmbedding(
//         employeeId,
//         jsonEncode(embedding), // <- L2-normalized embedding stored
//       );
//       final jsonEmbedding = jsonEncode(embedding);
//
//       // 3. Get Geo-location (optional)
//       Position? position = await _getCurrentLocation();
//
//       // 4. Create the profile object for the API
//       final apiProfile = EmployeeProfileRegistration(
//         employeeId: employeeId,
//         employeeImageData: jsonEmbedding,
//       );
//
//       // 5. Create the full profile data for the local database
//       final localProfileData = {
//         'employee_id': employeeId,
//         'name': null, // Name is not collected from the UI
//         'image_data': jsonEmbedding,
//         'latitude': position?.latitude,
//         'longitude': position?.longitude,
//         'timestamp': DateTime.now().toIso8601String(),
//       };
//
// // Persist as JSON string into image_data (L2-normalized embedding stored)
//       await DatabaseService.instance.updateEmployeeEmbedding(
//         employeeId,
//         jsonEncode(embedding),
//       );
//
// // --- ADD: also compute & persist aHash for tie-breaks (no schema change) ---
//       final String? phash = await _faceRecognitionService.getPHashForRegistration(base64Image);
//       if (phash != null) {
//         await StorageService().saveFaceHash(employeeId, phash);
//       }
//
// // --- ADD: audit log for registration completeness (optional but useful) ---
//       await _faceRecognitionService.logAudit('register', {
//         'employeeId': employeeId,
//         'hasEmbedding': true,
//         'hasPHash': phash != null,
//       });
//
//
//       // 6. Check connectivity
//       final connectivityResult = await Connectivity().checkConnectivity();
//       final isOnline = connectivityResult.contains(ConnectivityResult.mobile) || connectivityResult.contains(ConnectivityResult.wifi);
//
//       // 7. Update local DB first
//       await DatabaseService.instance.updateEmployeeProfile(localProfileData);
//
//       if (isOnline) {
//         // REAL-TIME SYNC
//         print("Device is online. Sending profile directly to server...");
//         final success = await _apiService.sendBulkProfileData([apiProfile.toMap()]);
//
//         if (success) {
//           print("Profile sent to server and saved locally.");
//           _showSuccessAndReset("Registration successful and synced.");
//         } else {
//           // If API fails, add to queue for later
//           print("API call failed. Adding profile to sync queue.");
//           await DatabaseService.instance.addProfileToSyncQueue(apiProfile.employeeId);
//           _showSuccessAndReset("Saved locally. Will sync later.");
//         }
//       } else {
//         // OFFLINE REGISTRATION
//         print("Device is offline. Adding profile to sync queue.");
//         await DatabaseService.instance.addProfileToSyncQueue(apiProfile.employeeId);
//         _showSuccessAndReset("Saved locally. Will sync when online.");
//       }
//
//     } catch (e) {
//       print("Error during registration: $e");
//       _showError('An error occurred during registration.');
//     } finally {
//       if (mounted) {
//         setState(() { _isRegistering = false; });
//       }
//     }
//   }
//
//   // Helper to get current location
//   Future<Position?> _getCurrentLocation() async {
//     try {
//       bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
//       if (!serviceEnabled) {
//         _showError("Location services are disabled.");
//         return null;
//       }
//
//       LocationPermission permission = await Geolocator.checkPermission();
//       if (permission == LocationPermission.denied) {
//         permission = await Geolocator.requestPermission();
//         if (permission == LocationPermission.denied) {
//           _showError("Location permissions are denied.");
//           return null;
//         }
//       }
//
//       if (permission == LocationPermission.deniedForever) {
//         _showError("Location permissions are permanently denied.");
//         return null;
//       }
//
//       return await Geolocator.getCurrentPosition();
//     } catch (e) {
//       print("Error getting location: $e");
//       return null;
//     }
//   }
//
//   void _showError(String message) {
//     if (mounted) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(backgroundColor: Colors.red, content: Text(message)),
//       );
//     }
//   }
//
//   void _showSuccessAndReset([String? message]) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         backgroundColor: Colors.green,
//         content: Text(message ?? 'Registration successful!'),
//       ),
//     );
//     setState(() { _isSuccessOverlayVisible = true; });
//     Future.delayed(const Duration(seconds: 2), () {
//       if (mounted) {
//         setState(() {
//           _isSuccessOverlayVisible = false;
//           _employeeIdController.clear();
//           _capturedImage = null;
//         });
//       }
//     });
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: const Color(0xFFF0F2F5),
//       body: Stack(
//         children: [
//           Center(
//             child: SingleChildScrollView(
//               padding: const EdgeInsets.all(24.0),
//               child: SizedBox(
//                 width: 450,
//                 child: Form(
//                   key: _formKey,
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       const Text(
//                         'Employee ID',
//                         style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
//                       ),
//                       const SizedBox(height: 8),
//                       SizedBox(
//                         height: 70,
//                         child: TextFormField(
//                           controller: _employeeIdController,
//                           autofocus: true,
//                           textAlignVertical: TextAlignVertical.center,
//                           style: const TextStyle(
//                             fontSize: 20.0,
//                             fontWeight: FontWeight.w500,
//                           ),
//                           decoration: InputDecoration(
//                             hintText: 'Enter Employee ID',
//                             filled: true,
//                             fillColor: Colors.white,
//                             border: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                               borderSide: const BorderSide(
//                                 color: Color(0xFFCED4DA),
//                                 width: 2.0,
//                               ),
//                             ),
//                             enabledBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                               borderSide: const BorderSide(
//                                 color: Color(0xFFCED4DA),
//                                 width: 2.0,
//                               ),
//                             ),
//                             focusedBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                               borderSide: BorderSide(
//                                 color: Theme.of(context).primaryColor,
//                                 width: 2.0,
//                               ),
//                             ),
//                           ),
//                           validator: (value) {
//                             if (value == null || value.isEmpty) {
//                               return 'Please enter an Employee ID';
//                             }
//                             return null;
//                           },
//                         ),
//                       ),
//                       const SizedBox(height: 32),
//                       _buildCameraSection(),
//                       const SizedBox(height: 40),
//                       _buildButtonControls(),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ),
//           if (_isSuccessOverlayVisible) _buildSuccessOverlay(),
//           if (_isRegistering) _buildLoadingOverlay(), // Loading overlay
//         ],
//       ),
//     );
//   }
//
//   Widget _buildCameraSection() {
//     return Material(
//       elevation: 4.0,
//       borderRadius: BorderRadius.circular(20.0),
//       child: ClipRRect(
//         borderRadius: BorderRadius.circular(20.0),
//         child: Container(
//           width: 300,
//           height: 400,
//           color: Colors.black,
//           child: Builder(
//             builder: (context) {
//               if (_capturedImage != null) {
//                 return Image.file(File(_capturedImage!.path), fit: BoxFit.cover);
//               }
//               if (_isCameraInitialized && _cameraController != null) {
//                 return CameraPreview(_cameraController!);
//               }
//               return const Center(
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Icon(Icons.camera_alt, size: 64, color: Colors.grey),
//                     SizedBox(height: 16),
//                     Text('Camera Preview', style: TextStyle(color: Colors.grey)),
//                   ],
//                 ),
//               );
//             },
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildButtonControls() {
//     // Disable buttons while registering
//     final bool isButtonDisabled = _isRegistering;
//
//     if (_capturedImage != null) {
//       return Row(
//         children: [
//           Expanded(
//             child: OutlinedButton(
//               onPressed: isButtonDisabled ? null : _retakePicture,
//               style: OutlinedButton.styleFrom(
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//               ),
//               child: const Text('Retake', style: TextStyle(fontSize: 18)),
//             ),
//           ),
//           const SizedBox(width: 16),
//           Expanded(
//             child: ElevatedButton(
//               onPressed: isButtonDisabled ? null : _registerEmployee,
//               style: ElevatedButton.styleFrom(
//                 padding: const EdgeInsets.symmetric(vertical: 16),
//               ),
//               child: const Text('Register', style: TextStyle(fontSize: 18)),
//             ),
//           ),
//         ],
//       );
//     }
//     if (_isCameraInitialized) {
//       return ElevatedButton(
//         onPressed: isButtonDisabled ? null : _takePicture,
//         style: ElevatedButton.styleFrom(
//           padding: const EdgeInsets.symmetric(vertical: 16),
//           minimumSize: const Size(double.infinity, 50),
//         ),
//         child: const Text('Take Picture', style: TextStyle(fontSize: 18)),
//       );
//     }
//     return ElevatedButton(
//       onPressed: isButtonDisabled ? null : _initializeCamera,
//       style: ElevatedButton.styleFrom(
//         padding: const EdgeInsets.symmetric(vertical: 16),
//         minimumSize: const Size(double.infinity, 50),
//       ),
//       child: const Text('Capture Image', style: TextStyle(fontSize: 18)),
//     );
//   }
//
//   Widget _buildSuccessOverlay() {
//     return Container(
//       color: Colors.green.withOpacity(0.85),
//       child: const Center(
//         child: Icon(
//           Icons.check_circle,
//           size: 150,
//           color: Colors.white,
//         ),
//       ),
//     );
//   }
//
//   Widget _buildLoadingOverlay() {
//     return Container(
//       color: Colors.black.withOpacity(0.5),
//       child: const Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             CircularProgressIndicator(color: Colors.white),
//             SizedBox(height: 20),
//             Text(
//               'Processing...',
//               style: TextStyle(color: Colors.white, fontSize: 18, decoration: TextDecoration.none),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
