// brightness_estimator.dart
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'threshold_policy.dart';

class BrightnessEstimator {
  /// Returns mean luma (0..255)
  static double meanLumaFromImage(img.Image im) {
    final g = img.grayscale(im);
    double sum = 0;
    for (int y = 0; y < g.height; y++) {
      for (int x = 0; x < g.width; x++) {
        sum += img.getLuminance(g.getPixel(x, y));
      }
    }
    return sum / (g.width * g.height);
  }

  /// Classify into daylight vs lowLight using simple cut.
  static Lighting classify(double meanLuma) =>
      (meanLuma < 85) ? Lighting.lowLight : Lighting.daylight;
}
