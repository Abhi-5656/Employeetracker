// quality_gates.dart
import 'dart:math';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';
import 'package:image/image.dart' as img;
import 'brightness_estimator.dart';
import 'threshold_policy.dart';

class QualityResult {
  final bool pass;
  final List<String> reasons;
  final Lighting lighting;
  final double meanLuma;
  final double sobelEnergy;
  final double yaw, roll, pitchApprox;
  QualityResult({
    required this.pass,
    required this.reasons,
    required this.lighting,
    required this.meanLuma,
    required this.sobelEnergy,
    required this.yaw,
    required this.roll,
    required this.pitchApprox,
  });
}

class QualityGates {
  /// Returns QualityResult. Uses:
  /// - ROI center gate (central 60% box)
  /// - |yaw|,|pitch|,|roll| <= 15°
  /// - blur (Sobel) >= policy.blurMin
  static QualityResult evaluate({
    required Face face,
    required img.Image fullImage,
    required img.Image faceCrop,
    double roiFrac = 0.60,
  }) {
    final bb = face.boundingBox;
    final cx = bb.left + bb.width / 2;
    final cy = bb.top + bb.height / 2;
    final roiW = fullImage.width * roiFrac;
    final roiH = fullImage.height * roiFrac;
    final roiLeft = (fullImage.width - roiW) / 2;
    final roiTop  = (fullImage.height - roiH) / 2;

    final inRoi = (cx >= roiLeft && cx <= (roiLeft + roiW) &&
        cy >= roiTop  && cy <= (roiTop  + roiH));

    final yaw  = face.headEulerAngleY ?? 0.0;     // left/right
    final roll = face.headEulerAngleZ ?? 0.0;     // tilt
    // Pitch is not provided; approximate using eye-to-nose geometry when possible.
    // If landmarks missing, leave 0.0 so the clamp below fails only if others fail.
    double pitch = 0.0;
    final le = face.landmarks[FaceLandmarkType.leftEye]?.position;
    final re = face.landmarks[FaceLandmarkType.rightEye]?.position;
    final nose = face.landmarks[FaceLandmarkType.noseBase]?.position;
    if (le != null && re != null && nose != null) {
      final eyeY = (le.y + re.y) / 2.0;
      final eyeX = (le.x + re.x) / 2.0;
      final eyeDist = max(1.0, (re.x - le.x).abs());
      // crude pitch proxy: nose vertical offset relative to eye line
      final pitchNorm = (nose.y - eyeY).abs() / eyeDist; // ~0.3–0.6
      // Map 0.25..0.75 roughly into 0..25°
      pitch = (max(0.0, (pitchNorm - 0.25)) * 50.0).clamp(0.0, 25.0);
    }

    // Blur & brightness on the crop
    final g = img.grayscale(img.copyResize(faceCrop, width: 64, height: 64));
    double sobel = 0;
    const sx = [[-1,0,1],[-2,0,2],[-1,0,1]];
    const sy = [[-1,-2,-1],[0,0,0],[1,2,1]];
    for (int y = 1; y < g.height - 1; y++) {
      for (int x = 1; x < g.width - 1; x++) {
        double gx = 0, gy = 0;
        for (int j = -1; j <= 1; j++) {
          for (int i = -1; i <= 1; i++) {
            final lum = img.getLuminance(g.getPixel(x + i, y + j)).toDouble();
            gx += sx[j + 1][i + 1] * lum;
            gy += sy[j + 1][i + 1] * lum;
          }
        }
        sobel += gx * gx + gy * gy;
      }
    }
    sobel /= ((g.width - 2) * (g.height - 2));

    final mean = BrightnessEstimator.meanLumaFromImage(faceCrop);
    final lighting = BrightnessEstimator.classify(mean);
    final policy = (lighting == Lighting.lowLight)
        ? ThresholdPolicy.lowLight
        : ThresholdPolicy.daylight;

    final List<String> reasons = [];
    if (!inRoi) reasons.add('Face not centered');
    if (yaw.abs()   > 15.0) reasons.add('Yaw > 15°');
    if (roll.abs()  > 15.0) reasons.add('Roll > 15°');
    if (pitch.abs() > 15.0) reasons.add('Pitch > 15°');
    if (sobel < policy.blurMin) reasons.add('Too blurry');

    return QualityResult(
      pass: reasons.isEmpty,
      reasons: reasons,
      lighting: lighting,
      meanLuma: mean,
      sobelEnergy: sobel,
      yaw: yaw, roll: roll, pitchApprox: pitch,
    );
  }
}
