import 'package:kiosk/app/core/config/env_config.dart';

// class DevConfig implements EnvConfig {
//   @override
//   // --- FIX APPLIED: Added the 'http://' scheme ---
//   String get baseUrl => 'http://wfm-backend-alb-60464600.ap-south-1.elb.amazonaws.com';
// }
class DevConfig implements EnvConfig {
  @override
  // --- FIX APPLIED: Added the 'http://' scheme ---
  String get baseUrl => 'http://wfm-backend-alb-60464600.ap-south-1.elb.amazonaws.com';
}