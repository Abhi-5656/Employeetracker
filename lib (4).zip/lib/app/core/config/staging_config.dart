// lib/app/core/config/staging_config.dart
import 'package:kiosk/app/core/config/env_config.dart';

class StagingConfig implements EnvConfig {
  @override
  String get baseUrl => 'https://staging.yourapi.com'; // Your staging API URL
}
