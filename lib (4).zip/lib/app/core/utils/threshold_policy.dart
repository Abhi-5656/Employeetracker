// threshold_policy.dart
enum Lighting { daylight, lowLight }

class ThresholdPolicy {
  final double baseDistance;       // d1 must be <= this
  final double top2Margin;         // (d2 - d1) must be >= this
  final int requiredConsensus;     // consecutive frames
  final Duration window;           // time budget per attempt
  final int blurMin;               // Sobel energy min
  const ThresholdPolicy({
    required this.baseDistance,
    required this.top2Margin,
    required this.requiredConsensus,
    required this.window,
    required this.blurMin,
  });

  // static const ThresholdPolicy daylight = ThresholdPolicy(
  //   baseDistance: 0.85, top2Margin: 0.08,
  //   requiredConsensus: 2, window: Duration(milliseconds: 1200),
  //   blurMin: 120,
  // );

  static const ThresholdPolicy daylight = ThresholdPolicy(
    baseDistance: 0.88,
    top2Margin:  0.08,
    requiredConsensus: 2,
    window: Duration(milliseconds: 1600),
    blurMin: 120,
  );

  // static const ThresholdPolicy lowLight = ThresholdPolicy(
  //   baseDistance: 0.80, top2Margin: 0.10,
  //   requiredConsensus: 3, window: Duration(milliseconds: 1800),
  //   blurMin: 150,
  // );
  static const ThresholdPolicy lowLight = ThresholdPolicy(
    baseDistance: 0.82,
    top2Margin:  0.10,
    requiredConsensus: 3,
    window: Duration(milliseconds: 1800),
    blurMin: 150,
  );
}
