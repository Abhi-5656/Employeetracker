// import 'package:path/path.dart';
// import 'package:sqflite/sqflite.dart';
// import 'package:path_provider/path_provider.dart';
//
// import '../models /punch_event.dart';
//
// class DatabaseService {
//   // Singleton pattern
//   static final DatabaseService instance = DatabaseService._init();
//   static Database? _database;
//   DatabaseService._init();
//
//   Future<Database> get database async {
//     if (_database != null) return _database!;
//     _database = await _initDB('kiosk.db');
//     return _database!;
//   }
//
//   Future<Database> _initDB(String filePath) async {
//     final dbPath = await getApplicationDocumentsDirectory();
//     final path = join(dbPath.path, filePath);
//     return await openDatabase(path, version: 2, onCreate: _createDB, onUpgrade: _upgradeDB);
//   }
//
//   Future _createDB(Database db, int version) async {
//     await _createEmployeeProfileTable(db);
//     await _createPunchEventTable(db);
//   }
//
//   Future _upgradeDB(Database db, int oldVersion, int newVersion) async {
//     if (oldVersion < 2) {
//       await _createPunchEventTable(db);
//     }
//   }
//
//   Future<void> _createEmployeeProfileTable(Database db) async {
//     const idType = 'TEXT PRIMARY KEY';
//     const textType = 'TEXT'; // Can be NULL initially
//
//     await db.execute('''
//       CREATE TABLE employee_profile_registration (
//         employee_id $idType,
//         image_data $textType
//       )
//     ''');
//   }
//
//   Future<void> _createPunchEventTable(Database db) async {
//     const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
//     const textType = 'TEXT NOT NULL';
//     const dateTimeType = 'TEXT NOT NULL';
//
//     await db.execute('''
//       CREATE TABLE punch_event (
//         id $idType,
//         employee_id $textType,
//         event_time $dateTimeType,
//         punch_type $textType
//       )
//     ''');
//   }
//
//   /// Syncs employee IDs from the server.
//   /// Only inserts new employees, leaving existing ones untouched.
//   Future<void> syncEmployeeIds(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//
//     for (final id in employeeIds) {
//       // 'INSERT OR IGNORE' ensures that if an employee_id already exists,
//       // the new insert is skipped without causing an error.
//       batch.rawInsert(
//         'INSERT OR IGNORE INTO employee_profile_registration (employee_id, image_data) VALUES (?, ?)',
//         [id, null], // New employees have null image data initially
//       );
//     }
//     await batch.commit(noResult: true);
//     print('${employeeIds.length} Employee IDs synced with the local database.');
//   }
//
//   /// Checks if an employee ID exists in the database.
//   Future<bool> employeeExists(String employeeId) async {
//     final db = await instance.database;
//     final result = await db.query(
//       'employee_profile_registration',
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//       limit: 1,
//     );
//     return result.isNotEmpty;
//   }
//
//   /// Updates an employee's record with their face embedding data after registration.
//   Future<void> updateEmployeeEmbedding(String employeeId, String imageData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       {'image_data': imageData},
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//     );
//   }
//
//   /// Inserts or replaces an employee record. Used for backward compatibility.
//   Future<void> insertEmployee(String employeeId, String imageData) async {
//     final db = await instance.database;
//     await db.insert(
//       'employee_profile_registration',
//       {'employee_id': employeeId, 'image_data': imageData},
//       conflictAlgorithm: ConflictAlgorithm.replace,
//     );
//   }
//
//   Future<void> insertPunchEvent(PunchEvent punchEvent) async {
//     final db = await instance.database;
//     await db.insert('punch_event', punchEvent.toMap());
//   }
//
//   Future<List<Map<String, dynamic>>> getAllEmployeeProfiles() async {
//     final db = await instance.database;
//     return await db.query('employee_profile_registration');
//   }
//
//   Future close() async {
//     final db = await instance.database;
//     db.close();
//   }
// }
// lib/app/core/services/database_service.dart

// import 'package:path/path.dart';
// import 'package:sqflite/sqflite.dart';
// import 'package:path_provider/path_provider.dart';
//
// import '../models /punch_event.dart';
//
// class DatabaseService {
//   // Singleton pattern
//   static final DatabaseService instance = DatabaseService._init();
//   static Database? _database;
//   DatabaseService._init();
//
//   Future<Database> get database async {
//     if (_database != null) return _database!;
//     _database = await _initDB('kiosk.db');
//     return _database!;
//   }
//
//   Future<Database> _initDB(String filePath) async {
//     final dbPath = await getApplicationDocumentsDirectory();
//     final path = join(dbPath.path, filePath);
//     // Version increased to 3 to handle adding offline sync tables and columns
//     return await openDatabase(path, version: 3, onCreate: _createDB, onUpgrade: _onUpgrade);
//   }
//
//   // Called when the database is created for the very first time.
//   Future _createDB(Database db, int version) async {
//     await _createEmployeeProfileTable(db);
//     await _createPunchEventTable(db);
//     await _createSyncQueueTable(db);
//   }
//
//   // Handles migrations for existing users when the app is updated.
//   Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
//     if (oldVersion < 2) {
//       await _createPunchEventTable(db);
//     }
//     if (oldVersion < 3) {
//       // Add new columns for offline data to the existing table
//       await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN name TEXT');
//       await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN latitude REAL');
//       await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN longitude REAL');
//       await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN timestamp TEXT');
//       // Create the new table for the sync queue
//       await _createSyncQueueTable(db);
//     }
//   }
//
//   // Creates the main employee table with all necessary columns.
//   Future<void> _createEmployeeProfileTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE employee_profile_registration (
//         employee_id TEXT PRIMARY KEY,
//         name TEXT,
//         image_data TEXT,
//         latitude REAL,
//         longitude REAL,
//         timestamp TEXT
//       )
//     ''');
//   }
//
//   // New table to queue unsynced profiles
//   Future<void> _createSyncQueueTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE sync_queue (
//         employee_id TEXT PRIMARY KEY,
//         FOREIGN KEY (employee_id) REFERENCES employee_profile_registration (employee_id) ON DELETE CASCADE
//       )
//     ''');
//   }
//
//   // Creates the table for punch events.
//   Future<void> _createPunchEventTable(Database db) async {
//     const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
//     const textType = 'TEXT NOT NULL';
//     const dateTimeType = 'TEXT NOT NULL';
//
//     await db.execute('''
//       CREATE TABLE punch_event (
//         id $idType,
//         employee_id $textType,
//         event_time $dateTimeType,
//         punch_type $textType
//       )
//     ''');
//   }
//
//   /// Syncs employee IDs from the server.
//   /// Only inserts new employees, leaving existing ones untouched.
//   Future<void> syncEmployeeIds(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//
//     for (final id in employeeIds) {
//       batch.rawInsert(
//         'INSERT OR IGNORE INTO employee_profile_registration (employee_id) VALUES (?)',
//         [id],
//       );
//     }
//     await batch.commit(noResult: true);
//     print('${employeeIds.length} Employee IDs synced with the local database.');
//   }
//
//   /// Checks if an employee ID exists in the database.
//   Future<bool> employeeExists(String employeeId) async {
//     final db = await instance.database;
//     final result = await db.query(
//       'employee_profile_registration',
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//       limit: 1,
//     );
//     return result.isNotEmpty;
//   }
//
//   /// Updates an employee's record with their face embedding data after registration.
//   Future<void> updateEmployeeEmbedding(String employeeId, String imageData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       {'image_data': imageData},
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//     );
//   }
//
//   /// Updates an employee's record with their full profile data.
//   Future<void> updateEmployeeProfile(Map<String, dynamic> profileData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       profileData,
//       where: 'employee_id = ?',
//       whereArgs: [profileData['employee_id']],
//     );
//   }
//
//   /// Adds a profile to the sync queue for later upload.
//   Future<void> addProfileToSyncQueue(String employeeId) async {
//     final db = await instance.database;
//     await db.insert(
//       'sync_queue',
//       {'employee_id': employeeId},
//       conflictAlgorithm: ConflictAlgorithm.ignore,
//     );
//   }
//
//   /// Gets all profiles that are waiting in the sync queue.
//   Future<List<Map<String, dynamic>>> getQueuedProfiles() async {
//     final db = await instance.database;
//     final result = await db.rawQuery('''
//       SELECT p.employee_id as employeeId, p.image_data as employeeImageData
//       FROM employee_profile_registration p
//       INNER JOIN sync_queue q ON p.employee_id = q.employee_id
//     ''');
//     return result;
//   }
//
//   /// Clears profiles from the queue after a successful sync.
//   Future<void> clearSyncedProfiles(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in employeeIds) {
//       batch.delete('sync_queue', where: 'employee_id = ?', whereArgs: [id]);
//     }
//     await batch.commit(noResult: true);
//     print('${employeeIds.length} profiles cleared from sync queue.');
//   }
//
//   Future<void> insertPunchEvent(PunchEvent punchEvent) async {
//     final db = await instance.database;
//     await db.insert('punch_event', punchEvent.toMap());
//   }
//
//   Future<List<Map<String, dynamic>>> getAllEmployeeProfiles() async {
//     final db = await instance.database;
//     return await db.query('employee_profile_registration');
//   }
// }
//
// import 'package:path/path.dart';
// import 'dart:convert';
// import 'package:sqflite/sqflite.dart';
// import 'package:path_provider/path_provider.dart';
//
// import '../models/punch_event.dart';
//
// class DatabaseService {
//   // Singleton pattern
//   static final DatabaseService instance = DatabaseService._init();
//   static Database? _database;
//
//   DatabaseService._init();
//
//   Future<Database> get database async {
//     if (_database != null) return _database!;
//     _database = await _initDB('kiosk.db');
//     return _database!;
//   }
//
//   Future<Database> _initDB(String filePath) async {
//     final dbPath = await getApplicationDocumentsDirectory();
//     final path = join(dbPath.path, filePath);
//     return await openDatabase(path,
//         version: 4, onCreate: _createDB, onUpgrade: _onUpgrade);
//   }
//
//   Future _createDB(Database db, int version) async {
//     await _createEmployeeProfileTable(db);
//     await _createPunchEventTable(db);
//     await _createSyncQueueTable(db);
//     await _createPunchSyncQueueTable(db);
//   }
//
//   Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
//     if (oldVersion < 2) {
//       await _createPunchEventTable(db);
//     }
//     if (oldVersion < 3) {
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN name TEXT');
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN latitude REAL');
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN longitude REAL');
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN timestamp TEXT');
//       await _createSyncQueueTable(db);
//     }
//     if (oldVersion < 4) {
//       await db.execute('ALTER TABLE punch_event ADD COLUMN status TEXT');
//       await db.execute('ALTER TABLE punch_event ADD COLUMN deviceId TEXT');
//       await db.execute('ALTER TABLE punch_event ADD COLUMN latitude REAL');
//       await db.execute('ALTER TABLE punch_event ADD COLUMN longitude REAL');
//       await _createPunchSyncQueueTable(db);
//     }
//   }
//
//   Future<void> _createEmployeeProfileTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE employee_profile_registration (
//         employee_id TEXT PRIMARY KEY,
//         name TEXT,
//         image_data TEXT,
//         latitude REAL,
//         longitude REAL,
//         timestamp TEXT
//       )
//     ''');
//   }
//
//   Future<void> _createSyncQueueTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE sync_queue (
//         employee_id TEXT PRIMARY KEY,
//         FOREIGN KEY (employee_id) REFERENCES employee_profile_registration (employee_id) ON DELETE CASCADE
//       )
//     ''');
//   }
//
//   Future<void> _createPunchEventTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE punch_event (
//         id INTEGER PRIMARY KEY AUTOINCREMENT,
//         employee_id TEXT NOT NULL,
//         event_time TEXT NOT NULL,
//         punch_type TEXT NOT NULL,
//         status TEXT,
//         deviceId TEXT,
//         latitude REAL,
//         longitude REAL
//       )
//     ''');
//   }
//
//   Future<void> _createPunchSyncQueueTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE punch_sync_queue (
//         punch_id INTEGER PRIMARY KEY,
//         FOREIGN KEY (punch_id) REFERENCES punch_event (id) ON DELETE CASCADE
//       )
//     ''');
//   }
//
//   Future<void> addPunchEventToQueue(PunchEvent event) async {
//     final db = await instance.database;
//     await db.transaction((txn) async {
//       final id = await txn.insert('punch_event', event.toMap(),
//           conflictAlgorithm: ConflictAlgorithm.replace);
//       await txn.insert(
//         'punch_sync_queue',
//         {'punch_id': id},
//         conflictAlgorithm: ConflictAlgorithm.ignore,
//       );
//     });
//   }
//
//   Future<List<PunchEvent>> getQueuedPunchEvents() async {
//     final db = await instance.database;
//     final result = await db.rawQuery('''
//       SELECT p.* FROM punch_event p
//       INNER JOIN punch_sync_queue q ON p.id = q.punch_id
//     ''');
//     return result.map((json) => PunchEvent.fromMap(json)).toList();
//   }
//
//   Future<void> clearSyncedPunchEvents(List<int> punchIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in punchIds) {
//       batch.delete('punch_sync_queue', where: 'punch_id = ?', whereArgs: [id]);
//     }
//     await batch.commit(noResult: true);
//     print('${punchIds.length} punch events cleared from sync queue.');
//   }
//
//   // --- Methods for Employee Profiles ---
//
//   /// --- UPDATED: Now correctly maps keys from the server JSON response. ---
//   Future<void> syncProfilesFromServer(
//       List<Map<String, dynamic>> profiles) async {
//     final db = await instance.database;
//     final batch = db.batch();
//
//     for (final profile in profiles) {
//       // Create a map that correctly matches the DB columns with the JSON keys.
//       final dbRow = {
//         'employee_id': profile['employeeId'],
//
//         // --- FIX 1: Use the correct key 'employeeImageData' ---
//         'image_data': profile['employeeImageData'],
//
//         // --- FIX 2: Use 'updatedAt' for the timestamp column ---
//         'timestamp': profile['updatedAt'],
//
//         // --- FIX 3: Other fields like 'name', 'latitude', 'longitude' are not in the
//         // JSON, so we don't try to map them. They will remain null in the DB
//         // unless updated by another process.
//       };
//
//       batch.insert(
//         'employee_profile_registration',
//         dbRow,
//         conflictAlgorithm: ConflictAlgorithm.replace,
//       );
//     }
//
//     await batch.commit(noResult: true);
//     print(
//         '✅ Synced ${profiles.length} profiles from server to local database.');
//   }
//
//   Future<void> syncEmployeeIds(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in employeeIds) {
//       batch.rawInsert(
//         'INSERT OR IGNORE INTO employee_profile_registration (employee_id) VALUES (?)',
//         [id],
//       );
//     }
//     await batch.commit(noResult: true);
//   }
//
//   Future<bool> employeeExists(String employeeId) async {
//     final db = await instance.database;
//     final result = await db.query(
//       'employee_profile_registration',
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//       limit: 1,
//     );
//     return result.isNotEmpty;
//   }
//
//   Future<void> updateEmployeeEmbedding(String employeeId,
//       String imageData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       {'image_data': imageData},
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//     );
//   }
//
//   Future<void> updateEmployeeProfile(Map<String, dynamic> profileData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       profileData,
//       where: 'employee_id = ?',
//       whereArgs: [profileData['employee_id']],
//     );
//   }
//
//   Future<void> addProfileToSyncQueue(String employeeId) async {
//     final db = await instance.database;
//     await db.insert(
//       'sync_queue',
//       {'employee_id': employeeId},
//       conflictAlgorithm: ConflictAlgorithm.ignore,
//     );
//   }
//
//   Future<List<Map<String, dynamic>>> getQueuedProfiles() async {
//     final db = await instance.database;
//     final result = await db.rawQuery('''
//       SELECT p.employee_id as employeeId, p.image_data as employeeImageData
//       FROM employee_profile_registration p
//       INNER JOIN sync_queue q ON p.employee_id = q.employee_id
//     ''');
//     return result;
//   }
//
//   Future<void> clearSyncedProfiles(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in employeeIds) {
//       batch.delete('sync_queue', where: 'employee_id = ?', whereArgs: [id]);
//     }
//     await batch.commit(noResult: true);
//   }
//
//   Future<void> insertPunchEvent(PunchEvent punchEvent) async {
//     final db = await instance.database;
//     await db.insert('punch_event', punchEvent.toMap());
//   }
//
//   Future<List<Map<String, dynamic>>> getAllEmployeeProfiles() async {
//     final db = await instance.database;
//     return await db.query('employee_profile_registration');
//   }
//
//   // Returns employeeId -> List<List<double>> (multi-template).
// // Supports both legacy single-vector JSON "[...]" and new multi-vector JSON "[[...],[...],...]".
//   Future<Map<String, List<List<double>>>> getAllEmployeeEmbeddingsMap() async {
//     final db = await database;
//
//     // Adjust the table/columns to match your schema if needed.
//     // These are the most common in your project; wrapped in try-catch to avoid breakage.
//     const String table = 'employee_profile_registration';
//     const String idCol = 'employee_id';
//     const String embeddingCol = 'image_data';
//
//     final Map<String, List<List<double>>> out = {};
//     try {
//       final rows = await db.query(
//         table,
//         columns: [idCol, embeddingCol],
//         where: '$embeddingCol IS NOT NULL',
//       );
//
//       for (final r in rows) {
//         final String empId = (r[idCol] as String).trim();
//         final String jsonStr = (r[embeddingCol] as String).trim();
//         final parsed = _parseEmbeddingJson(jsonStr);
//         if (parsed != null && parsed.isNotEmpty) {
//           out[empId] = parsed;
//         }
//       }
//     } catch (_) {
//       // If your embeddings live elsewhere, point to that table/columns instead.
//       // Intentionally swallow to avoid crashing existing flows.
//     }
//     return out;
//   }
//
//   // Parses:
// //  - "[f1,f2,...]" -> [[f1,f2,...]]
// //  - "[[...],[...],...]" -> kept as-is
//   List<List<double>>? _parseEmbeddingJson(String jsonStr) {
//     try {
//       final dynamic j = json.decode(jsonStr);
//       if (j is List) {
//         if (j.isEmpty) return const [];
//         if (j.first is List) {
//           return j
//               .map<List<double>>(
//                   (it) =>
//                   (it as List).map((e) => (e as num).toDouble()).toList(
//                       growable: false))
//               .toList(growable: false);
//         }
//         if (j.first is num) {
//           return [
//             j.map<double>((e) => (e as num).toDouble()).toList(growable: false)
//           ];
//         }
//       }
//       return null;
//     } catch (_) {
//       return null;
//     }
//   }
// }





//older
// import 'package:path/path.dart';
// import 'dart:convert';
// import 'package:sqflite/sqflite.dart';
// import 'package:path_provider/path_provider.dart';
//
// import '../models/punch_event.dart';
//
// class DatabaseService {
//   // Singleton pattern
//   static final DatabaseService instance = DatabaseService._init();
//   static Database? _database;
//
//   DatabaseService._init();
//
//   Future<Database> get database async {
//     if (_database != null) return _database!;
//     _database = await _initDB('kiosk.db');
//     return _database!;
//   }
//
//   Future<Database> _initDB(String filePath) async {
//     final dbPath = await getApplicationDocumentsDirectory();
//     final path = join(dbPath.path, filePath);
//     return await openDatabase(path,
//         version: 4, onCreate: _createDB, onUpgrade: _onUpgrade);
//   }
//
//   Future _createDB(Database db, int version) async {
//     await _createEmployeeProfileTable(db);
//     await _createPunchEventTable(db);
//     await _createSyncQueueTable(db);
//     await _createPunchSyncQueueTable(db);
//   }
//
//   Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
//     if (oldVersion < 2) {
//       await _createPunchEventTable(db);
//     }
//     if (oldVersion < 3) {
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN name TEXT');
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN latitude REAL');
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN longitude REAL');
//       await db.execute(
//           'ALTER TABLE employee_profile_registration ADD COLUMN timestamp TEXT');
//       await _createSyncQueueTable(db);
//     }
//     if (oldVersion < 4) {
//       await db.execute('ALTER TABLE punch_event ADD COLUMN status TEXT');
//       await db.execute('ALTER TABLE punch_event ADD COLUMN deviceId TEXT');
//       await db.execute('ALTER TABLE punch_event ADD COLUMN latitude REAL');
//       await db.execute('ALTER TABLE punch_event ADD COLUMN longitude REAL');
//       await _createPunchSyncQueueTable(db);
//     }
//   }
//
//   Future<void> _createEmployeeProfileTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE employee_profile_registration (
//         employee_id TEXT PRIMARY KEY,
//         name TEXT,
//         image_data TEXT,
//         latitude REAL,
//         longitude REAL,
//         timestamp TEXT
//       )
//     ''');
//   }
//
//   Future<void> _createSyncQueueTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE sync_queue (
//         employee_id TEXT PRIMARY KEY,
//         FOREIGN KEY (employee_id) REFERENCES employee_profile_registration (employee_id) ON DELETE CASCADE
//       )
//     ''');
//   }
//
//   Future<void> _createPunchEventTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE punch_event (
//         id INTEGER PRIMARY KEY AUTOINCREMENT,
//         employee_id TEXT NOT NULL,
//         event_time TEXT NOT NULL,
//         punch_type TEXT NOT NULL,
//         status TEXT,
//         deviceId TEXT,
//         latitude REAL,
//         longitude REAL
//       )
//     ''');
//   }
//
//   Future<void> _createPunchSyncQueueTable(Database db) async {
//     await db.execute('''
//       CREATE TABLE punch_sync_queue (
//         punch_id INTEGER PRIMARY KEY,
//         FOREIGN KEY (punch_id) REFERENCES punch_event (id) ON DELETE CASCADE
//       )
//     ''');
//   }
//
//   Future<void> addPunchEventToQueue(PunchEvent event) async {
//     final db = await instance.database;
//     await db.transaction((txn) async {
//       final id = await txn.insert('punch_event', event.toMap(),
//           conflictAlgorithm: ConflictAlgorithm.replace);
//       await txn.insert(
//         'punch_sync_queue',
//         {'punch_id': id},
//         conflictAlgorithm: ConflictAlgorithm.ignore,
//       );
//     });
//   }
//
//   Future<List<PunchEvent>> getQueuedPunchEvents() async {
//     final db = await instance.database;
//     final result = await db.rawQuery('''
//       SELECT p.* FROM punch_event p
//       INNER JOIN punch_sync_queue q ON p.id = q.punch_id
//     ''');
//     return result.map((json) => PunchEvent.fromMap(json)).toList();
//   }
//
//   Future<void> clearSyncedPunchEvents(List<int> punchIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in punchIds) {
//       batch.delete('punch_sync_queue', where: 'punch_id = ?', whereArgs: [id]);
//     }
//     await batch.commit(noResult: true);
//     print('${punchIds.length} punch events cleared from sync queue.');
//   }
//
//   // --- Methods for Employee Profiles ---
//
//   /// --- UPDATED: Now correctly maps keys from the server JSON response. ---
//   Future<void> syncProfilesFromServer(
//       List<Map<String, dynamic>> profiles) async {
//     final db = await instance.database;
//     final batch = db.batch();
//
//     for (final profile in profiles) {
//       // Create a map that correctly matches the DB columns with the JSON keys.
//       final dbRow = {
//         'employee_id': profile['employeeId'],
//
//         // --- FIX 1: Use the correct key 'employeeImageData' ---
//         'image_data': profile['employeeImageData'],
//
//         // --- FIX 2: Use 'updatedAt' for the timestamp column ---
//         'timestamp': profile['updatedAt'],
//
//         // --- FIX 3: Other fields like 'name', 'latitude', 'longitude' are not in the
//         // JSON, so we don't try to map them. They will remain null in the DB
//         // unless updated by another process.
//       };
//
//       batch.insert(
//         'employee_profile_registration',
//         dbRow,
//         conflictAlgorithm: ConflictAlgorithm.replace,
//       );
//     }
//
//     await batch.commit(noResult: true);
//     print(
//         '✅ Synced ${profiles.length} profiles from server to local database.');
//   }
//
//   Future<void> syncEmployeeIds(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in employeeIds) {
//       batch.rawInsert(
//         'INSERT OR IGNORE INTO employee_profile_registration (employee_id) VALUES (?)',
//         [id],
//       );
//     }
//     await batch.commit(noResult: true);
//   }
//
//   Future<bool> employeeExists(String employeeId) async {
//     final db = await instance.database;
//     final result = await db.query(
//       'employee_profile_registration',
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//       limit: 1,
//     );
//     return result.isNotEmpty;
//   }
//
//   Future<void> updateEmployeeEmbedding(String employeeId,
//       String imageData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       {'image_data': imageData},
//       where: 'employee_id = ?',
//       whereArgs: [employeeId],
//     );
//   }
//
//   Future<void> updateEmployeeProfile(Map<String, dynamic> profileData) async {
//     final db = await instance.database;
//     await db.update(
//       'employee_profile_registration',
//       profileData,
//       where: 'employee_id = ?',
//       whereArgs: [profileData['employee_id']],
//     );
//   }
//
//   Future<void> addProfileToSyncQueue(String employeeId) async {
//     final db = await instance.database;
//     await db.insert(
//       'sync_queue',
//       {'employee_id': employeeId},
//       conflictAlgorithm: ConflictAlgorithm.ignore,
//     );
//   }
//
//   Future<List<Map<String, dynamic>>> getQueuedProfiles() async {
//     final db = await instance.database;
//     final result = await db.rawQuery('''
//       SELECT p.employee_id as employeeId, p.image_data as employeeImageData
//       FROM employee_profile_registration p
//       INNER JOIN sync_queue q ON p.employee_id = q.employee_id
//     ''');
//     return result;
//   }
//
//   Future<void> clearSyncedProfiles(List<String> employeeIds) async {
//     final db = await instance.database;
//     final batch = db.batch();
//     for (final id in employeeIds) {
//       batch.delete('sync_queue', where: 'employee_id = ?', whereArgs: [id]);
//     }
//     await batch.commit(noResult: true);
//   }
//
//   Future<void> insertPunchEvent(PunchEvent punchEvent) async {
//     final db = await instance.database;
//     await db.insert('punch_event', punchEvent.toMap());
//   }
//
//   Future<List<Map<String, dynamic>>> getAllEmployeeProfiles() async {
//     final db = await instance.database;
//     return await db.query('employee_profile_registration');
//   }
//
//   // Returns employeeId -> List<List<double>> (multi-template).
// // Supports both legacy single-vector JSON "[...]" and new multi-vector JSON "[[...],[...],...]".
//   Future<Map<String, List<List<double>>>> getAllEmployeeEmbeddingsMap() async {
//     final db = await database;
//
//     // Adjust the table/columns to match your schema if needed.
//     // These are the most common in your project; wrapped in try-catch to avoid breakage.
//     const String table = 'employee_profile_registration';
//     const String idCol = 'employee_id';
//     const String embeddingCol = 'image_data';
//
//     final Map<String, List<List<double>>> out = {};
//     try {
//       final rows = await db.query(
//         table,
//         columns: [idCol, embeddingCol],
//         where: '$embeddingCol IS NOT NULL',
//       );
//
//       for (final r in rows) {
//         final String empId = (r[idCol] as String).trim();
//         final String jsonStr = (r[embeddingCol] as String).trim();
//         final parsed = _parseEmbeddingJson(jsonStr);
//         if (parsed != null && parsed.isNotEmpty) {
//           out[empId] = parsed;
//         }
//       }
//     } catch (_) {
//       // If your embeddings live elsewhere, point to that table/columns instead.
//       // Intentionally swallow to avoid crashing existing flows.
//     }
//     return out;
//   }
//
//   // Parses:
// //  - "[f1,f2,...]" -> [[f1,f2,...]]
// //  - "[[...],[...],...]" -> kept as-is
//   List<List<double>>? _parseEmbeddingJson(String jsonStr) {
//     try {
//       final dynamic j = json.decode(jsonStr);
//       if (j is List) {
//         if (j.isEmpty) return const [];
//         if (j.first is List) {
//           return j
//               .map<List<double>>(
//                   (it) =>
//                   (it as List).map((e) => (e as num).toDouble()).toList(
//                       growable: false))
//               .toList(growable: false);
//         }
//         if (j.first is num) {
//           return [
//             j.map<double>((e) => (e as num).toDouble()).toList(growable: false)
//           ];
//         }
//       }
//       return null;
//     } catch (_) {
//       return null;
//     }
//   }
// }



import 'package:path/path.dart';
import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';

import '../models/punch_event.dart';

class DatabaseService {
  // Singleton pattern
  static final DatabaseService instance = DatabaseService._init();
  static Database? _database;

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('kiosk.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getApplicationDocumentsDirectory();
    final path = join(dbPath.path, filePath);
    return await openDatabase(path,
        version: 5, // ⬅⬅ bump to v5
        onCreate: _createDB,
        onUpgrade: _onUpgrade);
  }

  Future _createDB(Database db, int version) async {
    await _createEmployeeProfileTable(db);
    await _createPunchEventTable(db);
    await _createSyncQueueTable(db);
    await _createPunchSyncQueueTable(db);
    await _createAuditTrailTable(db); // ⬅ NEW
  }

  Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await _createPunchEventTable(db);
    }
    if (oldVersion < 3) {
      await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN name TEXT');
      await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN latitude REAL');
      await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN longitude REAL');
      await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN timestamp TEXT');
      await _createSyncQueueTable(db);
    }
    if (oldVersion < 4) {
      await db.execute('ALTER TABLE punch_event ADD COLUMN status TEXT');
      await db.execute('ALTER TABLE punch_event ADD COLUMN deviceId TEXT');
      await db.execute('ALTER TABLE punch_event ADD COLUMN latitude REAL');
      await db.execute('ALTER TABLE punch_event ADD COLUMN longitude REAL');
      await _createPunchSyncQueueTable(db);
    }
    if (oldVersion < 5) {
      await _createAuditTrailTable(db);
      // last_seen_local to bias local whitelist by recency
      try {
        await db.execute('ALTER TABLE employee_profile_registration ADD COLUMN last_seen_local TEXT');
      } catch (_) {}
    }
  }

  Future<void> _createAuditTrailTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS audit_trail (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id TEXT,
        ts TEXT NOT NULL,
        decision_json TEXT NOT NULL,
        local_image_path TEXT NOT NULL,
        review_flag INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_trail(ts)');
  }

// === NEW: write a local-only audit row ===
  Future<void> insertAuditTrail({
    String? employeeId,
    required String isoTs,
    required String decisionJson,
    required String localImagePath,
  }) async {
    final db = await instance.database;
    await db.insert('audit_trail', {
      'employee_id': employeeId,
      'ts': isoTs,
      'decision_json': decisionJson,
      'local_image_path': localImagePath,
    });
  }
// Simple purge (call occasionally)
  Future<void> purgeOldAudit({int maxDays = 30}) async {
    final db = await instance.database;
    final cutoff = DateTime.now().subtract(Duration(days: maxDays)).toIso8601String();
    await db.delete('audit_trail', where: 'ts < ?', whereArgs: [cutoff]);
  }

  Future<void> updateLastSeenLocal(String employeeId) async {
    final db = await instance.database;
    await db.update(
      'employee_profile_registration',
      {'last_seen_local': DateTime.now().toIso8601String()},
      where: 'employee_id = ?',
      whereArgs: [employeeId],
    );
  }

  /// Candidate profiles prioritizing recent local presence (last 14 days),
  /// falling back to all rows if none qualify.
  Future<List<Map<String, dynamic>>> getCandidateProfiles({int lookbackDays = 14}) async {
    final db = await instance.database;
    final cutoff = DateTime.now().subtract(Duration(days: lookbackDays)).toIso8601String();
    final recent = await db.query(
      'employee_profile_registration',
      where: 'last_seen_local IS NOT NULL AND last_seen_local >= ?',
      whereArgs: [cutoff],
    );
    if (recent.isNotEmpty) return recent;
    return await db.query('employee_profile_registration');
  }


  ///
  Future<void> _createEmployeeProfileTable(Database db) async {
    await db.execute('''
      CREATE TABLE employee_profile_registration (
        employee_id TEXT PRIMARY KEY,
        name TEXT,
        image_data TEXT,
        latitude REAL,
        longitude REAL,
        timestamp TEXT
      )
    ''');
  }

  Future<void> _createSyncQueueTable(Database db) async {
    await db.execute('''
      CREATE TABLE sync_queue (
        employee_id TEXT PRIMARY KEY,
        FOREIGN KEY (employee_id) REFERENCES employee_profile_registration (employee_id) ON DELETE CASCADE
      )
    ''');
  }

  Future<void> _createPunchEventTable(Database db) async {
    await db.execute('''
      CREATE TABLE punch_event (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id TEXT NOT NULL,
        event_time TEXT NOT NULL,
        punch_type TEXT NOT NULL,
        status TEXT,
        deviceId TEXT,
        latitude REAL,
        longitude REAL
      )
    ''');
  }

  Future<void> _createPunchSyncQueueTable(Database db) async {
    await db.execute('''
      CREATE TABLE punch_sync_queue (
        punch_id INTEGER PRIMARY KEY,
        FOREIGN KEY (punch_id) REFERENCES punch_event (id) ON DELETE CASCADE
      )
    ''');
  }

  Future<void> addPunchEventToQueue(PunchEvent event) async {
    final db = await instance.database;
    await db.transaction((txn) async {
      final id = await txn.insert('punch_event', event.toMap(),
          conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.insert(
        'punch_sync_queue',
        {'punch_id': id},
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
    });
  }

  Future<List<PunchEvent>> getQueuedPunchEvents() async {
    final db = await instance.database;
    final result = await db.rawQuery('''
      SELECT p.* FROM punch_event p
      INNER JOIN punch_sync_queue q ON p.id = q.punch_id
    ''');
    return result.map((json) => PunchEvent.fromMap(json)).toList();
  }

  Future<void> clearSyncedPunchEvents(List<int> punchIds) async {
    final db = await instance.database;
    final batch = db.batch();
    for (final id in punchIds) {
      batch.delete('punch_sync_queue', where: 'punch_id = ?', whereArgs: [id]);
    }
    await batch.commit(noResult: true);
    print('${punchIds.length} punch events cleared from sync queue.');
  }

  // --- Methods for Employee Profiles ---

  /// --- UPDATED: Now correctly maps keys from the server JSON response. ---
  Future<void> syncProfilesFromServer(
      List<Map<String, dynamic>> profiles) async {
    final db = await instance.database;
    final batch = db.batch();

    for (final profile in profiles) {
      // Create a map that correctly matches the DB columns with the JSON keys.
      final dbRow = {
        'employee_id': profile['employeeId'],

        // --- FIX 1: Use the correct key 'employeeImageData' ---
        'image_data': profile['employeeImageData'],

        // --- FIX 2: Use 'updatedAt' for the timestamp column ---
        'timestamp': profile['updatedAt'],

        // --- FIX 3: Other fields like 'name', 'latitude', 'longitude' are not in the
        // JSON, so we don't try to map them. They will remain null in the DB
        // unless updated by another process.
      };

      batch.insert(
        'employee_profile_registration',
        dbRow,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }

    await batch.commit(noResult: true);
    print(
        '✅ Synced ${profiles.length} profiles from server to local database.');
  }

  Future<void> syncEmployeeIds(List<String> employeeIds) async {
    final db = await instance.database;
    final batch = db.batch();
    for (final id in employeeIds) {
      batch.rawInsert(
        'INSERT OR IGNORE INTO employee_profile_registration (employee_id) VALUES (?)',
        [id],
      );
    }
    await batch.commit(noResult: true);
  }

  Future<bool> employeeExists(String employeeId) async {
    final db = await instance.database;
    final result = await db.query(
      'employee_profile_registration',
      where: 'employee_id = ?',
      whereArgs: [employeeId],
      limit: 1,
    );
    return result.isNotEmpty;
  }

  Future<void> updateEmployeeEmbedding(String employeeId,
      String imageData) async {
    final db = await instance.database;
    await db.update(
      'employee_profile_registration',
      {'image_data': imageData},
      where: 'employee_id = ?',
      whereArgs: [employeeId],
    );
  }

  Future<void> updateEmployeeProfile(Map<String, dynamic> profileData) async {
    final db = await instance.database;
    await db.update(
      'employee_profile_registration',
      profileData,
      where: 'employee_id = ?',
      whereArgs: [profileData['employee_id']],
    );
  }

  Future<void> addProfileToSyncQueue(String employeeId) async {
    final db = await instance.database;
    await db.insert(
      'sync_queue',
      {'employee_id': employeeId},
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<List<Map<String, dynamic>>> getQueuedProfiles() async {
    final db = await instance.database;
    final result = await db.rawQuery('''
      SELECT p.employee_id as employeeId, p.image_data as employeeImageData
      FROM employee_profile_registration p
      INNER JOIN sync_queue q ON p.employee_id = q.employee_id
    ''');
    return result;
  }

  Future<void> clearSyncedProfiles(List<String> employeeIds) async {
    final db = await instance.database;
    final batch = db.batch();
    for (final id in employeeIds) {
      batch.delete('sync_queue', where: 'employee_id = ?', whereArgs: [id]);
    }
    await batch.commit(noResult: true);
  }

  Future<void> insertPunchEvent(PunchEvent punchEvent) async {
    final db = await instance.database;
    await db.insert('punch_event', punchEvent.toMap());
  }

  Future<List<Map<String, dynamic>>> getAllEmployeeProfiles() async {
    final db = await instance.database;
    return await db.query('employee_profile_registration');
  }

  // Returns employeeId -> List<List<double>> (multi-template).
// Supports both legacy single-vector JSON "[...]" and new multi-vector JSON "[[...],[...],...]".
  Future<Map<String, List<List<double>>>> getAllEmployeeEmbeddingsMap() async {
    final db = await database;

    // Adjust the table/columns to match your schema if needed.
    // These are the most common in your project; wrapped in try-catch to avoid breakage.
    const String table = 'employee_profile_registration';
    const String idCol = 'employee_id';
    const String embeddingCol = 'image_data';

    final Map<String, List<List<double>>> out = {};
    try {
      final rows = await db.query(
        table,
        columns: [idCol, embeddingCol],
        where: '$embeddingCol IS NOT NULL',
      );

      for (final r in rows) {
        final String empId = (r[idCol] as String).trim();
        final String jsonStr = (r[embeddingCol] as String).trim();
        final parsed = _parseEmbeddingJson(jsonStr);
        if (parsed != null && parsed.isNotEmpty) {
          out[empId] = parsed;
        }
      }
    } catch (_) {
      // If your embeddings live elsewhere, point to that table/columns instead.
      // Intentionally swallow to avoid crashing existing flows.
    }
    return out;
  }

  // Parses:
//  - "[f1,f2,...]" -> [[f1,f2,...]]
//  - "[[...],[...],...]" -> kept as-is
  List<List<double>>? _parseEmbeddingJson(String jsonStr) {
    try {
      final dynamic j = json.decode(jsonStr);
      if (j is List) {
        if (j.isEmpty) return const [];
        if (j.first is List) {
          return j
              .map<List<double>>(
                  (it) =>
                  (it as List).map((e) => (e as num).toDouble()).toList(
                      growable: false))
              .toList(growable: false);
        }
        if (j.first is num) {
          return [
            j.map<double>((e) => (e as num).toDouble()).toList(growable: false)
          ];
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }
}
