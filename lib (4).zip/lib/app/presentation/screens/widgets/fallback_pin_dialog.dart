// fallback_pin_dialog.dart
import 'package:flutter/material.dart';

Future<String?> showFallbackPinDialog(BuildContext context) async {
  final controller = TextEditingController();
  return showDialog<String>(
    context: context,
    barrierDismissible: false,
    builder: (_) => AlertDialog(
      title: const Text('Identity Verification'),
      content: TextField(
        controller: controller,
        autofocus: true,
        decoration: const InputDecoration(
          labelText: 'Enter Employee ID / Badge / PIN',
          border: OutlineInputBorder(),
        ),
      ),
      actions: [
        TextButton(onPressed: ()=> Navigator.of(context).pop(null), child: const Text('Cancel')),
        FilledButton(onPressed: ()=> Navigator.of(context).pop(controller.text.trim()), child: const Text('Verify')),
      ],
    ),
  );
}
