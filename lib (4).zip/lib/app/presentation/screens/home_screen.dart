// // lib/app/presentation/screens/home_screen.dart
//
// import 'dart:async';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
// import 'package:kiosk/app/core/services/sync_service.dart';
// import 'package:kiosk/app/presentation/screens/punch_camera_screen.dart';
// import 'package:kiosk/app/presentation/screens/registration_screen.dart';
//
// import '../../core/models /punch_event.dart';
//
//
// class HomeScreen extends StatefulWidget {
//   const HomeScreen({super.key});
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   late Timer _clockTimer;
//   late Timer _queueStatusTimer;
//   String _timeString = '';
//   String _dateString = '';
//
//   // --- State for Sync Status ---
//   final SyncService _syncService = SyncService();
//   StreamSubscription? _connectivitySubscription;
//   bool _isOnline = false;
//   int _queuedItems = 0;
//
//   @override
//   void initState() {
//     super.initState();
//     _updateTime();
//     _clockTimer =
//         Timer.periodic(const Duration(seconds: 1), (Timer t) => _updateTime());
//
//     // --- Initialize Sync and Connectivity Listeners ---
//     _initializeSyncAndConnectivity();
//
//     // Periodically check the queue status to keep the UI updated
//     _queueStatusTimer = Timer.periodic(
//         const Duration(seconds: 5), (timer) => _updateQueueStatus());
//   }
//
//   @override
//   void dispose() {
//     _clockTimer.cancel();
//     _queueStatusTimer.cancel();
//     _connectivitySubscription?.cancel();
//     _syncService.dispose(); // Clean up sync service listeners
//     super.dispose();
//   }
//
//   void _initializeSyncAndConnectivity() {
//     // Listen for connectivity changes. The SyncService handles the actual trigger.
//     _connectivitySubscription =
//         Connectivity().onConnectivityChanged.listen((_) async {
//           await _checkConnectivityStatus();
//         });
//     // Run an initial check when the screen loads.
//     _checkConnectivityStatus();
//   }
//
//   Future<void> _checkConnectivityStatus() async {
//     final connectivityResult = await Connectivity().checkConnectivity();
//     if (mounted) {
//       setState(() {
//         _isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
//             connectivityResult.contains(ConnectivityResult.wifi);
//       });
//       // Update the local queue count for the UI.
//       _updateQueueStatus();
//     }
//   }
//
//   Future<void> _updateQueueStatus() async {
//     final profiles = await DatabaseService.instance.getQueuedProfiles();
//     final punches = await DatabaseService.instance.getQueuedPunchEvents();
//     if (mounted) {
//       setState(() {
//         _queuedItems = profiles.length + punches.length;
//       });
//     }
//   }
//
//   void _updateTime() {
//     final now = DateTime.now();
//     final formattedTime = DateFormat('h:mm:ss a').format(now);
//     // --- DATE FORMAT UPDATED ---
//     final formattedDate = DateFormat('E, MMM d, yyyy').format(now);
//     if (mounted) {
//       setState(() {
//         _timeString = formattedTime;
//         _dateString = formattedDate;
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       body: SafeArea(
//         child: Column(
//           children: [
//             _buildHeader(context),
//             Expanded(child: _buildMainContent()),
//             _buildFooter(),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildHeader(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           IconButton(
//             icon: const Icon(Icons.settings_outlined,
//                 color: Color(0xFF6C757D), size: 28),
//             onPressed: () => _showSettingsModal(context),
//           ),
//           // --- ICON REMOVED ---
//           // The Row's `spaceBetween` property will handle the layout.
//           _buildSyncStatusIndicator(),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildSyncStatusIndicator() {
//     IconData icon;
//     Color color;
//     String text;
//
//     if (_isOnline) {
//       if (_queuedItems > 0) {
//         icon = Icons.sync_problem_outlined;
//         color = Colors.orange.shade700;
//         text = '$_queuedItems Pending';
//       } else {
//         icon = Icons.cloud_done_outlined;
//         color = Colors.green.shade600;
//         text = 'Synced';
//       }
//     } else {
//       icon = Icons.cloud_off_outlined;
//       color = Colors.grey.shade600;
//       text = 'Offline';
//     }
//
//     return InkWell(
//       onTap: () {
//         if (_isOnline) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//                 content: Text("Attempting manual sync..."),
//                 duration: Duration(seconds: 2)),
//           );
//           _syncService.triggerSync();
//           // Update status after a short delay to reflect sync attempt
//           Future.delayed(
//               const Duration(seconds: 3), () => _updateQueueStatus());
//         } else {
//           ScaffoldMessenger.of(context).showSnackBar(
//             const SnackBar(
//                 content: Text("Cannot sync. Device is offline."),
//                 duration: Duration(seconds: 2)),
//           );
//         }
//       },
//       borderRadius: BorderRadius.circular(8),
//       child: Padding(
//         padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
//         child: Row(
//           children: [
//             Icon(icon, color: color, size: 24),
//             const SizedBox(width: 8),
//             Text(text,
//                 style: TextStyle(
//                     color: color, fontWeight: FontWeight.w500, fontSize: 16)),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildMainContent() {
//     return LayoutBuilder(
//       builder: (context, constraints) {
//         final bool isTablet = constraints.maxWidth > 768;
//         return SingleChildScrollView(
//           child: ConstrainedBox(
//             constraints: BoxConstraints(minHeight: constraints.maxHeight),
//             child: Padding(
//               padding:
//               const EdgeInsets.symmetric(horizontal: 24.0, vertical: 10.0),
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   _buildLiveClock(isTablet),
//                   const SizedBox(height: 60),
//                   SizedBox(
//                     width: isTablet ? 600 : 350,
//                     child: _buildPunchCards(isTablet),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   Widget _buildLiveClock(bool isTablet) {
//     return Column(
//       children: [
//         Text(
//           _dateString,
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             fontSize: isTablet ? 28.0 : 22.0,
//             fontWeight: FontWeight.w500,
//             color: const Color(0xFF343A40),
//           ),
//         ),
//         Text(
//           _timeString,
//           textAlign: TextAlign.center,
//           style: TextStyle(
//             fontSize: isTablet ? 65.0 : 45.0,
//             fontWeight: FontWeight.bold,
//             color: const Color(0xFF212529),
//             letterSpacing: -2,
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget _buildPunchCards(bool isTablet) {
//     final punchInCard = _buildPunchInCard(isTablet);
//     final punchOutCard = _buildPunchOutCard(isTablet);
//
//     if (isTablet) {
//       return Row(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Flexible(child: punchInCard),
//           const SizedBox(width: 24),
//           Flexible(child: punchOutCard),
//         ],
//       );
//     } else {
//       return Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           punchInCard,
//           const SizedBox(height: 24),
//           punchOutCard,
//         ],
//       );
//     }
//   }
//
//   void _navigateToCamera(PunchType punchType) {
//     Navigator.of(context).push(
//       MaterialPageRoute(
//           builder: (context) => PunchCameraScreen(punchType: punchType)),
//     );
//   }
//
//   Widget _buildPunchInCard(bool isTablet) {
//     return _buildPunchCard(
//       isTablet: isTablet,
//       color: Colors.blue,
//       icon: Icons.arrow_forward,
//       title: 'Punch In',
//       subtitle: 'Tap to start your workday',
//       onTap: () => _navigateToCamera(PunchType.IN),
//     );
//   }
//
//   Widget _buildPunchOutCard(bool isTablet) {
//     return _buildPunchCard(
//       isTablet: isTablet,
//       color: Colors.red,
//       icon: Icons.arrow_back,
//       title: 'Punch Out',
//       subtitle: 'Tap to end your workday',
//       onTap: () => _navigateToCamera(PunchType.OUT),
//     );
//   }
//
//   Widget _buildPunchCard({
//     required bool isTablet,
//     required Color color,
//     required IconData icon,
//     required String title,
//     required String subtitle,
//     required VoidCallback onTap,
//   }) {
//     return Material(
//       color: color,
//       borderRadius: BorderRadius.circular(20.0),
//       elevation: 4,
//       child: InkWell(
//         onTap: onTap,
//         borderRadius: BorderRadius.circular(20.0),
//         child: Container(
//           padding: const EdgeInsets.all(16.0),
//           height: isTablet ? 220 : 160,
//           width: double.infinity,
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Container(
//                 padding: EdgeInsets.all(isTablet ? 20 : 14),
//                 decoration: BoxDecoration(
//                   color: Colors.white.withOpacity(0.2),
//                   shape: BoxShape.circle,
//                 ),
//                 child:
//                 Icon(icon, size: isTablet ? 48 : 32, color: Colors.white),
//               ),
//               SizedBox(height: isTablet ? 16 : 10),
//               Text(
//                 title,
//                 style: TextStyle(
//                   fontSize: isTablet ? 35 : 26,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.white,
//                 ),
//               ),
//               Text(
//                 subtitle,
//                 style: TextStyle(
//                   fontSize: isTablet ? 18 : 14,
//                   color: Colors.white.withOpacity(0.9),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildFooter() {
//     return const Padding(
//       padding: EdgeInsets.all(16.0),
//       child: Text(
//         '© 2025 WFM Experts India Pvt Ltd. All rights reserved.',
//         textAlign: TextAlign.center,
//         style: TextStyle(fontSize: 12, color: Color(0xFF6C757D)),
//       ),
//     );
//   }
//
//   void _showSettingsModal(BuildContext context) {
//     showModalBottomSheet(
//       context: context,
//       shape: const RoundedRectangleBorder(
//         borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
//       ),
//       builder: (bottomSheetContext) {
//         return Padding(
//           padding: const EdgeInsets.all(16.0),
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               ListTile(
//                 leading: const Icon(Icons.person_outline, color: Colors.blue),
//                 title: const Text('Admin Login', style: TextStyle(fontSize: 18)),
//                 onTap: () async {
//                   Navigator.pop(bottomSheetContext);
//                   final bool? loginSuccess =
//                   await _showAdminLoginModal(context);
//                   if (loginSuccess == true && mounted) {
//                     _syncService.triggerSync();
//                     Navigator.of(context).push(
//                       MaterialPageRoute(
//                         builder: (context) => const RegistrationScreen(),
//                       ),
//                     );
//                   }
//                 },
//               ),
//               ListTile(
//                 leading: const Icon(Icons.info_outline, color: Colors.orange),
//                 title: const Text('About', style: TextStyle(fontSize: 18)),
//                 onTap: () {
//                   Navigator.pop(context);
//                   // TODO: Show About dialog
//                 },
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
//
//   Future<bool?> _showAdminLoginModal(BuildContext context) {
//     return showDialog<bool>(
//       context: context,
//       builder: (BuildContext context) {
//         return const AdminLoginDialog();
//       },
//     );
//   }
// }
//
// class AdminLoginDialog extends StatefulWidget {
//   const AdminLoginDialog({super.key});
//
//   @override
//   State<AdminLoginDialog> createState() => _AdminLoginDialogState();
// }
//
// class _AdminLoginDialogState extends State<AdminLoginDialog> {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController _emailController = TextEditingController();
//   final TextEditingController _passwordController = TextEditingController();
//   final ApiService _apiService = ApiService();
//   bool _isPasswordVisible = false;
//   bool _isLoading = false;
//
//   @override
//   void dispose() {
//     _emailController.dispose();
//     _passwordController.dispose();
//     super.dispose();
//   }
//
//   Future<void> _login() async {
//     if (!_formKey.currentState!.validate()) {
//       return;
//     }
//
//     setState(() {
//       _isLoading = true;
//     });
//
//     final String? token = await _apiService.login(
//       _emailController.text,
//       _passwordController.text,
//     );
//
//     if (mounted) {
//       setState(() {
//         _isLoading = false;
//       });
//
//       if (token != null) {
//         Navigator.of(context).pop(true); // Return true on success
//       } else {
//         ScaffoldMessenger.of(context).showSnackBar(
//           const SnackBar(
//               backgroundColor: Colors.redAccent,
//               content: Text('Login failed. Please check credentials.')),
//         );
//       }
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       backgroundColor: const Color(0xFFF0F2F5),
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(20.0),
//       ),
//       title: const Text(
//         'Admin Login',
//         textAlign: TextAlign.center,
//         style: TextStyle(fontWeight: FontWeight.bold),
//       ),
//       content: SizedBox(
//         width: 400,
//         child: Form(
//           key: _formKey,
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               TextFormField(
//                 controller: _emailController,
//                 keyboardType: TextInputType.emailAddress,
//                 autofocus: true,
//                 style: const TextStyle(
//                   fontSize: 18.0,
//                 ),
//                 decoration: InputDecoration(
//                   hintText: 'Enter Email',
//                   filled: true,
//                   fillColor: Colors.white,
//                   prefixIcon: const Icon(Icons.email_outlined),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12.0),
//                     borderSide: BorderSide.none,
//                   ),
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your email';
//                   }
//                   if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
//                     return 'Please enter a valid email';
//                   }
//                   return null;
//                 },
//               ),
//               const SizedBox(height: 16.0),
//               TextFormField(
//                 controller: _passwordController,
//                 obscureText: !_isPasswordVisible,
//                 style: const TextStyle(
//                   fontSize: 18.0,
//                 ),
//                 decoration: InputDecoration(
//                   hintText: 'Enter Password',
//                   filled: true,
//                   fillColor: Colors.white,
//                   prefixIcon: const Icon(Icons.lock_outline),
//                   border: OutlineInputBorder(
//                     borderRadius: BorderRadius.circular(12.0),
//                     borderSide: BorderSide.none,
//                   ),
//                   suffixIcon: IconButton(
//                     icon: Icon(
//                       _isPasswordVisible
//                           ? Icons.visibility_outlined
//                           : Icons.visibility_off_outlined,
//                       color: const Color(0xFF6C757D),
//                     ),
//                     onPressed: () {
//                       setState(() {
//                         _isPasswordVisible = !_isPasswordVisible;
//                       });
//                     },
//                   ),
//                 ),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter your password';
//                   }
//                   return null;
//                 },
//               ),
//             ],
//           ),
//         ),
//       ),
//       actions: <Widget>[
//         TextButton(
//           child: const Text('Cancel'),
//           onPressed: () {
//             Navigator.of(context).pop(false);
//           },
//         ),
//         SizedBox(
//           height: 45,
//           child: ElevatedButton(
//             onPressed: _isLoading ? null : _login,
//             style: ElevatedButton.styleFrom(
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(12.0),
//               ),
//             ),
//             child: _isLoading
//                 ? const SizedBox(
//               width: 20,
//               height: 20,
//               child: CircularProgressIndicator(
//                 strokeWidth: 2,
//                 valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
//               ),
//             )
//                 : const Text('Login'),
//           ),
//         ),
//       ],
//       actionsAlignment: MainAxisAlignment.end,
//       actionsPadding: const EdgeInsets.fromLTRB(0, 16, 24, 16),
//     );
//   }
// }
import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:kiosk/app/core/services/api_service.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:kiosk/app/core/services/sync_service.dart';
import 'package:kiosk/app/presentation/screens/punch_camera_screen.dart';
import 'package:kiosk/app/presentation/screens/registration_screen.dart';

import '../../core/models/punch_event.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Timer _clockTimer;
  late Timer _queueStatusTimer;
  String _timeString = '';
  String _dateString = '';

  final SyncService _syncService = SyncService();
  StreamSubscription? _connectivitySubscription;
  bool _isOnline = false;
  int _queuedItems = 0;

  @override
  void initState() {
    super.initState();
    _updateTime();
    _clockTimer =
        Timer.periodic(const Duration(seconds: 1), (Timer t) => _updateTime());

    _initializeSyncAndConnectivity();

    _queueStatusTimer = Timer.periodic(
        const Duration(seconds: 5), (timer) => _updateQueueStatus());
  }

  @override
  void dispose() {
    _clockTimer.cancel();
    _queueStatusTimer.cancel();
    _connectivitySubscription?.cancel();
    _syncService.dispose();
    super.dispose();
  }

  void _initializeSyncAndConnectivity() {
    _connectivitySubscription =
        Connectivity().onConnectivityChanged.listen((_) async {
          await _checkConnectivityStatus();
        });
    _checkConnectivityStatus();
  }

  Future<void> _checkConnectivityStatus() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    if (mounted) {
      setState(() {
        _isOnline = connectivityResult.contains(ConnectivityResult.mobile) ||
            connectivityResult.contains(ConnectivityResult.wifi);
      });
      _updateQueueStatus();
    }
  }

  Future<void> _updateQueueStatus() async {
    final profiles = await DatabaseService.instance.getQueuedProfiles();
    final punches = await DatabaseService.instance.getQueuedPunchEvents();
    if (mounted) {
      setState(() {
        _queuedItems = profiles.length + punches.length;
      });
    }
  }

  void _updateTime() {
    final now = DateTime.now();
    final formattedTime = DateFormat('h:mm:ss a').format(now);
    final formattedDate = DateFormat('E, MMM d, yyyy').format(now);
    if (mounted) {
      setState(() {
        _timeString = formattedTime;
        _dateString = formattedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(context),
            Expanded(child: _buildMainContent()),
            _buildFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: const Icon(Icons.settings_outlined,
                color: Color(0xFF6C757D), size: 28),
            onPressed: () => _showSettingsModal(context),
          ),
          _buildSyncStatusIndicator(),
        ],
      ),
    );
  }

  Widget _buildSyncStatusIndicator() {
    IconData icon;
    Color color;
    String text;

    if (_isOnline) {
      if (_queuedItems > 0) {
        icon = Icons.sync_problem_outlined;
        color = Colors.orange.shade700;
        text = '$_queuedItems Pending';
      } else {
        icon = Icons.cloud_done_outlined;
        color = Colors.green.shade600;
        text = 'Synced';
      }
    } else {
      icon = Icons.cloud_off_outlined;
      color = Colors.grey.shade600;
      text = 'Offline';
    }

    return InkWell(
      onTap: () {
        if (_isOnline) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text("Attempting manual sync..."),
                duration: Duration(seconds: 2)),
          );
          _syncService.triggerSync();
          Future.delayed(
              const Duration(seconds: 3), () => _updateQueueStatus());
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text("Cannot sync. Device is offline."),
                duration: Duration(seconds: 2)),
          );
        }
      },
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
        child: Row(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(width: 8),
            Text(text,
                style: TextStyle(
                    color: color, fontWeight: FontWeight.w500, fontSize: 16)),
          ],
        ),
      ),
    );
  }

  Widget _buildMainContent() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bool isTablet = constraints.maxWidth > 768;
        return SingleChildScrollView(
          child: ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.maxHeight),
            child: Padding(
              padding:
              const EdgeInsets.symmetric(horizontal: 24.0, vertical: 10.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildLiveClock(isTablet),
                  const SizedBox(height: 60),
                  SizedBox(
                    width: isTablet ? 600 : 350,
                    child: _buildPunchCards(isTablet),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildLiveClock(bool isTablet) {
    return Column(
      children: [
        Text(
          _dateString,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: isTablet ? 28.0 : 22.0,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF343A40),
          ),
        ),
        Text(
          _timeString,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: isTablet ? 65.0 : 45.0,
            fontWeight: FontWeight.bold,
            color: const Color(0xFF212529),
            letterSpacing: -2,
          ),
        ),
      ],
    );
  }

  Widget _buildPunchCards(bool isTablet) {
    final punchInCard = _buildPunchInCard(isTablet);
    final punchOutCard = _buildPunchOutCard(isTablet);

    if (isTablet) {
      return Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Flexible(child: punchInCard),
          const SizedBox(width: 24),
          Flexible(child: punchOutCard),
        ],
      );
    } else {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          punchInCard,
          const SizedBox(height: 24),
          punchOutCard,
        ],
      );
    }
  }

  void _navigateToCamera(PunchType punchType) {
    Navigator.of(context).push(
      MaterialPageRoute(
          builder: (context) => PunchCameraScreen(punchType: punchType)),
    );
  }

  Widget _buildPunchInCard(bool isTablet) {
    return _buildPunchCard(
      isTablet: isTablet,
      color: Colors.blue,
      icon: Icons.arrow_forward,
      title: 'Punch In',
      subtitle: 'Tap to start your workday',
      onTap: () => _navigateToCamera(PunchType.IN),
    );
  }

  Widget _buildPunchOutCard(bool isTablet) {
    return _buildPunchCard(
      isTablet: isTablet,
      color: Colors.red,
      icon: Icons.arrow_back,
      title: 'Punch Out',
      subtitle: 'Tap to end your workday',
      onTap: () => _navigateToCamera(PunchType.OUT),
    );
  }

  Widget _buildPunchCard({
    required bool isTablet,
    required Color color,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: color,
      borderRadius: BorderRadius.circular(20.0),
      elevation: 4,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20.0),
        child: Container(
          padding: const EdgeInsets.all(16.0),
          height: isTablet ? 220 : 160,
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(isTablet ? 20 : 14),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  shape: BoxShape.circle,
                ),
                child:
                Icon(icon, size: isTablet ? 48 : 32, color: Colors.white),
              ),
              SizedBox(height: isTablet ? 16 : 10),
              Text(
                title,
                style: TextStyle(
                  fontSize: isTablet ? 35 : 26,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: isTablet ? 18 : 14,
                  color: Colors.white.withOpacity(0.9),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return const Padding(
      padding: EdgeInsets.all(16.0),
      child: Text(
        '© 2025 WFM Experts India Pvt Ltd. All rights reserved.',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 12, color: Color(0xFF6C757D)),
      ),
    );
  }

  void _showSettingsModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (bottomSheetContext) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.person_outline, color: Colors.blue),
                title:
                const Text('Admin Login', style: TextStyle(fontSize: 18)),
                onTap: () async {
                  Navigator.pop(bottomSheetContext);
                  final bool? loginSuccess =
                  await _showAdminLoginModal(context);
                  if (loginSuccess == true && mounted) {
                    _syncService.triggerSync();
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const RegistrationScreen(),
                      ),
                    );
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.info_outline, color: Colors.orange),
                title: const Text('About', style: TextStyle(fontSize: 18)),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Future<bool?> _showAdminLoginModal(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return const AdminLoginDialog();
      },
    );
  }
}

class AdminLoginDialog extends StatefulWidget {
  const AdminLoginDialog({super.key});

  @override
  State<AdminLoginDialog> createState() => _AdminLoginDialogState();
}

class _AdminLoginDialogState extends State<AdminLoginDialog> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final ApiService _apiService = ApiService();
  bool _isPasswordVisible = false;
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final String? token = await _apiService.login(
      _emailController.text,
      _passwordController.text,
    );

    if (mounted) {
      setState(() {
        _isLoading = false;
      });

      if (token != null) {
        Navigator.of(context).pop(true); // Return true on success
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              backgroundColor: Colors.redAccent,
              content: Text('Login failed. Please check credentials.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: const Color(0xFFF0F2F5),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      title: const Text(
        'Admin Login',
        textAlign: TextAlign.center,
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      content: SizedBox(
        width: 400,
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _emailController,
                keyboardType: TextInputType.emailAddress,
                autofocus: true,
                style: const TextStyle(
                  fontSize: 18.0,
                ),
                decoration: InputDecoration(
                  hintText: 'Enter Email',
                  filled: true,
                  fillColor: Colors.white,
                  prefixIcon: const Icon(Icons.email_outlined),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide.none,
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your email';
                  }
                  if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16.0),
              TextFormField(
                controller: _passwordController,
                obscureText: !_isPasswordVisible,
                style: const TextStyle(
                  fontSize: 18.0,
                ),
                decoration: InputDecoration(
                  hintText: 'Enter Password',
                  filled: true,
                  fillColor: Colors.white,
                  prefixIcon: const Icon(Icons.lock_outline),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                    borderSide: BorderSide.none,
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      _isPasswordVisible
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined,
                      color: const Color(0xFF6C757D),
                    ),
                    onPressed: () {
                      setState(() {
                        _isPasswordVisible = !_isPasswordVisible;
                      });
                    },
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your password';
                  }
                  return null;
                },
              ),
            ],
          ),
        ),
      ),
      actions: <Widget>[
        TextButton(
          child: const Text('Cancel'),
          onPressed: () {
            Navigator.of(context).pop(false);
          },
        ),
        SizedBox(
          height: 45,
          child: ElevatedButton(
            onPressed: _isLoading ? null : _login,
            style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            child: _isLoading
                ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            )
                : const Text('Login'),
          ),
        ),
      ],
      actionsAlignment: MainAxisAlignment.end,
      actionsPadding: const EdgeInsets.fromLTRB(0, 16, 24, 16),
    );
  }
}