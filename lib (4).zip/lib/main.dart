// // lib/main.dart
// import 'package:flutter/material.dart';
//
// // Entry
// void main() => runApp(const WfmApp());
//
// class WfmApp extends StatelessWidget {
//   const WfmApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     final theme = ThemeData(
//       useMaterial3: true,
//       colorSchemeSeed: const Color(0xFF667eea),
//       brightness: Brightness.light,
//       textTheme: const TextTheme(
//         headlineSmall: TextStyle(fontWeight: FontWeight.w700),
//         titleMedium: TextStyle(fontWeight: FontWeight.w700),
//       ),
//       scaffoldBackgroundColor: const Color(0xFFF8F9FA),
//       cardTheme: CardThemeData(
//         elevation: 2,
//         margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//       ),
//     );
//
//     return MaterialApp(
//       debugShowCheckedModeBanner: false,
//       title: 'WFM Employee',
//       theme: theme,
//       home: const RootShell(),
//     );
//   }
// }
//
// /// Root with Bottom Navigation
// class RootShell extends StatefulWidget {
//   const RootShell({super.key});
//   @override
//   State<RootShell> createState() => _RootShellState();
// }
//
// class _RootShellState extends State<RootShell> {
//   int _index = 0;
//   int inboxBadge = 4;
//   int bellBadge = 3;
//
//   final PageController _pageController = PageController();
//
//   void _toast(String msg) {
//     ScaffoldMessenger.of(context)
//       ..hideCurrentSnackBar()
//       ..showSnackBar(SnackBar(
//         behavior: SnackBarBehavior.floating,
//         content: Text(msg, style: const TextStyle(fontWeight: FontWeight.w600)),
//         duration: const Duration(seconds: 2),
//       ));
//   }
//
//   void _gotoReplacement() {
//     Navigator.of(context).push(MaterialPageRoute(
//       builder: (_) => ReplacementScreen(onSubmit: () {
//         _toast('📤 Replacement request sent to manager');
//       }),
//     ));
//   }
//
//   void _gotoPickup() {
//     Navigator.of(context).push(MaterialPageRoute(
//       builder: (_) => PickupScreen(
//         onPick: () => _toast('🎯 Shift pickup request submitted'),
//       ),
//     ));
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final navItems = <_NavItem>[
//       _NavItem('My Day', Icons.home_rounded),
//       _NavItem('Timesheet', Icons.bar_chart_rounded),
//       _NavItem('Schedule', Icons.calendar_month_rounded),
//       _NavItem('Leave', Icons.beach_access_rounded),
//       _NavItem('Inbox', Icons.inbox_rounded, badge: inboxBadge),
//     ];
//
//     return Container(
//       decoration: const BoxDecoration(
//         gradient: LinearGradient(
//           colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//         ),
//       ),
//       child: SafeArea(
//         child: Scaffold(
//           backgroundColor: Colors.transparent,
//           floatingActionButton: FloatingActionButton(
//             tooltip: 'Show All',
//             onPressed: () {
//               _toast('👁️ All sections accessible via tabs & routes');
//             },
//             child: const Text('👁️', style: TextStyle(fontSize: 20)),
//           ),
//           bottomNavigationBar: Container(
//             decoration: const BoxDecoration(
//               color: Colors.white,
//               border: Border(top: BorderSide(color: Color(0xFFE9ECEF))),
//             ),
//             child: NavigationBar(
//               selectedIndex: _index,
//               height: 72,
//               onDestinationSelected: (i) {
//                 setState(() => _index = i);
//                 _pageController.jumpToPage(i);
//               },
//               destinations: [
//                 for (final item in navItems)
//                   NavigationDestination(
//                     icon: _BadgeIcon(
//                       icon: item.icon,
//                       badge: item.badge,
//                     ),
//                     label: item.label,
//                   ),
//               ],
//             ),
//           ),
//           body: PageView(
//             controller: _pageController,
//             physics: const NeverScrollableScrollPhysics(),
//             children: [
//               MyDayScreen(
//                 bellBadge: bellBadge,
//                 onClockIn: () => _toast('✅ Clocked in successfully at 08:00'),
//                 onCantMake: _gotoReplacement,
//                 onViewTeam: () => _toast('👥 Team screen coming soon'),
//               ),
//               TimesheetScreen(
//                 onSaveDraft: () => _toast('💾 Draft saved'),
//                 onSubmitWeek: () =>
//                     _toast('⏰ Timesheet submitted for manager approval'),
//               ),
//               ScheduleScreen(
//                 onRequestTimeOff: () => _pageTo(3),
//                 onPickShift: _gotoPickup,
//                 onCantMake: _gotoReplacement,         // NEW
//               ),
//               LeaveScreen(
//                 onSaveDraft: () => _toast('💾 Leave draft saved'),
//                 onSubmit: () =>
//                     _toast('📋 Leave application submitted for approval'),
//               ),
//               InboxScreen(
//                 onClockIn: () => _toast('✅ Clocked in'),
//                 onMarkAllRead: () {
//                   setState(() => inboxBadge = 0);
//                   _toast('📬 All messages marked as read');
//                 },
//                 onSettings: () => _toast('⚙️ Settings opened'),
//                 onCantMake: _gotoReplacement, // NEW
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   void _pageTo(int index) {
//     setState(() => _index = index);
//     _pageController.jumpToPage(index);
//   }
// }
//
// class _NavItem {
//   final String label;
//   final IconData icon;
//   final int badge;
//   _NavItem(this.label, this.icon, {this.badge = 0});
// }
//
// class _BadgeIcon extends StatelessWidget {
//   final IconData icon;
//   final int badge;
//   const _BadgeIcon({required this.icon, this.badge = 0});
//
//   @override
//   Widget build(BuildContext context) {
//     final iconWidget = Icon(icon);
//     if (badge <= 0) return iconWidget;
//     return Stack(
//       clipBehavior: Clip.none,
//       children: [
//         iconWidget,
//         Positioned(
//           right: -6,
//           top: -6,
//           child: Container(
//             padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
//             decoration: BoxDecoration(
//               color: Colors.redAccent,
//               borderRadius: BorderRadius.circular(10),
//             ),
//             child: Text(
//               '$badge',
//               style: const TextStyle(
//                 fontSize: 10,
//                 color: Colors.white,
//                 fontWeight: FontWeight.w700,
//               ),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
// }
//
// /// ---------- Shared small UI helpers ----------
// class SectionHeader extends StatelessWidget {
//   final String title;
//   final IconData? icon;
//   final Widget? trailing;
//   const SectionHeader(this.title, {this.icon, this.trailing, super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     final t = Theme.of(context).textTheme.titleMedium;
//     return Padding(
//       padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
//       child: Row(
//         children: [
//           if (icon != null)
//             Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
//           if (icon != null) const SizedBox(width: 8),
//           Text(title, style: t),
//           const Spacer(),
//           if (trailing != null) trailing!,
//         ],
//       ),
//     );
//   }
// }
//
// class Pill extends StatelessWidget {
//   final String text;
//   final Color bg;
//   final Color fg;
//   const Pill(this.text, {required this.bg, required this.fg, super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
//       decoration:
//       BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
//       child: Text(
//         text,
//         style: TextStyle(
//           color: fg,
//           fontSize: 12,
//           fontWeight: FontWeight.w700,
//         ),
//       ),
//     );
//   }
// }
//
// class _StatCard extends StatelessWidget {
//   final String value;
//   final String label;
//   const _StatCard({required this.value, required this.label});
//
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       child: Padding(
//         padding:
//         const EdgeInsets.only(top: 14, bottom: 14, left: 12, right: 12),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text(value,
//                 style: TextStyle(
//                   fontSize: 20,
//                   color: Theme.of(context).colorScheme.primary,
//                   fontWeight: FontWeight.w800,
//                 )),
//             const SizedBox(height: 4),
//             Text(label,
//                 style: const TextStyle(fontSize: 12, color: Colors.black54)),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// /// ---------- Screen: My Day ----------
// class MyDayScreen extends StatelessWidget {
//   final int bellBadge;
//   final VoidCallback onClockIn;
//   final VoidCallback onCantMake;
//   final VoidCallback onViewTeam;
//
//   const MyDayScreen({
//     super.key,
//     required this.bellBadge,
//     required this.onClockIn,
//     required this.onCantMake,
//     required this.onViewTeam,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return _GradientScaffold(
//       title: 'WorkForce',
//       trailing: _BadgeIcon(icon: Icons.notifications_rounded, badge: bellBadge),
//       child: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//           const SizedBox(height: 8),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16),
//             child: _GreetingCard(
//               name: 'Harsh',
//               sub: 'Thursday, September 19, 2024',
//             ),
//           ),
//           _ShiftCard(
//             timeRange: '08:00 - 16:00',
//             status: 'Scheduled',
//             statusColor: Colors.green,
//             details: const [
//               _ShiftDetail(label: 'Location', value: 'Line A'),
//               _ShiftDetail(label: 'Duration', value: '8.0 hrs'),
//               _ShiftDetail(label: 'Type', value: 'Regular'),
//               _ShiftDetail(label: 'Next', value: 'Huddle 09:00'),
//             ],
//             actions: [
//               _ActionBtn.primary('Clock In', onClockIn),
//               _ActionBtn.outline('View Team', onViewTeam),
//               _ActionBtn.danger('Can\'t Make?', onCantMake),
//             ],
//           ),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Row(
//               children: const [
//                 Expanded(child: _StatCard(value: '7h 52m', label: 'Yesterday')),
//                 Expanded(child: _StatCard(value: '32h', label: 'This Week')),
//                 Expanded(child: _StatCard(value: '0', label: 'Exceptions')),
//               ],
//             ),
//           ),
//           Card(
//             margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
//             child: Column(
//               children: const [
//                 _NotifRow(
//                   colorBg: Color(0xFFFFE6E6),
//                   colorFg: Color(0xFFDC3545),
//                   icon: Icons.alarm_rounded,
//                   title: 'Shift starts in 30 minutes',
//                   text: 'Don\'t forget your safety gear',
//                 ),
//                 Divider(height: 1),
//                 _NotifRow(
//                   colorBg: Color(0xFFE6F7E6),
//                   colorFg: Color(0xFF28A745),
//                   icon: Icons.check_circle_rounded,
//                   title: 'Leave approved',
//                   text: '25-26 Sep casual leave approved',
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
// class _GradientScaffold extends StatelessWidget {
//   final String title;
//   final Widget child; // usually a ListView/ScrollView
//   final Widget? trailing;
//
//   const _GradientScaffold({
//     required this.title,
//     required this.child,
//     this.trailing,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     // We don't render a fake status bar; device provides it.
//     return Column(
//       children: [
//         // Gradient app header only
//         Container(
//           padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
//               begin: Alignment.centerLeft,
//               end: Alignment.centerRight,
//             ),
//           ),
//           child: Row(
//             children: [
//               Expanded(
//                 child: Text(
//                   title,
//                   maxLines: 1,
//                   overflow: TextOverflow.ellipsis,
//                   style: const TextStyle(
//                       color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800),
//                 ),
//               ),
//               if (trailing != null)
//                 IconTheme(
//                   data: const IconThemeData(color: Colors.white, size: 24),
//                   child: trailing!,
//                 ),
//             ],
//           ),
//         ),
//         // Body fills the rest
//         Expanded(child: child),
//       ],
//     );
//   }
// }
//
//
//
// class _GreetingCard extends StatelessWidget {
//   final String name;
//   final String sub;
//   const _GreetingCard({required this.name, required this.sub});
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text('Good morning, $name! 👋',
//             style: Theme.of(context).textTheme.headlineSmall),
//         const SizedBox(height: 6),
//         Text(sub, style: const TextStyle(color: Colors.black54)),
//         const SizedBox(height: 8),
//       ],
//     );
//   }
// }
//
// class _ShiftCard extends StatelessWidget {
//   final String timeRange;
//   final String status;
//   final Color statusColor;
//   final List<_ShiftDetail> details;
//   final List<Widget> actions;
//
//   const _ShiftCard({
//     required this.timeRange,
//     required this.status,
//     required this.statusColor,
//     required this.details,
//     required this.actions,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       margin: const EdgeInsets.fromLTRB(12, 8, 12, 8),
//       child: Container(
//         decoration: BoxDecoration(
//           border: Border(
//             left: BorderSide(width: 5, color: statusColor),
//           ),
//         ),
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           children: [
//             Row(
//               children: [
//                 Text(timeRange,
//                     style: const TextStyle(
//                         fontSize: 18, fontWeight: FontWeight.w800)),
//                 const Spacer(),
//                 Pill(status, bg: statusColor, fg: Colors.white),
//               ],
//             ),
//             const SizedBox(height: 12),
//             LayoutBuilder(builder: (context, c) {
//               final isWide = c.maxWidth > 360;
//               return GridView.count(
//                 shrinkWrap: true,
//                 physics: const NeverScrollableScrollPhysics(),
//                 crossAxisCount: isWide ? 2 : 1,
//                 childAspectRatio: isWide ? 4 : 6,
//                 crossAxisSpacing: 12,
//                 mainAxisSpacing: 8,
//                 children: [
//                   for (final d in details)
//                     _DetailTile(label: d.label, value: d.value),
//                 ],
//               );
//             }),
//             const SizedBox(height: 8),
//             Row(
//               children: [
//                 for (final a in actions) Expanded(child: a),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class _ShiftDetail {
//   final String label;
//   final String value;
//   const _ShiftDetail({required this.label, required this.value});
// }
//
// class _DetailTile extends StatelessWidget {
//   final String label;
//   final String value;
//   const _DetailTile({required this.label, required this.value});
//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         Text(label,
//             style: const TextStyle(fontSize: 12, color: Colors.black54)),
//         const SizedBox(height: 4),
//         Text(value,
//             style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
//       ],
//     );
//   }
// }
//
// class _ActionBtn extends StatelessWidget {
//   final String text;
//   final VoidCallback onTap;
//   final Color? color;
//   final Color? border;
//   final Color? fg;
//
//   const _ActionBtn._(
//       this.text, this.onTap, this.color, this.border, this.fg, {super.key});
//
//   factory _ActionBtn.primary(String text, VoidCallback onTap) =>
//       _ActionBtn._(text, onTap, null, null, null);
//
//   factory _ActionBtn.outline(String text, VoidCallback onTap) =>
//       _ActionBtn._(text, onTap, Colors.transparent, null, null);
//
//   factory _ActionBtn.danger(String text, VoidCallback onTap) =>
//       _ActionBtn._(text, onTap, Colors.redAccent, null, Colors.white);
//
//   @override
//   Widget build(BuildContext context) {
//     final cs = Theme.of(context).colorScheme;
//     final bg = color ?? cs.primary;
//     final foreground = fg ?? (color == null ? Colors.white : cs.primary);
//     final isOutline = color == Colors.transparent;
//
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
//       child: InkWell(
//         onTap: onTap,
//         borderRadius: BorderRadius.circular(10),
//         child: Ink(
//           padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
//           decoration: BoxDecoration(
//             color: isOutline ? Colors.transparent : bg,
//             borderRadius: BorderRadius.circular(10),
//             border: Border.all(
//               color: isOutline ? cs.primary : Colors.transparent,
//               width: 2,
//             ),
//           ),
//           child: Center(
//             child: Text(
//               text,
//               style: TextStyle(
//                 color: foreground,
//                 fontWeight: FontWeight.w700,
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class _NotifRow extends StatelessWidget {
//   final Color colorBg;
//   final Color colorFg;
//   final IconData icon;
//   final String title;
//   final String text;
//   const _NotifRow({
//     required this.colorBg,
//     required this.colorFg,
//     required this.icon,
//     required this.title,
//     required this.text,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       leading: CircleAvatar(
//         backgroundColor: colorBg,
//         child: Icon(icon, color: colorFg),
//       ),
//       title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
//       subtitle: Text(text),
//     );
//   }
// }
//
// /// ---------- Screen: Timesheet ----------
// class TimesheetScreen extends StatefulWidget {
//   final VoidCallback onSaveDraft;
//   final VoidCallback onSubmitWeek;
//   const TimesheetScreen(
//       {super.key, required this.onSaveDraft, required this.onSubmitWeek});
//   @override
//   State<TimesheetScreen> createState() => _TimesheetScreenState();
// }
//
// class _TimesheetScreenState extends State<TimesheetScreen> {
//   final TextEditingController _comment = TextEditingController();
//
//   @override
//   Widget build(BuildContext context) {
//     return _GradientScaffold(
//       title: 'Timesheet',
//       trailing: const Icon(Icons.save_alt_rounded),
//       child: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//           const SectionHeader('Week 13-19 Sep', icon: Icons.date_range_rounded),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 16),
//             child: Text('Total: 40h | OT: 0h | Status: Draft',
//                 style: const TextStyle(color: Colors.black54)),
//           ),
//           const SizedBox(height: 8),
//           _TimesheetWeekGrid(),
//           Card(
//             margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//             child: Padding(
//               padding: const EdgeInsets.all(16),
//               child: Column(
//                 children: [
//                   Row(
//                     children: const [
//                       Text('Thu 19 Sep Details',
//                           style: TextStyle(
//                               fontWeight: FontWeight.w800, fontSize: 16)),
//                       Spacer(),
//                       Pill('In Progress',
//                           bg: Colors.orange, fg: Colors.white),
//                     ],
//                   ),
//                   const SizedBox(height: 12),
//                   const _KeyVal('IN', '07:55 (Rounded: 08:00)'),
//                   const _KeyVal('OUT', '12:05 (Lunch)'),
//                   const _KeyVal('IN', '12:35 (Return)'),
//                   const _KeyVal('OUT', '--:-- (Pending)'),
//                   const SizedBox(height: 12),
//                   Row(
//                     children: const [
//                       Expanded(
//                         child: _DetailTile(
//                           label: 'Total Hours',
//                           value: '4h 30m',
//                         ),
//                       ),
//                       Expanded(
//                         child: _DetailTile(
//                           label: 'Exceptions',
//                           value: 'None',
//                         ),
//                       ),
//                     ],
//                   ),
//                   const SizedBox(height: 12),
//                   TextField(
//                     controller: _comment,
//                     decoration: InputDecoration(
//                       labelText: 'Comments',
//                       hintText: 'Add any notes...',
//                       border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(10),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(height: 12),
//                   Row(
//                     children: [
//                       Expanded(
//                         child: _ActionBtn.outline(
//                           'Add Exception',
//                               () => _snack('Exception dialog opened'),
//                         ),
//                       ),
//                       Expanded(
//                         child:
//                         _ActionBtn.primary('Save Draft', widget.onSaveDraft),
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Row(
//               children: [
//                 Expanded(
//                   child: _ActionBtn.outline(
//                       'Previous Week', () => _snack('Go to previous week')),
//                 ),
//                 Expanded(
//                   child: _ActionBtn.primary('Submit Week', widget.onSubmitWeek),
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   void _snack(String msg) {
//     ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
//   }
// }
//
// class _TimesheetWeekGrid extends StatelessWidget {
//   const _TimesheetWeekGrid();
//
//   @override
//   Widget build(BuildContext context) {
//     final cells = [
//       _DayCell('Sun', '15', 'OFF', DayState.off),
//       _DayCell('Mon', '16', '8h', DayState.completed),
//       _DayCell('Tue', '17', '8h', DayState.completed),
//       _DayCell('Wed', '18', '8h', DayState.completed),
//       _DayCell('Thu', '19', '8h', DayState.today),
//       _DayCell('Fri', '20', '8h', DayState.pending),
//       _DayCell('Sat', '21', 'OFF', DayState.off),
//     ];
//     return Card(
//       margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
//       child: Padding(
//         padding: const EdgeInsets.all(12),
//         child: Column(
//           children: [
//             GridView.count(
//               crossAxisCount: 7,
//               shrinkWrap: true,
//               physics: const NeverScrollableScrollPhysics(),
//               mainAxisSpacing: 6,
//               crossAxisSpacing: 6,
//               childAspectRatio: 0.75,
//               children: [
//                 for (final c in cells) _DayTile(cell: c),
//               ],
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// enum DayState { today, completed, pending, off }
//
// class _DayCell {
//   final String day;
//   final String date;
//   final String hours;
//   final DayState state;
//   _DayCell(this.day, this.date, this.hours, this.state);
// }
//
// class _DayTile extends StatelessWidget {
//   final _DayCell cell;
//   const _DayTile({required this.cell});
//
//   @override
//   Widget build(BuildContext context) {
//     Color bg;
//     Color fg;
//     switch (cell.state) {
//       case DayState.today:
//         bg = const Color(0xFF667EEA);
//         fg = Colors.white;
//         break;
//       case DayState.completed:
//         bg = const Color(0xFF28A745);
//         fg = Colors.white;
//         break;
//       case DayState.pending:
//         bg = const Color(0xFFFFC107);
//         fg = Colors.black87;
//         break;
//       case DayState.off:
//       default:
//         bg = const Color(0xFFF8F9FA);
//         fg = Colors.black54;
//     }
//
//     return InkWell(
//       borderRadius: BorderRadius.circular(10),
//       onTap: () {
//         ScaffoldMessenger.of(context).showSnackBar(
//           SnackBar(content: Text('${cell.day} ${cell.date} tapped')),
//         );
//       },
//       child: Ink(
//         decoration: BoxDecoration(
//           color: bg,
//           borderRadius: BorderRadius.circular(10),
//         ),
//         child: Center(
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Text(cell.date,
//                   style: TextStyle(
//                       color: fg, fontWeight: FontWeight.w800, fontSize: 16)),
//               const SizedBox(height: 4),
//               Text(cell.hours, style: TextStyle(color: fg, fontSize: 12)),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class _KeyVal extends StatelessWidget {
//   final String k;
//   final String v;
//   const _KeyVal(this.k, this.v, {super.key});
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 4),
//       child: Row(
//         children: [
//           Text('$k: ', style: const TextStyle(fontWeight: FontWeight.w700)),
//           Expanded(child: Text(v)),
//         ],
//       ),
//     );
//   }
// }
//
// class _SchedDayData {
//   final String day; final String date; final String slot; final String line; final bool working;
//   const _SchedDayData(this.day, this.date, this.slot, this.line, this.working);
// }
//
// class _WeekStrip extends StatelessWidget {
//   final List<_SchedDayData> days;
//   const _WeekStrip({required this.days});
//
//   @override
//   Widget build(BuildContext context) {
//     return SizedBox(
//       height: 112, // enough for 3 short text lines
//       child: ListView.separated(
//         scrollDirection: Axis.horizontal,
//         padding: const EdgeInsets.symmetric(horizontal: 8),
//         itemCount: days.length,
//         separatorBuilder: (_, __) => const SizedBox(width: 8),
//         itemBuilder: (_, i) {
//           final d = days[i];
//           final border = d.working ? Colors.green : Colors.black26;
//           final bg = d.working ? const Color(0x1A28A745) : const Color(0xFFF8F9FA);
//           return Container(
//             width: 90,
//             padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
//             decoration: BoxDecoration(
//               border: Border.all(color: border, width: 2),
//               color: bg,
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Text(d.day, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
//                 const SizedBox(height: 4),
//                 Text(d.date, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
//                 const SizedBox(height: 4),
//                 Text(d.slot, maxLines: 1, overflow: TextOverflow.ellipsis,
//                     style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700)),
//                 if (d.line.isNotEmpty)
//                   Text(d.line, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
//               ],
//             ),
//           );
//         },
//       ),
//     );
//   }
// }
//
//
// /// ---------- Screen: Schedule ----------
// class ScheduleScreen extends StatelessWidget {
//   final VoidCallback onPickShift;
//   final VoidCallback onRequestTimeOff;
//   final VoidCallback onCantMake; // NEW
//   const ScheduleScreen(
//       {super.key, required this.onPickShift, required this.onRequestTimeOff,
//   required this.onCantMake, // NEW
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return _GradientScaffold(
//       title: 'My Schedule',
//       trailing: const Icon(Icons.calendar_today_rounded),
//       child: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//       Card(
//       margin: const EdgeInsets.fromLTRB(12, 12, 12, 8),
//       child: Padding(
//         padding: const EdgeInsets.all(16),
//         child: Column(
//           children: [
//             // Header row that never overflows
//             Row(
//               children: [
//                 _OutlineChip('← Prev', onTap: () {}),
//                 const Spacer(),
//                 Flexible(
//                   child: Center(
//                     child: Text('Week 16-22 Sep',
//                         maxLines: 1,
//                         overflow: TextOverflow.ellipsis,
//                         style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
//                   ),
//                 ),
//                 const Spacer(),
//                 _OutlineChip('Next →', onTap: () {}),
//               ],
//             ),
//             const SizedBox(height: 12),
//
//             // NEW: horizontally scrollable week strip
//             _WeekStrip(days: const [
//               _SchedDayData('Mon', '16', '08-16', 'Line A', true),
//               _SchedDayData('Tue', '17', '08-16', 'Line A', true),
//               _SchedDayData('Wed', '18', '08-16', 'Line A', true),
//               _SchedDayData('Thu', '19', '08-16', 'Line A', true),
//               _SchedDayData('Fri', '20', '08-16', 'Line A', true),
//               _SchedDayData('Sat', '21', 'OFF',   '',      false),
//               _SchedDayData('Sun', '22', 'OFF',   '',      false),
//             ]),
//           ],
//         ),
//       ),
//     ),
//           const SectionHeader('Available Shifts', icon: Icons.work_history),
//           ...[
//             _AvailShift(
//               title: 'Sat 21 Sep: 06:00-14:00 (Line B)',
//               rate: '1.5x Rate',
//               badges: const ['✓ Qualified', 'Weekend Shift'],
//               primary: 'Pick Up',
//               onPrimary: onPickShift,
//               secondary: 'Details',
//             ),
//             _AvailShift(
//               title: 'Sun 22 Sep: 14:00-22:00 (Line C)',
//               rate: '2.0x Rate',
//               badges: const ['⚠ Training Needed', 'Night Shift'],
//               primary: 'Request Training',
//               onPrimary: () {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                     const SnackBar(content: Text('Training requested')));
//               },
//               secondary: 'Details',
//             ),
//           ].map((w) => Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: w)),
//           Padding(
//             padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
//             child: Row(
//               children: [
//                 Expanded(child: _ActionBtn.outline('Swap Shifts', () => _snack(context, 'Swap flow'))),
//                 const SizedBox(width: 8),
//                 Expanded(child: _ActionBtn.danger('Can\'t Make It', onCantMake)), // NEW
//                 const SizedBox(width: 8),
//                 Expanded(child: _ActionBtn.primary('Request Time Off', onRequestTimeOff)),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   void _snack(BuildContext c, String s) =>
//       ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(s)));
// }
//
// class _OutlineChip extends StatelessWidget {
//   final String text;
//   final VoidCallback onTap;
//   const _OutlineChip(this.text, {required this.onTap});
//   @override
//   Widget build(BuildContext context) {
//     return OutlinedButton(
//       onPressed: onTap,
//       style: OutlinedButton.styleFrom(
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
//         padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//       ),
//       child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
//     );
//   }
// }
//
// class _SchedDay extends StatelessWidget {
//   final String day;
//   final String date;
//   final String slot;
//   final String line;
//   final bool working;
//   const _SchedDay(this.day, this.date, this.slot, this.line, this.working);
//
//   @override
//   Widget build(BuildContext context) {
//     final border = working ? Colors.green : Colors.black26;
//     final bg = working ? const Color(0x1A28A745) : const Color(0xFFF8F9FA);
//     return Container(
//       padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
//       decoration: BoxDecoration(
//         border: Border.all(color: border, width: 2),
//         color: bg,
//         borderRadius: BorderRadius.circular(12),
//       ),
//       child: Column(
//         children: [
//           Text(day,
//               style:
//               const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
//           const SizedBox(height: 6),
//           Text(date,
//               style:
//               const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
//           const SizedBox(height: 6),
//           Text(slot,
//               style: TextStyle(
//                   fontSize: 12,
//                   color: Theme.of(context).colorScheme.primary,
//                   fontWeight: FontWeight.w700)),
//           if (line.isNotEmpty)
//             Text(line, style: const TextStyle(fontSize: 12)),
//         ],
//       ),
//     );
//   }
// }
//
// class _AvailShift extends StatelessWidget {
//   final String title;
//   final String rate;
//   final List<String> badges;
//   final String primary;
//   final VoidCallback onPrimary;
//   final String? secondary;
//
//   const _AvailShift({
//     required this.title,
//     required this.rate,
//     required this.badges,
//     required this.primary,
//     required this.onPrimary,
//     this.secondary,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Card(
//       child: Padding(
//         padding:
//         const EdgeInsets.only(left: 16, right: 16, top: 14, bottom: 14),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             Row(children: [
//               Expanded(
//                 child: Text(title,
//                     style: const TextStyle(
//                         fontWeight: FontWeight.w800, fontSize: 14)),
//               ),
//               Pill(rate, bg: Colors.green, fg: Colors.white),
//             ]),
//             const SizedBox(height: 8),
//             Wrap(
//               spacing: 6,
//               runSpacing: -6,
//               children: badges
//                   .map((b) => Chip(
//                 label: Text(b),
//                 visualDensity: VisualDensity.compact,
//                 side:
//                 const BorderSide(color: Color(0xFFE9ECEF), width: 2),
//               ))
//                   .toList(),
//             ),
//             const SizedBox(height: 8),
//             Row(
//               children: [
//                 if (secondary != null)
//                   Expanded(
//                       child:
//                       _ActionBtn.outline(secondary!, () => _snack(context))),
//                 Expanded(child: _ActionBtn.primary(primary, onPrimary)),
//               ],
//             )
//           ],
//         ),
//       ),
//     );
//   }
//
//   void _snack(BuildContext c) => ScaffoldMessenger.of(c)
//       .showSnackBar(const SnackBar(content: Text('Details opened')));
// }
//
// /// ---------- Screen: Leave ----------
// class LeaveScreen extends StatefulWidget {
//   final VoidCallback onSaveDraft;
//   final VoidCallback onSubmit;
//   const LeaveScreen({super.key, required this.onSaveDraft, required this.onSubmit});
//
//   @override
//   State<LeaveScreen> createState() => _LeaveScreenState();
// }
//
// class _LeaveScreenState extends State<LeaveScreen> {
//   String _leaveType = 'Casual Leave (12 days remaining)';
//   DateTime _from = DateTime(2024, 9, 25);
//   DateTime _to = DateTime(2024, 9, 26);
//   bool _halfDay = false;
//   bool _includeWeekends = true;
//   final TextEditingController _reason = TextEditingController();
//
//   Future<void> _pickDate(bool isFrom) async {
//     final initial = isFrom ? _from : _to;
//     final res = await showDatePicker(
//       context: context,
//       initialDate: initial,
//       firstDate: DateTime(2023),
//       lastDate: DateTime(2030),
//     );
//     if (res != null) {
//       setState(() {
//         if (isFrom) {
//           _from = res;
//           if (_to.isBefore(_from)) _to = _from;
//         } else {
//           _to = res.isBefore(_from) ? _from : res;
//         }
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return _GradientScaffold(
//       title: 'Apply for Leave',
//       trailing: const Icon(Icons.beach_access_rounded),
//       child: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//           const SectionHeader('Leave Balance', icon: Icons.account_balance_wallet),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Row(
//               children: const [
//                 Expanded(child: _StatCard(value: '12', label: 'Casual')),
//                 Expanded(child: _StatCard(value: '8', label: 'Sick')),
//                 Expanded(child: _StatCard(value: '15', label: 'Earned')),
//               ],
//             ),
//           ),
//           Card(
//             margin: const EdgeInsets.fromLTRB(12, 8, 12, 0),
//             child: Padding(
//               padding: const EdgeInsets.all(16),
//               child: Column(children: [
//                 DropdownButtonFormField<String>(
//                   value: _leaveType,
//                   items: const [
//                     DropdownMenuItem(
//                         value: 'Casual Leave (12 days remaining)',
//                         child: Text('Casual Leave (12 days remaining)')),
//                     DropdownMenuItem(
//                         value: 'Sick Leave (8 days remaining)',
//                         child: Text('Sick Leave (8 days remaining)')),
//                     DropdownMenuItem(
//                         value: 'Earned Leave (15 days remaining)',
//                         child: Text('Earned Leave (15 days remaining)')),
//                   ],
//                   onChanged: (v) => setState(() => _leaveType = v!),
//                   decoration: _inputDeco('Leave Type'),
//                 ),
//                 const SizedBox(height: 12),
//                 Row(
//                   children: [
//                     Expanded(
//                       child: _DateField(
//                         label: 'From Date',
//                         date: _from,
//                         onTap: () => _pickDate(true),
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     Expanded(
//                       child: _DateField(
//                         label: 'To Date',
//                         date: _to,
//                         onTap: () => _pickDate(false),
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(height: 8),
//                 SwitchListTile(
//                   value: _halfDay,
//                   onChanged: (v) => setState(() => _halfDay = v),
//                   title: const Text('Half day (AM/PM)'),
//                 ),
//                 SwitchListTile(
//                   value: _includeWeekends,
//                   onChanged: (v) => setState(() => _includeWeekends = v),
//                   title: const Text('Include weekends/holidays'),
//                 ),
//                 const SizedBox(height: 8),
//                 TextField(
//                   controller: _reason,
//                   maxLines: 3,
//                   decoration:
//                   _inputDeco('Reason', hint: 'Please provide reason for leave...'),
//                 ),
//                 const SizedBox(height: 12),
//                 _InfoBanner(
//                   icon: Icons.warning_amber_rounded,
//                   title: 'Team Impact',
//                   text: '2 other team members are on leave the same day',
//                   color: const Color(0xFFFFF3CD),
//                   fg: const Color(0xFF856404),
//                 ),
//                 const SizedBox(height: 8),
//                 _InfoBanner(
//                   icon: Icons.route_rounded,
//                   title: 'Approval Route',
//                   text: 'You → Supervisor → HR → Auto-approve',
//                 ),
//                 const SizedBox(height: 8),
//                 Row(
//                   children: [
//                     Expanded(
//                         child:
//                         _ActionBtn.outline('Save Draft', widget.onSaveDraft)),
//                     Expanded(
//                         child: _ActionBtn.primary('Submit', widget.onSubmit)),
//                   ],
//                 )
//               ]),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   InputDecoration _inputDeco(String label, {String? hint}) => InputDecoration(
//     labelText: label,
//     hintText: hint,
//     border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
//   );
// }
//
// class _DateField extends StatelessWidget {
//   final String label;
//   final DateTime date;
//   final VoidCallback onTap;
//   const _DateField({required this.label, required this.date, required this.onTap});
//   @override
//   Widget build(BuildContext context) {
//     final txt = '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
//     return InkWell(
//       onTap: onTap,
//       borderRadius: BorderRadius.circular(10),
//       child: InputDecorator(
//         decoration: InputDecoration(
//           labelText: label,
//           border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
//         ),
//         child: Text(txt),
//       ),
//     );
//   }
// }
//
// class _InfoBanner extends StatelessWidget {
//   final IconData icon;
//   final String title;
//   final String text;
//   final Color color;
//   final Color fg;
//   const _InfoBanner({
//     required this.icon,
//     required this.title,
//     required this.text,
//     this.color = const Color(0xFFF8F9FA),
//     this.fg = const Color(0xFF333333),
//   });
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(14),
//       decoration:
//       BoxDecoration(color: color, borderRadius: BorderRadius.circular(10)),
//       child: Row(
//         children: [
//           Icon(icon, color: fg),
//           const SizedBox(width: 10),
//           Expanded(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Text(title,
//                     style:
//                     TextStyle(color: fg, fontWeight: FontWeight.w700)),
//                 const SizedBox(height: 4),
//                 Text(text, style: TextStyle(color: fg.withOpacity(0.9))),
//               ],
//             ),
//           )
//         ],
//       ),
//     );
//   }
// }
//
// /// ---------- Screen: Inbox ----------
// class InboxScreen extends StatelessWidget {
//   final VoidCallback onClockIn;
//   final VoidCallback onMarkAllRead;
//   final VoidCallback onSettings;
//   // In InboxScreen constructor:
//   final VoidCallback onCantMake; // NEW
//   const InboxScreen({
//     super.key,
//     required this.onClockIn,
//     required this.onMarkAllRead,
//     required this.onSettings,
//     required this.onCantMake,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return _GradientScaffold(
//       title: 'Inbox',
//       trailing: Stack(
//         clipBehavior: Clip.none,
//         children: const [
//           Icon(Icons.inbox_rounded, color: Colors.white),
//         ],
//       ),
//       child: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//           Card(
//             margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
//             child: Column(
//               children: [
//                 _InboxRow(
//                   colorBg: const Color(0xFFFFE6E6),
//                   colorFg: const Color(0xFFDC3545),
//                   icon: Icons.circle,
//                   title: 'URGENT - Shift starts in 15 min',
//                   text: 'Thu 19 Sep, 08:00-16:00 Line A',
//                   actions: [
//                     _SmallBtn.primary('Clock In', onClockIn),
//                     _SmallBtn.outline('Running Late', () {}),
//                     // _SmallBtn.danger('Can\'t Make', () {}),
//                     // In InboxScreen build:
//                     _SmallBtn.danger('Can\'t Make', onCantMake),
//                   ],
//                 ),
//                 const Divider(height: 1),
//                 _InboxRow(
//                   colorBg: const Color(0xFFE6F7E6),
//                   colorFg: const Color(0xFF28A745),
//                   icon: Icons.circle,
//                   title: 'Leave Approved - 25-26 Sep',
//                   text: 'Casual Leave approved by Manager',
//                   actions: [
//                     _SmallBtn.outline('View Details', () {}),
//                     _SmallBtn.primary('Add to Calendar', () {}),
//                   ],
//                 ),
//                 const Divider(height: 1),
//                 _InboxRow(
//                   colorBg: const Color(0xFFE6F3FF),
//                   colorFg: const Color(0xFF007BFF),
//                   icon: Icons.circle,
//                   title: 'Shift Swap Request from Priya',
//                   text: 'Wants to swap Fri 20 Sep for Mon 23',
//                   actions: [
//                     _SmallBtn.primary('Accept', () {}),
//                     _SmallBtn.outline('Decline', () {}),
//                     _SmallBtn.outline('Counter-offer', () {}),
//                   ],
//                 ),
//                 const Divider(height: 1),
//                 _InboxRow(
//                   colorBg: const Color(0xFFE6F3FF),
//                   colorFg: const Color(0xFF007BFF),
//                   icon: Icons.circle,
//                   title: 'New Training Available',
//                   text: 'Line C Cross-training - Earn 2.0x rate',
//                   actions: [
//                     _SmallBtn.primary('Enroll', () {}),
//                     _SmallBtn.outline('Learn More', () {}),
//                     _SmallBtn.outline('Remind Later', () {}),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
//             child: Row(
//               children: [
//                 Expanded(child: _ActionBtn.outline('Mark All Read', onMarkAllRead)),
//                 Expanded(child: _ActionBtn.outline('Filter', () {})),
//                 Expanded(child: _ActionBtn.primary('Settings', onSettings)),
//               ],
//             ),
//           )
//         ],
//       ),
//     );
//   }
// }
//
// class _InboxRow extends StatelessWidget {
//   final Color colorBg;
//   final Color colorFg;
//   final IconData icon;
//   final String title;
//   final String text;
//   final List<Widget> actions;
//
//   const _InboxRow({
//     required this.colorBg,
//     required this.colorFg,
//     required this.icon,
//     required this.title,
//     required this.text,
//     required this.actions,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//         padding:
//         const EdgeInsets.only(left: 12, right: 12, top: 10, bottom: 10),
//         child: Row(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             CircleAvatar(backgroundColor: colorBg, child: Icon(icon, color: colorFg, size: 18)),
//             const SizedBox(width: 12),
//             Expanded(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
//                   const SizedBox(height: 2),
//                   Text(text, style: const TextStyle(color: Colors.black54)),
//                   const SizedBox(height: 8),
//                   Wrap(spacing: 8, runSpacing: 8, children: actions),
//                 ],
//               ),
//             ),
//           ],
//         ));
//   }
// }
//
// // Replace the entire _SmallBtn class with this version.
// enum _SmallBtnKind { primary, outline, danger }
//
// class _SmallBtn extends StatelessWidget {
//   final String text;
//   final VoidCallback onTap;
//   final _SmallBtnKind kind;
//
//   const _SmallBtn._(this.text, this.onTap, this.kind);
//
//   factory _SmallBtn.primary(String text, VoidCallback onTap) =>
//       _SmallBtn._(text, onTap, _SmallBtnKind.primary);
//
//   factory _SmallBtn.outline(String text, VoidCallback onTap) =>
//       _SmallBtn._(text, onTap, _SmallBtnKind.outline);
//
//   factory _SmallBtn.danger(String text, VoidCallback onTap) =>
//       _SmallBtn._(text, onTap, _SmallBtnKind.danger);
//
//   @override
//   Widget build(BuildContext context) {
//     final child = Text(
//       text,
//       style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
//     );
//
//     switch (kind) {
//       case _SmallBtnKind.primary:
//         return ElevatedButton(
//           onPressed: onTap,
//           style: ElevatedButton.styleFrom(
//             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//           ),
//           child: child,
//         );
//       case _SmallBtnKind.outline:
//         return OutlinedButton(
//           onPressed: onTap,
//           style: OutlinedButton.styleFrom(
//             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//           ),
//           child: child,
//         );
//       case _SmallBtnKind.danger:
//         return ElevatedButton(
//           onPressed: onTap,
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.redAccent,
//             foregroundColor: Colors.white,
//             padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//             shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
//           ),
//           child: child,
//         );
//     }
//   }
// }
//
//
// /// ---------- Route Screen: Can't Make It / Replacement ----------
// class ReplacementScreen extends StatefulWidget {
//   final VoidCallback onSubmit;
//   const ReplacementScreen({super.key, required this.onSubmit});
//   @override
//   State<ReplacementScreen> createState() => _ReplacementScreenState();
// }
//
// class _ReplacementScreenState extends State<ReplacementScreen> {
//   String _reason = 'Sick';
//   bool _notify = true;
//   bool _autoReplace = true;
//   bool _offerSwap = false;
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Can't Make Your Shift?")),
//       body: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//           _ShiftCard(
//             timeRange: 'Thu 19 Sep, 08:00-16:00',
//             status: 'Line A',
//             statusColor: Colors.deepPurple,
//             details: const [],
//             actions: const [],
//           ),
//           Card(
//             margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
//             child: Padding(
//               padding: const EdgeInsets.all(16),
//               child: Column(children: [
//                 DropdownButtonFormField<String>(
//                   value: _reason,
//                   items: const [
//                     DropdownMenuItem(value: 'Sick', child: Text('Sick')),
//                     DropdownMenuItem(value: 'Travel', child: Text('Travel')),
//                     DropdownMenuItem(value: 'Personal', child: Text('Personal')),
//                     DropdownMenuItem(value: 'Other', child: Text('Other')),
//                   ],
//                   onChanged: (v) => setState(() => _reason = v!),
//                   decoration: InputDecoration(
//                     labelText: 'Reason',
//                     border: OutlineInputBorder(
//                         borderRadius: BorderRadius.circular(10)),
//                   ),
//                 ),
//                 SwitchListTile(
//                   title: const Text('Notify manager immediately'),
//                   value: _notify,
//                   onChanged: (v) => setState(() => _notify = v),
//                 ),
//                 SwitchListTile(
//                   title: const Text('Find replacement automatically'),
//                   value: _autoReplace,
//                   onChanged: (v) => setState(() => _autoReplace = v),
//                 ),
//                 SwitchListTile(
//                   title: const Text('Offer to swap with future shift'),
//                   value: _offerSwap,
//                   onChanged: (v) => setState(() => _offerSwap = v),
//                 ),
//               ]),
//             ),
//           ),
//           Card(
//             margin: const EdgeInsets.fromLTRB(12, 0, 12, 8),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: const [
//                 Padding(
//                   padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
//                   child: Text('Replacement Ranking Preview',
//                       style:
//                       TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
//                 ),
//                 _ReplaceTile('Priya S.', 'Available, same line experience',
//                     score: '95%', color: Colors.green),
//                 Divider(height: 1),
//                 _ReplaceTile('Raj K.', 'Available, overtime eligible',
//                     score: '87%', color: Colors.amber),
//                 Divider(height: 1),
//                 _ReplaceTile('Amit P.', 'Cross-trained, good performance',
//                     score: '82%', color: Colors.grey),
//                 SizedBox(height: 8),
//               ],
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Column(
//               children: [
//                 _InfoBanner(
//                   icon: Icons.smart_toy_rounded,
//                   title: 'Replacement Engine',
//                   text:
//                   'Factors: Skill match, availability, overtime rules, fairness rotation, location proximity, past performance',
//                 ),
//                 const SizedBox(height: 8),
//                 Row(
//                   children: [
//                     Expanded(
//                         child: _ActionBtn.outline('Cancel', () {
//                           Navigator.of(context).pop();
//                         })),
//                     Expanded(
//                         child: _ActionBtn.primary('Submit Request', () {
//                           widget.onSubmit();
//                           Navigator.of(context).pop();
//                         })),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
//
// class _ReplaceTile extends StatelessWidget {
//   final String name;
//   final String details;
//   final String score;
//   final Color color;
//   const _ReplaceTile(this.name, this.details,
//       {required this.score, required this.color});
//
//   @override
//   Widget build(BuildContext context) {
//     return ListTile(
//       title: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
//       subtitle: Text(details),
//       trailing: Pill(score, bg: color, fg: color.computeLuminance() > 0.5 ? Colors.black : Colors.white),
//     );
//   }
// }
//
// /// ---------- Route Screen: Shift Pickup (with Offline banner) ----------
// class PickupScreen extends StatelessWidget {
//   final VoidCallback onPick;
//   const PickupScreen({super.key, required this.onPick});
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text('Available Shifts')),
//       body: ListView(
//         padding: const EdgeInsets.only(bottom: 24),
//         children: [
//           Container(
//             padding: const EdgeInsets.all(12),
//             color: const Color(0xFFFFC107),
//             child: const Text(
//               '📱 OFFLINE MODE - Last sync: 2 min ago | ⚡ 3 actions queued',
//               style: TextStyle(fontWeight: FontWeight.w700),
//             ),
//           ),
//           const SizedBox(height: 8),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Row(
//               children: const [
//                 Expanded(child: _StatCard(value: '5', label: 'Available')),
//                 Expanded(child: _StatCard(value: '3', label: 'Qualified')),
//                 Expanded(child: _StatCard(value: '2.0x', label: 'Max Rate')),
//               ],
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 12),
//             child: Column(children: [
//               _AvailShift(
//                 title: 'Today 14:00-22:00 (Line B)',
//                 rate: '1.5x Rate',
//                 badges: const ['✓ Qualified', 'Urgent', '4km away'],
//                 primary: 'Pick Up Now',
//                 onPrimary: onPick,
//                 secondary: 'Details',
//               ),
//               _AvailShift(
//                 title: 'Sat 21 Sep: 06:00-14:00 (Line B)',
//                 rate: '1.5x Rate',
//                 badges: const ['✓ Qualified', 'Weekend', '2km away'],
//                 primary: 'Pick Up',
//                 onPrimary: onPick,
//                 secondary: 'Details',
//               ),
//               _AvailShift(
//                 title: 'Sun 22 Sep: 14:00-22:00 (Line C)',
//                 rate: '2.0x Rate',
//                 badges: const ['⚠ Training Needed', 'Night Premium', '8km away'],
//                 primary: 'Request Training',
//                 onPrimary: () {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                       const SnackBar(content: Text('Training requested')));
//                 },
//                 secondary: 'Details',
//               ),
//               _AvailShift(
//                 title: 'Mon 23 Sep: 22:00-06:00 (Line A)',
//                 rate: '1.8x Rate',
//                 badges: const ['✓ Qualified', 'Night Shift', 'Home line'],
//                 primary: 'Pick Up',
//                 onPrimary: onPick,
//                 secondary: 'Details',
//               ),
//               const SizedBox(height: 8),
//               Row(
//                 children: [
//                   Expanded(
//                       child: _ActionBtn.outline(
//                           'Filter Shifts',
//                               () => ScaffoldMessenger.of(context).showSnackBar(
//                               const SnackBar(
//                                   content: Text('Filter coming soon'))))),
//                   Expanded(
//                       child: _ActionBtn.primary(
//                           'Set Preferences',
//                               () => ScaffoldMessenger.of(context).showSnackBar(
//                               const SnackBar(
//                                   content: Text('Preferences saved'))))),
//                 ],
//               ),
//             ]),
//           ),
//         ],
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:kiosk/app/core/config/environment.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:kiosk/app/core/services/storage_service.dart';
import 'package:kiosk/app/core/services/sync_service.dart';
import 'package:kiosk/app/presentation/screens/home_screen.dart';
import 'package:kiosk/app/presentation/screens/login_screen.dart';
import 'package:kiosk/app/presentation/screens/welcome_screen.dart';

void main() async {
  // Ensure all plugins are initialized before running the app
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize services
  await DatabaseService.instance.database;
  SyncService(); // Initializes the singleton instance and its listeners

  // Initialize environment configuration
  const environment =
  String.fromEnvironment('FLAVOR', defaultValue: Environment.dev);
  Environment().init(environment);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kiosk',
      debugShowCheckedModeBanner: false, // Hides the debug banner
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        textTheme: GoogleFonts.poppinsTextTheme(
          Theme.of(context).textTheme,
        ),
        useMaterial3: true,
      ),
      // Use the AuthWrapper to determine the starting screen
      home: const AuthWrapper(),
    );
  }
}

/// A widget that determines the initial screen to display based on
/// the user's authentication and setup status.
class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  final StorageService _storageService = StorageService();

  /// Checks storage and determines the correct starting screen.
  Future<Widget> _getInitialScreen() async {
    // Check if a refresh token exists. This means the user is logged in.
    final refreshToken = await _storageService.getRefreshToken();
    if (refreshToken != null) {
      return const HomeScreen();
    }

    // If no token, check if a tenant ID exists. This means they need to log in.
    final tenantId = await _storageService.getTenantId();
    if (tenantId != null) {
      return const LoginScreen();
    }

    // If neither exists, it's the first time opening the app.
    return const WelcomeScreen();
  }

  @override
  Widget build(BuildContext context) {
    // FutureBuilder handles the asynchronous check and UI updates.
    return FutureBuilder<Widget>(
      future: _getInitialScreen(),
      builder: (context, snapshot) {
        // While waiting for the checks to complete, show a loading indicator.
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        // If the checks are done, show the screen that was determined.
        if (snapshot.hasData) {
          return snapshot.data!;
        }

        // If something went wrong, default to the WelcomeScreen.
        return const WelcomeScreen();
      },
    );
  }
}