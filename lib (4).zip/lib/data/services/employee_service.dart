// import 'http_client.dart';
// import 'auth_service.dart';
// import 'routes.dart';
//
// class EmployeeService {
//   EmployeeService._();
//   static final EmployeeService instance = EmployeeService._();
//
//   String _requireEmployeeId() {
//     final id = AuthService.instance.employeeId ?? SessionController.instance.employeeId;
//     if (id == null || id.isEmpty) {
//       throw StateError('Not signed in: employeeId not available.');
//     }
//     return id;
//   }
//
//   Future<Map<String, dynamic>> getMe() async {
//     final id = _requireEmployeeId();
//     return await ApiClient.instance.getJson(Routes.employeeById(id));
//   }
//
//   Future<Map<String, dynamic>> getEmployeeByEmail(String email) async {
//     // This call uses the token set temporarily during the login flow.
//     return await ApiClient.instance.getJson(Routes.employeeByEmail(email));
//   }
// }

// --- 👇 ADD THESE IMPORTS AT THE TOP ---
import 'package:maplibre_gl/maplibre_gl.dart'; // For LatLng
import 'package:flutter/foundation.dart';
import '../models/reportee_model.dart';
import 'http_client.dart';
import 'auth_service.dart';
import 'routes.dart';
import '../models/employee_profile_model.dart';
import 'package:intl/intl.dart'; // 🎯 ADD THIS IMPORT
import 'dart:convert';

// --- 👇 ADD THIS DTO CLASS ---
// This class will hold the full response from the new API

class SessionPathResponse {
  final int sessionId;
  final String employeeId;
  final List<LatLng> path;
  final String startedAt;
  final String? endedAt;

  SessionPathResponse({
    required this.sessionId,
    required this.employeeId,
    required this.path,
    required this.startedAt,
    required this.endedAt,
  });

  factory SessionPathResponse.fromJson(Map<String, dynamic> json) {
    final parsedPath = _parseBestAvailablePath(json);

    return SessionPathResponse(
      sessionId: _toInt(json['sessionId']) ?? 0,
      employeeId: (json['employeeId'] ?? '').toString(),
      path: parsedPath,
      startedAt: (json['startedAt'] ?? '').toString(),
      endedAt: json['endedAt']?.toString(),
    );
  }

  static List<LatLng> _parseBestAvailablePath(Map<String, dynamic> json) {
    // 1. Prefer dense matched chunk geometry if present
    final chunkPath = _parseChunks(json['chunks']) ??
        _parseChunks(json['pathChunks']) ??
        _parseChunks(json['matchedChunks']);

    if (chunkPath != null && chunkPath.length >= 2) {
      return chunkPath;
    }

    // 2. Then try route-level matched geometry
    final matchedGeometryPath = _parseGeometryObject(
      json['matchedGeometry'],
    ) ??
        _parseGeometryObject(json['routeGeometry']) ??
        _parseGeometryObject(json['geometry']) ??
        _parseGeometryObject(json['geoJson']);

    if (matchedGeometryPath != null && matchedGeometryPath.length >= 2) {
      return matchedGeometryPath;
    }

    // 3. Fallback to old simple path array
    return _parsePath(json['path']);
  }

  static List<LatLng>? _parseChunks(Object? rawChunks) {
    if (rawChunks is! List || rawChunks.isEmpty) return null;

    final result = <LatLng>[];

    for (final chunk in rawChunks) {
      if (chunk is! Map<String, dynamic>) continue;

      final geometry = _parseGeometryObject(chunk['matchedGeometry']) ??
          _parseGeometryObject(chunk['geometry']) ??
          _parseGeometryObject(chunk['routeGeometry']) ??
          _parsePath(chunk['path']);

      if (geometry != null && geometry.isNotEmpty) {
        if (result.isEmpty) {
          result.addAll(geometry);
        } else {
          final first = geometry.first;
          final last = result.last;

          if ((last.latitude - first.latitude).abs() < 0.000001 &&
              (last.longitude - first.longitude).abs() < 0.000001) {
            result.addAll(geometry.skip(1));
          } else {
            result.addAll(geometry);
          }
        }
      }
    }

    return result.isEmpty ? null : result;
  }

  static List<LatLng>? _parseGeometryObject(Object? rawGeometry) {
    if (rawGeometry == null) return null;

    if (rawGeometry is String) {
      try {
        final decoded = jsonDecode(rawGeometry);
        return _parseGeometryObject(decoded);
      } catch (_) {
        return null;
      }
    }

    if (rawGeometry is! Map<String, dynamic>) return null;

    final type = rawGeometry['type']?.toString();
    final coordinates = rawGeometry['coordinates'];

    if (type == 'LineString' && coordinates is List) {
      final points = <LatLng>[];

      for (final item in coordinates) {
        if (item is List && item.length >= 2) {
          final lng = _toDouble(item[0]);
          final lat = _toDouble(item[1]);

          if (lat != null && lng != null) {
            points.add(LatLng(lat, lng));
          }
        }
      }

      return points.isEmpty ? null : points;
    }

    return null;
  }

  static List<LatLng> _parsePath(Object? rawPath) {
    if (rawPath == null) return const [];

    if (rawPath is List) {
      return rawPath
          .map((item) => _parseCoordinate(item))
          .whereType<LatLng>()
          .toList(growable: false);
    }

    if (rawPath is String) {
      try {
        final decoded = jsonDecode(rawPath);
        if (decoded is List) {
          return decoded
              .map((item) => _parseCoordinate(item))
              .whereType<LatLng>()
              .toList(growable: false);
        }
      } catch (_) {
        return const [];
      }
    }

    return const [];
  }

  static LatLng? _parseCoordinate(Object? raw) {
    if (raw is! Map) return null;

    final lat = _toDouble(raw['latitude'] ?? raw['lat'] ?? raw['y']);
    final lng = _toDouble(raw['longitude'] ?? raw['lng'] ?? raw['lon'] ?? raw['x']);

    if (lat == null || lng == null) return null;
    return LatLng(lat, lng);
  }

  static int? _toInt(Object? value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString());
  }

  static double? _toDouble(Object? value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }
}
class EmployeeService {
  EmployeeService._();
  static final EmployeeService instance = EmployeeService._();

  // String _requireEmail() {
  //   final e = AuthService.instance.email ?? SessionController.instance.email;
  //   if (e == null || e.isEmpty) {
  //     throw StateError('Not signed in: email not available.');
  //   }
  //   return e;
  // }

  String _requireEmployeeId() {
    final id = AuthService.instance.employeeId ?? SessionController.instance.employeeId;
    if (id == null || id.isEmpty) {
      throw StateError('employeeId not available.');
    }
    return id;
  }
  Future<EmployeeProfile> getProfileById() async {
    final id = _requireEmployeeId();
    final json = await ApiClient.instance.getJson(Routes.employeeById(id));
    return EmployeeProfile.fromJson(json);
  }

  /// Use EMAIL as the source of truth (because backend doesn't return employeeId at login).
  Future<Map<String, dynamic>> getMe() async {
    final id = _requireEmployeeId();
    return await ApiClient.instance.getJson(Routes.employeeById(id));
  }

  /// If you already have an ID somewhere, this still works.
  Future<Map<String, dynamic>> getById(String employeeId) async {
    return await ApiClient.instance.getJson(Routes.employeeById(employeeId));
  }

  /// Explicit lookup by email.
  Future<Map<String, dynamic>> getEmployeeByEmail(String email) async {
    return await ApiClient.instance.getJson(Routes.employeeByEmail(email));
  }

  /// Optional helper: fill AuthService.employeeId lazily if missing.
  Future<void> ensureEmployeeIdCached() async {
    if ((AuthService.instance.employeeId ?? '').isNotEmpty) return;
    final ej = await getMe();
    final eid = (ej['employeeId'] as String?) ?? (ej['id'] as String?);
    final name = (ej['employeeName'] as String?) ?? (ej['fullName'] as String?) ?? (ej['name'] as String?);
    if (eid != null && eid.isNotEmpty) {
      AuthService.instance.updateProfile(employeeId: eid, employeeName: name);
    }
  }
  /// Fetches the list of reportees for the currently logged-in user.
  Future<List<ReporteeModel>> getReportees() async {
    try {
      // We use getList because the API returns a JSON array (a List)
      final dynamic dataList = await ApiClient.instance.getList(Routes.getReportees);

      if (dataList is List) {
        return dataList
            .map((json) => ReporteeModel.fromJson(json as Map<String, dynamic>))
            .toList();
      }
      return []; // Return empty list if response is not a list
    } catch (e) {
      debugPrint('Failed to get reportees: $e');
      return []; // Return empty list on any error
    }
  }
// --- 👇 ADD THIS NEW METHOD ---

  /// Fetches the latest path for a specific reportee.
  Future<SessionPathResponse> getLatestReporteePath(String employeeId) async {
    try {
      final responseJson = await ApiClient.instance.getJson(
        Routes.getLatestReporteePath(employeeId),
      );
      return SessionPathResponse.fromJson(responseJson);
    } catch (e) {
      debugPrint('Failed to get reportee path: $e');
      // Re-throw to be handled by the FutureBuilder
      throw Exception('Failed to load path: $e');
    }
  }

  // 🎯 ADD THIS NEW METHOD
  /// Fetches the path for a specific reportee on a specific date.
  Future<SessionPathResponse> getReporteePathForDate(String employeeId, DateTime date) async {
    // 🎯 FIX: Define ymd outside the try-block to make it accessible in the catch-block
    final String ymd = DateFormat('yyyy-MM-dd').format(date);

    try {
      final responseJson = await ApiClient.instance.getJson(
        Routes.getReporteePathForDate(employeeId, ymd),
      );
      return SessionPathResponse.fromJson(responseJson);
    } catch (e) {
      debugPrint('Failed to get reportee path for date $ymd: $e');
      // Now 'ymd' is accessible here
      throw Exception('Failed to load path for $ymd: $e');
    }
  }

}
