// lib/app/core/diagnostics/gallery_audit.dart
import 'dart:convert';
import 'dart:io' as io;
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:kiosk/app/core/services/database_service.dart';
import 'package:path_provider/path_provider.dart';

class AuditResult {
  final int employees;
  final int templates;
  final double maxIntra;
  final double minInter;
  final String? minInterA;
  final String? minInterB;
  final String? csvPath;
  const AuditResult({
    required this.employees,
    required this.templates,
    required this.maxIntra,
    required this.minInter,
    this.minInterA,
    this.minInterB,
    this.csvPath,
  });
}

class GalleryAudit {
  /// Computes:
  /// - max intra-person distance (should be low)
  /// - min inter-person distance (should be high)
  /// If [saveCsv] true, saves pairwise summary to Documents as gallery_pairs.csv
  static Future<AuditResult> run({bool saveCsv = false, int maxEmployees = 1000}) async {
    final rows = await DatabaseService.instance.getAllEmployeeProfiles();
    final embs = <String, List<List<double>>>{};
    int totalTemplates = 0;

    for (final r in rows.take(maxEmployees)) {
      final id = r['employee_id'] as String?;
      final raw = r['image_data'] as String?;
      if (id == null || raw == null || raw.isEmpty) continue;

      try {
        final parsed = jsonDecode(raw);
        final vecs = <List<double>>[];

        if (parsed is List && parsed.isNotEmpty) {
          if (parsed.first is Map) {
            for (final m in parsed) {
              if (m is! Map) continue;
              final v = _asNumList(m['emb']);
              if (v != null) vecs.add(_l2(v));
            }
          } else if (parsed.first is List) {
            for (final v in parsed) {
              final a = _asNumList(v); if (a != null) vecs.add(_l2(a));
            }
          } else {
            final a = _asNumList(parsed); if (a != null) vecs.add(_l2(a));
          }
        }
        if (vecs.isNotEmpty) {
          embs[id] = vecs;
          totalTemplates += vecs.length;
        }
      } catch (_) { /* skip */ }
    }

    double maxIntra = 0.0;
    for (final vecs in embs.values) {
      for (int i = 0; i < vecs.length; i++) {
        for (int j = i + 1; j < vecs.length; j++) {
          final d = _dist(vecs[i], vecs[j]);
          if (d > maxIntra) maxIntra = d;
        }
      }
    }

    double minInter = double.infinity;
    String? aId, bId;
    final ids = embs.keys.toList();
    for (int i = 0; i < ids.length; i++) {
      for (int j = i + 1; j < ids.length; j++) {
        for (final a in embs[ids[i]]!) {
          for (final b in embs[ids[j]]!) {
            final d = _dist(a, b);
            if (d < minInter) { minInter = d; aId = ids[i]; bId = ids[j]; }
          }
        }
      }
    }

    String? csvPath;
    if (saveCsv) {
      final dir = await getApplicationDocumentsDirectory();
      final f = io.File('${dir.path}/gallery_pairs.csv');
      final sink = f.openWrite();
      sink.writeln('type,id_a,id_b,distance');
      // Intra
      for (final id in ids) {
        final vecs = embs[id]!;
        for (int i = 0; i < vecs.length; i++) {
          for (int j = i + 1; j < vecs.length; j++) {
            sink.writeln('intra,$id,$id,${_dist(vecs[i], vecs[j]).toStringAsFixed(6)}');
          }
        }
      }
      // Inter
      for (int i = 0; i < ids.length; i++) {
        for (int j = i + 1; j < ids.length; j++) {
          for (final a in embs[ids[i]]!) {
            for (final b in embs[ids[j]]!) {
              sink.writeln('inter,${ids[i]},${ids[j]},${_dist(a, b).toStringAsFixed(6)}');
            }
          }
        }
      }
      await sink.close();
      csvPath = f.path;
      debugPrint('Audit CSV saved to $csvPath');
    }

    debugPrint('AUDIT: employees=${embs.length}, templates=$totalTemplates, '
        'maxIntra=${maxIntra.toStringAsFixed(3)}, '
        'minInter=${minInter.isFinite ? minInter.toStringAsFixed(3) : 'INF'} '
        '${aId!=null ? '(closest: $aId vs $bId)' : ''}');
    return AuditResult(
      employees: embs.length,
      templates: totalTemplates,
      maxIntra: maxIntra,
      minInter: minInter.isFinite ? minInter : 9999,
      minInterA: aId,
      minInterB: bId,
      csvPath: csvPath,
    );
  }

  // ---- helpers ----
  static List<double>? _asNumList(dynamic v) {
    if (v is! List) return null;
    try { return v.map((e) => (e as num).toDouble()).toList(growable: false); }
    catch (_) { return null; }
  }
  static List<double> _l2(List<double> vec) {
    double s = 0; for (final x in vec) s += x*x;
    if (s <= 0) return vec;
    final n = sqrt(s);
    return List<double>.generate(vec.length, (i) => vec[i]/n, growable: false);
  }
  static double _dist(List<double> a, List<double> b) {
    double s = 0; for (int i=0;i<a.length;i++){ final d=a[i]-b[i]; s+=d*d; }
    return sqrt(s);
  }
}
