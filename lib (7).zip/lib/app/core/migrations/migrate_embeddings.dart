// lib/app/core/migrations/migrate_embeddings.dart
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:kiosk/app/core/services/database_service.dart';

class EmbeddingMigrator {
  /// Run once from a debug/admin action.
  /// - Normalizes all stored embeddings (L2)
  /// - Unifies storage to [{"emb":[..512..], "shape":[..10..]?, "phash":".."?,"v":"f32l2_v1"}]
  /// - Dedupes and limits to [maxPerEmployee] by keeping vectors closest to the medoid
  static Future<void> run({int maxPerEmployee = 5}) async {
    final rows = await DatabaseService.instance.getAllEmployeeProfiles();
    int migrated = 0, skipped = 0, totalVec = 0, keptVec = 0;

    for (final r in rows) {
      final id = r['employee_id'] as String?;
      final raw = r['image_data'] as String?;
      if (id == null || raw == null || raw.isEmpty) { skipped++; continue; }

      try {
        final parsed = jsonDecode(raw);
        // Normalize all vectors into a list of {emb, shape?, phash?, v}
        final unified = <Map<String, dynamic>>[];
        if (parsed is List && parsed.isNotEmpty) {
          // Case A: already object list?
          if (parsed.first is Map) {
            for (final m in parsed) {
              if (m is! Map) continue;
              final embL = _asNumList(m['emb']);
              if (embL == null) continue;
              final shapeL = _asNumList(m['shape']);
              final item = <String, dynamic>{
                'emb': _l2(embL),
                'v': 'f32l2_v1',
              };
              if (shapeL != null) item['shape'] = shapeL;
              if (m['phash'] is String) item['phash'] = m['phash'];
              if (m['ts']    is num   ) item['ts']    = m['ts'];
              unified.add(item);
            }
          } else if (parsed.first is List) {
            // Case B: [[..],[..]] legacy shape
            for (final v in parsed) {
              final embL = _asNumList(v);
              if (embL == null) continue;
              unified.add({'emb': _l2(embL), 'v': 'f32l2_v1'});
            }
          } else {
            // Case C: single flat list [..]
            final embL = _asNumList(parsed);
            if (embL != null) {
              unified.add({'emb': _l2(embL), 'v': 'f32l2_v1'});
            }
          }
        }

        // nothing valid -> skip row
        if (unified.isEmpty) { skipped++; continue; }
        totalVec += unified.length;

        // Deduplicate by phash if available
        final seen = <String>{};
        final dedup = <Map<String, dynamic>>[];
        for (final m in unified) {
          final ph = (m['phash'] is String) ? (m['phash'] as String) : null;
          if (ph == null || seen.add(ph)) dedup.add(m);
        }

        // If over limit, keep those closest to medoid
        final trimmed = _limitByMedoid(dedup, maxPerEmployee);
        keptVec += trimmed.length;

        await DatabaseService.instance.updateEmployeeEmbedding(
          id,
          jsonEncode(trimmed),
        );
        migrated++;
      } catch (e) {
        debugPrint('migrate[$r] error: $e');
        skipped++;
      }
    }

    debugPrint('MIGRATION: migrated=$migrated skipped=$skipped '
        'totalVec=$totalVec kept=$keptVec maxPerEmployee=$maxPerEmployee');
  }

  // ---------- helpers ----------
  static List<double>? _asNumList(dynamic v) {
    if (v is! List) return null;
    try {
      return v.map((e) => (e as num).toDouble()).toList(growable: false);
    } catch (_) { return null; }
  }

  static List<double> _l2(List<double> vec) {
    double s = 0; for (final x in vec) { s += x * x; }
    if (s <= 0) return vec;
    final n = sqrt(s);
    return List<double>.generate(vec.length, (i) => vec[i] / n, growable: false);
    // L2 makes cosine ≡ euclidean up to a constant → safe across legacy/float
  }

  static double _dist(List<double> a, List<double> b) {
    double s = 0; for (int i = 0; i < a.length; i++) { final d = a[i]-b[i]; s += d*d; }
    return sqrt(s);
  }

  static List<Map<String, dynamic>> _limitByMedoid(
      List<Map<String, dynamic>> items,
      int k,
      ) {
    if (items.length <= k) return items;

    // 1) Extract emb vectors
    final embs = <List<double>>[];
    for (final m in items) {
      final v = _asNumList(m['emb']);
      if (v != null) embs.add(v);
    }
    if (embs.isEmpty) return items.take(k).toList();

    // 2) Find medoid (vector with min total distance to others)
    final n = embs.length;
    final totals = List<double>.filled(n, 0);
    for (int i = 0; i < n; i++) {
      double sum = 0;
      for (int j = 0; j < n; j++) {
        if (i == j) continue;
        sum += _dist(embs[i], embs[j]);
      }
      totals[i] = sum;
    }
    int medoid = 0;
    for (int i = 1; i < n; i++) {
      if (totals[i] < totals[medoid]) medoid = i;
    }

    // 3) Rank by distance to medoid and keep top k nearest
    final pairs = <_IdxDist>[];
    for (int i = 0; i < n; i++) {
      pairs.add(_IdxDist(i, _dist(embs[i], embs[medoid])));
    }
    pairs.sort((a, b) => a.d.compareTo(b.d));
    final keepIdx = pairs.take(k).map((e) => e.i).toSet();

    // 4) Rebuild kept list preserving objects for kept indices
    final kept = <Map<String, dynamic>>[];
    int seenIdx = -1;
    for (final m in items) {
      final v = _asNumList(m['emb']);
      if (v == null) continue;
      seenIdx++;
      if (keepIdx.contains(seenIdx)) {
        kept.add({
          'emb': _l2(v),
          'shape': (m['shape'] is List) ? _asNumList(m['shape']) : null,
          'phash': (m['phash'] is String) ? m['phash'] : null,
          'v': 'f32l2_v1',
          if (m['ts'] is num) 'ts': m['ts'],
        });
      }
    }
    return kept;
  }
}

class _IdxDist {
  final int i; final double d;
  _IdxDist(this.i, this.d);
}
