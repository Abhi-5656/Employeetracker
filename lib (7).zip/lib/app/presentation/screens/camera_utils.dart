// camera_utils.dart
import 'dart:math';
import 'package:image/image.dart' as img;

class CameraUtils {
  /// Returns a centered ROI box (fraction of the full frame).
  static ({int left,int top,int width,int height}) centralRoi(img.Image full, {double frac = 0.60}) {
    final w = (full.width  * frac).round();
    final h = (full.height * frac).round();
    final left = ((full.width - w) / 2).round();
    final top  = ((full.height - h) / 2).round();
    return (left: left, top: top, width: w, height: h);
  }

  /// Mean luma helper for 64x64 downsample
  static double meanLuma64(img.Image im) {
    final g = img.grayscale(img.copyResize(im, width: 64, height: 64));
    double sum = 0;
    for (int y = 0; y < g.height; y++) {
      for (int x = 0; x < g.width; x++) {
        sum += img.getLuminance(g.getPixel(x, y));
      }
    }
    return sum / (g.width * g.height);
  }
}
