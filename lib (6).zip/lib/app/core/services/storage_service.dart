// import 'package:shared_preferences/shared_preferences.dart';
//
// class StorageService {
//   static const String _tenantIdKey = 'tenant_id';
//   static const String _tokenKey = 'jwt_token'; // Key for storing the JWT
//
//   Future<void> saveTenantId(String tenantId) async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.setString(_tenantIdKey, tenantId);
//   }
//
//   Future<String?> getTenantId() async {
//     final prefs = await SharedPreferences.getInstance();
//     return prefs.getString(_tenantIdKey);
//   }
//
//   /// Saves the JWT token to secure storage.
//   Future<void> saveToken(String token) async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.setString(_tokenKey, token);
//   }
//
//   /// Retrieves the JWT token from secure storage.
//   Future<String?> getToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     return prefs.getString(_tokenKey);
//   }
//
//   /// Clears the JWT token, effectively logging the user out.
//   Future<void> clearToken() async {
//     final prefs = await SharedPreferences.getInstance();
//     await prefs.remove(_tokenKey);
//   }
// }
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const String _tenantIdKey = 'tenant_id';
  static const String _tokenKey = 'jwt_token';
  // --- NEW: Key for the refresh token ---
  static const String _refreshTokenKey = 'jwt_refresh_token';

  /// Saves the Tenant ID to local storage.
  Future<void> saveTenantId(String tenantId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tenantIdKey, tenantId);
  }

  /// Retrieves the Tenant ID from local storage.
  Future<String?> getTenantId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tenantIdKey);
  }

  /// Saves the JWT access token to storage.
  Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
  }

  /// Retrieves the JWT access token from storage.
  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  // --- NEW: Methods to manage the refresh token ---

  /// Saves the JWT refresh token to storage.
  Future<void> saveRefreshToken(String refreshToken) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_refreshTokenKey, refreshToken);
  }

  /// Retrieves the JWT refresh token from storage.
  Future<String?> getRefreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_refreshTokenKey);
  }

  // --- UPDATED: Method to clear all authentication tokens ---

  /// Clears both access and refresh tokens, effectively logging the user out.
  Future<void> clearTokens() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_refreshTokenKey); // Also remove the refresh token
  }
  // Face hash (aHash) helpers — per employee
  Future<void> saveFaceHash(String employeeId, String hashHex) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('facehash_$employeeId', hashHex);
  }

  Future<String?> getFaceHash(String employeeId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('facehash_$employeeId');
  }

  

}