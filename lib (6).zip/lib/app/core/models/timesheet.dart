// lib/app/core/models/timesheet.dart

import 'package:intl/intl.dart';
import 'package:kiosk/app/core/models/punch_event.dart';


class Timesheet {
  final String employeeId;
  final String workDate;
  final List<PunchEventPayload> punchEvents;

  Timesheet({
    required this.employeeId,
    required this.workDate,
    required this.punchEvents,
  });

  /// Converts the Timesheet object to a Map suitable for JSON encoding,
  /// matching the server's expected format.
  Map<String, dynamic> toMap() {
    return {
      'employeeId': employeeId,
      'workDate': workDate,
      // Convert each PunchEventPayload object in the list to a map
      'punchEvents': punchEvents.map((event) => event.toMap()).toList(),
    };
  }
}

class PunchEventPayload {
  final String employeeId;
  final String eventTime;
  final String punchType;
  final String status;
  final String deviceId;

  PunchEventPayload({
    required this.employeeId,
    required this.eventTime,
    required this.punchType,
    required this.status,
    required this.deviceId,
  });

  /// Creates a PunchEventPayload from a locally stored PunchEvent.
  /// This is a helper to easily convert your database model to the API model.
  factory PunchEventPayload.fromPunchEvent(PunchEvent event, String deviceId) {
    return PunchEventPayload(
      employeeId: event.employeeId,
      // Format DateTime to the required ISO 8601 string format
      eventTime: DateFormat("yyyy-MM-dd'T'HH:mm:ss").format(event.eventTime),
      punchType: event.punchType.toString().split('.').last, // Converts PunchType.IN to "IN"
      status: 'VALID', // Defaulting status to VALID, can be changed later
      deviceId: deviceId,
    );
  }

  /// Converts the PunchEventPayload object to a Map for JSON encoding.
  Map<String, dynamic> toMap() {
    return {
      'employeeId': employeeId,
      'eventTime': eventTime,
      'punchType': punchType,
      'status': status,
      'deviceId': deviceId,
    };
  }
}
