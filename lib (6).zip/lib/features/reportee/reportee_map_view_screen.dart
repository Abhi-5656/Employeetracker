// // lib/features/reportee/reportee_map_view_screen.dart
//new
// lib/features/reportee/reportee_map_view_screen.dart

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:maplibre_gl/maplibre_gl.dart';

import '../../data/models/reportee_model.dart';
import '../../data/services/employee_service.dart';
import '../../data/services/reportee_path_render_service.dart';

const Color _kPrimaryColor = Color(0xFF667EEA);
const Color _kSecondaryColor = Color(0xFF764BA2);

class ReporteeMapViewScreen extends StatefulWidget {
  final ReporteeModel reportee;
  final DateTime? date;

  const ReporteeMapViewScreen({
    super.key,
    required this.reportee,
    this.date,
  });

  @override
  State<ReporteeMapViewScreen> createState() => _ReporteeMapViewScreenState();
}

class _ReporteeMapViewScreenState extends State<ReporteeMapViewScreen> {
  late final String _mapStyleJson = jsonEncode({
    "version": 8,
    "name": "Reportee Raster Map",
    "sources": {
      "osm": {
        "type": "raster",
        "tiles": [
          "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        ],
        "tileSize": 256,
        "attribution":
        "© OpenStreetMap contributors"
      }
    },
    "layers": [
      {
        "id": "osm-layer",
        "type": "raster",
        "source": "osm",
        "minzoom": 0,
        "maxzoom": 19
      }
    ]
  });

  MapLibreMapController? _mapController;
  DateTime? _currentDate;
  late Future<_PreparedSessionData> _pathFuture;

  bool _styleLoaded = false;
  bool _imagesLoaded = false;
  int _drawVersion = 0;

  @override
  void initState() {
    super.initState();
    _currentDate = widget.date;
    _loadPathData();
  }

  void _loadPathData() {
    final int requestVersion = ++_drawVersion;

    setState(() {
      _pathFuture = _fetchAndPrepare();
    });

    _clearMap();
    debugPrint('Loading reportee path, version=$requestVersion');
  }

  Future<_PreparedSessionData> _fetchAndPrepare() async {
    final SessionPathResponse session = _currentDate == null
        ? await EmployeeService.instance
        .getLatestReporteePath(widget.reportee.employeeId)
        : await EmployeeService.instance.getReporteePathForDate(
      widget.reportee.employeeId,
      _currentDate!,
    );

    final renderResult =
    await ReporteePathRenderService.instance.preparePath(session.path);

    return _PreparedSessionData(
      session: session,
      rawPath: renderResult.rawPath,
      displayPath: renderResult.displayPath,
      usedSnappedPath: renderResult.usedSnappedPath,
    );
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _currentDate ?? now,
      firstDate: DateTime(2023),
      lastDate: now,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: _kPrimaryColor,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked == null) return;

    setState(() {
      _currentDate = picked;
    });
    _loadPathData();
  }

  Future<void> _loadImages() async {
    final controller = _mapController;
    if (controller == null || _imagesLoaded) return;

    try {
      final start = await rootBundle.load('assets/icons/start_marker.png');
      final end = await rootBundle.load('assets/icons/end_marker.png');

      await controller.addImage('start-icon', start.buffer.asUint8List());
      await controller.addImage('end-icon', end.buffer.asUint8List());
      _imagesLoaded = true;
    } catch (e) {
      debugPrint('Custom marker icons not available: $e');
    }
  }

  Future<void> _clearMap() async {
    final controller = _mapController;
    if (controller == null) return;

    try {
      await controller.clearLines();
    } catch (_) {}
    try {
      await controller.clearSymbols();
    } catch (_) {}
    try {
      await controller.clearCircles();
    } catch (_) {}
  }

  void _onMapCreated(MapLibreMapController controller) {
    _mapController = controller;
    _styleLoaded = false;
    _imagesLoaded = false;
  }

  Future<void> _drawPathOnMap(_PreparedSessionData data) async {
    final controller = _mapController;
    if (controller == null || !_styleLoaded) return;

    final path = data.displayPath;
    await _clearMap();

    if (path.isEmpty) return;

    if (path.length == 1) {
      await controller.addCircle(
        CircleOptions(
          geometry: path.first,
          circleRadius: 8,
          circleColor: '#667EEA',
          circleOpacity: 0.95,
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 2,
        ),
      );

      await controller.animateCamera(
        CameraUpdate.newLatLngZoom(path.first, 16),
      );
      return;
    }

    await _loadImages();

    await controller.addLine(
      LineOptions(
        geometry: path,
        lineColor: '#007AFF',
        lineWidth: 6.0,
        lineOpacity: 0.9,
      ),
    );

    final startPoint = path.first;
    final endPoint = path.last;

    if (_imagesLoaded) {
      await controller.addSymbol(
        SymbolOptions(
          geometry: startPoint,
          iconImage: 'start-icon',
          iconSize: 2.2,
          textField: 'START',
          textSize: 12.0,
          textOffset: const Offset(0, -2.1),
          textHaloColor: '#FFFFFF',
          textHaloWidth: 1.0,
          textColor: '#0F172A',
        ),
      );

      await controller.addSymbol(
        SymbolOptions(
          geometry: endPoint,
          iconImage: 'end-icon',
          iconSize: 2.2,
          textField: 'END',
          textSize: 12.0,
          textOffset: const Offset(0, -2.1),
          textHaloColor: '#FFFFFF',
          textHaloWidth: 1.0,
          textColor: '#0F172A',
        ),
      );
    } else {
      await controller.addCircle(
        CircleOptions(
          geometry: startPoint,
          circleRadius: 7,
          circleColor: '#34C759',
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 2,
        ),
      );

      await controller.addCircle(
        CircleOptions(
          geometry: endPoint,
          circleRadius: 7,
          circleColor: '#007AFF',
          circleStrokeColor: '#FFFFFF',
          circleStrokeWidth: 2,
        ),
      );
    }

    final bounds = _calculateBounds(path);

    try {
      await controller.animateCamera(
        CameraUpdate.newLatLngBounds(
          bounds,
          left: 48,
          top: 110,
          right: 48,
          bottom: 180,
        ),
      );
    } catch (_) {
      await controller.animateCamera(
        CameraUpdate.newLatLngZoom(path.last, 15),
      );
    }
  }

  LatLngBounds _calculateBounds(List<LatLng> points) {
    double minLat = points.first.latitude;
    double maxLat = points.first.latitude;
    double minLng = points.first.longitude;
    double maxLng = points.first.longitude;

    for (final point in points) {
      if (point.latitude < minLat) minLat = point.latitude;
      if (point.latitude > maxLat) maxLat = point.latitude;
      if (point.longitude < minLng) minLng = point.longitude;
      if (point.longitude > maxLng) maxLng = point.longitude;
    }

    if (minLat == maxLat && minLng == maxLng) {
      const pad = 0.0025;
      minLat -= pad;
      maxLat += pad;
      minLng -= pad;
      maxLng += pad;
    }

    return LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );
  }

  Widget _buildSummaryCard(_PreparedSessionData data) {
    String formatTimestamp(String? value) {
      if (value == null || value.trim().isEmpty) return 'N/A';
      try {
        return DateFormat('dd MMM yyyy, h:mm a')
            .format(DateTime.parse(value).toLocal());
      } catch (_) {
        return value;
      }
    }

    final path = data.displayPath;
    final totalPoints = data.rawPath.length;

    return Positioned(
      left: 16,
      right: 16,
      bottom: 24,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.12),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.reportee.fullName,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        _currentDate == null
                            ? 'Latest session'
                            : DateFormat('dd MMM yyyy').format(_currentDate!),
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xFF64748B),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: data.usedSnappedPath
                        ? const Color(0xFFE0F2FE)
                        : const Color(0xFFEDE9FE),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    data.usedSnappedPath ? 'Road matched' : 'Raw GPS path',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: data.usedSnappedPath
                          ? const Color(0xFF0369A1)
                          : const Color(0xFF6D28D9),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _statTile(
                    'Start',
                    formatTimestamp(data.session.startedAt),
                    Icons.play_circle_outline,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statTile(
                    'End',
                    formatTimestamp(data.session.endedAt),
                    Icons.stop_circle_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _statTile(
                    'Points',
                    '$totalPoints',
                    Icons.alt_route_outlined,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _statTile(
                    'Displayed',
                    '${path.length}',
                    Icons.route_outlined,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _statTile(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Container(
            height: 34,
            width: 34,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_kPrimaryColor, _kSecondaryColor],
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              size: 18,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF0F172A),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    final subtitle = _currentDate == null
        ? 'Latest tracked session'
        : 'Tracked session for ${DateFormat('dd MMM yyyy').format(_currentDate!)}';

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [_kPrimaryColor, _kSecondaryColor],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            InkWell(
              onTap: () => Navigator.of(context).maybePop(),
              borderRadius: BorderRadius.circular(14),
              child: Container(
                height: 42,
                width: 42,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(Icons.arrow_back, color: Colors.white),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.reportee.fullName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.88),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: _pickDate,
              borderRadius: BorderRadius.circular(14),
              child: Container(
                padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.16),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.calendar_today_outlined,
                        color: Colors.white, size: 18),
                    SizedBox(width: 8),
                    Text(
                      'Date',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  String _friendlyErrorTitle(Object error) {
    final raw = error.toString();

    if (raw.contains('API Error 404') &&
        (raw.contains('No session found') ||
            raw.contains('NOT_FOUND') ||
            raw.contains('/api/tracking/query/path/latest/') ||
            raw.contains('/api/tracking/query/path/for-date/'))) {
      return 'No route found';
    }

    if (raw.contains('API Error 403')) {
      return 'Access denied';
    }

    if (raw.contains('API Error 500')) {
      return 'Something went wrong';
    }

    if (raw.contains('SocketException') ||
        raw.contains('Failed host lookup') ||
        raw.contains('Connection refused') ||
        raw.contains('Network is unreachable')) {
      return 'Unable to connect';
    }

    return 'Unable to load path';
  }

  String _friendlyErrorMessage(Object error) {
    final raw = error.toString();

    if (raw.contains('API Error 404') &&
        (raw.contains('No session found') ||
            raw.contains('NOT_FOUND') ||
            raw.contains('/api/tracking/query/path/latest/') ||
            raw.contains('/api/tracking/query/path/for-date/'))) {
      return _currentDate == null
          ? 'No tracked movement is available for this employee yet.'
          : 'No tracked movement is available for the selected date.';
    }

    if (raw.contains('API Error 403')) {
      return 'You do not have permission to view this employee route.';
    }

    if (raw.contains('API Error 500')) {
      return 'We could not load the route right now. Please try again in a moment.';
    }

    if (raw.contains('SocketException') ||
        raw.contains('Failed host lookup') ||
        raw.contains('Connection refused') ||
        raw.contains('Network is unreachable')) {
      return 'Please check your internet connection and try again.';
    }

    return 'Please try again.';
  }
  Widget _buildErrorState(Object error) {
    final title = _friendlyErrorTitle(error);
    final message = _friendlyErrorMessage(error);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.location_off_outlined,
              size: 56,
              color: Color(0xFF94A3B8),
            ),
            const SizedBox(height: 14),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF64748B),
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadPathData,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kPrimaryColor,
                foregroundColor: Colors.white,
              ),
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.route_outlined,
              size: 56,
              color: Color(0xFF94A3B8),
            ),
            const SizedBox(height: 14),
            const Text(
              'No route found',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Color(0xFF0F172A),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _currentDate == null
                  ? 'No tracked movement is available for this employee yet.'
                  : 'No tracked movement is available for the selected date.',
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Color(0xFF64748B),
                fontSize: 13,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadPathData,
              style: ElevatedButton.styleFrom(
                backgroundColor: _kPrimaryColor,
                foregroundColor: Colors.white,
              ),
              child: const Text('Refresh'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: Column(
        children: [
          _buildHeader(),
          Expanded(
            child: FutureBuilder<_PreparedSessionData>(
              future: _pathFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(color: _kPrimaryColor),
                  );
                }

                if (snapshot.hasError) {
                  return _buildErrorState(snapshot.error!);
                }

                final data = snapshot.data;
                if (data == null || data.displayPath.isEmpty) {
                  return _buildEmptyState();
                }

                WidgetsBinding.instance.addPostFrameCallback((_) {
                  _drawPathOnMap(data);
                });

                return Stack(
                  children: [
                    MapLibreMap(
                      styleString: _mapStyleJson,
                      initialCameraPosition: CameraPosition(
                        target: data.displayPath.first,
                        zoom: 14,
                      ),
                      myLocationEnabled: false,
                      compassEnabled: true,
                      rotateGesturesEnabled: true,
                      tiltGesturesEnabled: true,
                      onMapCreated: _onMapCreated,
                      onStyleLoadedCallback: () {
                        _styleLoaded = true;
                        _drawPathOnMap(data);
                      },
                    ),
                    _buildSummaryCard(data),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _PreparedSessionData {
  final SessionPathResponse session;
  final List<LatLng> rawPath;
  final List<LatLng> displayPath;
  final bool usedSnappedPath;

  _PreparedSessionData({
    required this.session,
    required this.rawPath,
    required this.displayPath,
    required this.usedSnappedPath,
  });
}


// import 'dart:typed_data';
// import 'package:flutter/services.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:maplibre_gl/maplibre_gl.dart';
// import '../../data/models/reportee_model.dart';
// import '../../data/services/employee_service.dart';
// import '../../shared/widgets/layouts.dart'; // For GradientScaffold if needed, though we use Scaffold here
//
// // 🎨 Theme Constants
// const Color _kPrimaryColor = Color(0xFF667EEA);
// const Color _kSecondaryColor = Color(0xFF764BA2);
//
// class ReporteeMapViewScreen extends StatefulWidget {
//   final ReporteeModel reportee;
//   final DateTime? date; // Initial date (null = latest)
//
//   const ReporteeMapViewScreen({
//     Key? key,
//     required this.reportee,
//     this.date,
//   }) : super(key: key);
//
//   @override
//   _ReporteeMapViewScreenState createState() => _ReporteeMapViewScreenState();
// }
//
// class _ReporteeMapViewScreenState extends State<ReporteeMapViewScreen> {
//   // ⚠️ PASTE YOUR MapTiler API KEY HERE
//   static const String MAPTILER_STYLE_URL =
//       "https://api.maptiler.com/maps/streets-v2/style.json?key=VMVIqNS4SYJhP8t1oDng";
//
//   MapLibreMapController? _mapController;
//
//   // State to track the currently viewed date (null means Latest)
//   DateTime? _currentDate;
//
//   late Future<SessionPathResponse> _pathFuture;
//   bool _pathDrawn = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _currentDate = widget.date; // Initialize with passed date
//     _loadPathData();
//   }
//
//   // 🎯 Centralized method to load data based on _currentDate
//   void _loadPathData() {
//     setState(() {
//       _pathDrawn = false;
//
//       // Clear old lines/symbols immediately if controller exists
//       if (_mapController != null) {
//         _mapController!.clearLines();
//         _mapController!.clearSymbols();
//       }
//
//       if (_currentDate != null) {
//         _pathFuture = EmployeeService.instance.getReporteePathForDate(
//           widget.reportee.employeeId,
//           _currentDate!,
//         );
//       } else {
//         _pathFuture = EmployeeService.instance.getLatestReporteePath(
//           widget.reportee.employeeId,
//         );
//       }
//     });
//   }
//
//   // 🎯 Date Picker Handler
//   Future<void> _pickDate() async {
//     final DateTime now = DateTime.now();
//     final DateTime? picked = await showDatePicker(
//       context: context,
//       initialDate: _currentDate ?? now,
//       firstDate: DateTime(2023),
//       lastDate: now,
//       builder: (context, child) {
//         return Theme(
//           data: Theme.of(context).copyWith(
//             colorScheme: const ColorScheme.light(
//               primary: _kPrimaryColor,
//               onPrimary: Colors.white,
//               onSurface: Colors.black,
//             ),
//           ),
//           child: child!,
//         );
//       },
//     );
//
//     if (picked != null) {
//       setState(() {
//         _currentDate = picked;
//       });
//       _loadPathData(); // Reload data for the new date
//     }
//   }
//
//   Future<void> _loadImages() async {
//     if (_mapController == null) return;
//
//     try {
//       final ByteData start = await rootBundle.load('assets/icons/start_marker.png');
//       final ByteData end = await rootBundle.load('assets/icons/end_marker.png');
//
//       await _mapController!.addImage('start-icon', start.buffer.asUint8List());
//       await _mapController!.addImage('end-icon', end.buffer.asUint8List());
//     } catch (e) {
//       debugPrint("Warning: Could not load custom map icons. Using default. Error: $e");
//     }
//   }
//
//   void _onMapCreated(MapLibreMapController controller) {
//     _mapController = controller;
//   }
//
//   void _drawPathOnMap(List<LatLng> path) async {
//     if (_mapController == null || path.isEmpty || _pathDrawn) return;
//
//     await _mapController!.clearLines();
//     await _mapController!.clearSymbols();
//
//     await _mapController!.addLine(
//       LineOptions(
//         geometry: path,
//         lineColor: "#667EEA", // Primary Color Hex
//         lineWidth: 5.0,
//         lineOpacity: 0.8,
//       ),
//     );
//
//     // Start Marker
//     await _mapController!.addSymbol(SymbolOptions(
//       geometry: path.first,
//       iconImage: 'start-icon',
//       iconSize: 3,
//       textField: 'START',
//       textSize: 14.0,
//       textColor: '#000000',
//       textOffset: const Offset(0, -2.5),
//       textHaloColor: '#FFFFFF',
//       textHaloWidth: 1.0,
//     ));
//
//     // End Marker
//     await _mapController!.addSymbol(SymbolOptions(
//       geometry: path.last,
//       iconImage: 'end-icon',
//       iconSize: 3,
//       textField: 'END',
//       textSize: 14.0,
//       textColor: '#000000',
//       textOffset: const Offset(0, -2.5),
//       textHaloColor: '#FFFFFF',
//       textHaloWidth: 1.0,
//     ));
//
//     final LatLngBounds bounds = _calculateBounds(path);
//     _mapController!.animateCamera(
//       CameraUpdate.newLatLngBounds(
//         bounds,
//         left: 50.0, top: 50.0, right: 50.0, bottom: 50.0,
//       ),
//     );
//
//     _pathDrawn = true;
//   }
//
//   LatLngBounds _calculateBounds(List<LatLng> points) {
//     double minLat = points.first.latitude, minLng = points.first.longitude;
//     double maxLat = points.first.latitude, maxLng = points.first.longitude;
//     for (var point in points) {
//       if (point.latitude < minLat) minLat = point.latitude;
//       if (point.longitude < minLng) minLng = point.longitude;
//       if (point.latitude > maxLat) maxLat = point.latitude;
//       if (point.longitude > maxLng) maxLng = point.longitude;
//     }
//     return LatLngBounds(
//       southwest: LatLng(minLat, minLng),
//       northeast: LatLng(maxLat, maxLng),
//     );
//   }
//
//   // 🎯 Enhanced Info Card (Shown when data exists)
//   Widget _buildInfoCard(SessionPathResponse sessionData) {
//     String formatTimestamp(String ts) {
//       if (ts.isEmpty) return "N/A";
//       try {
//         // ✅ FIX: Convert UTC string to Device Local Time
//         return DateFormat('h:mm a').format(DateTime.parse(ts).toLocal());
//       } catch (e) {
//         return ts;
//       }
//     }
//
//     return Positioned(
//       bottom: 30,
//       left: 16,
//       right: 16,
//       child: Container(
//         padding: const EdgeInsets.all(20),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(24),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.15),
//               blurRadius: 20,
//               offset: const Offset(0, 10),
//             ),
//           ],
//         ),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Row(
//               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               children: [
//                 Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     Text(
//                       widget.reportee.fullName,
//                       style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
//                     ),
//                     Text(
//                       _currentDate == null ? "Latest Session" : DateFormat('MMM d, y').format(_currentDate!),
//                       style: TextStyle(color: Colors.grey[600], fontSize: 12),
//                     ),
//                   ],
//                 ),
//                 Container(
//                   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
//                   decoration: BoxDecoration(
//                     color: _kPrimaryColor.withOpacity(0.1),
//                     borderRadius: BorderRadius.circular(12),
//                   ),
//                   child: const Text(
//                     "COMPLETED",
//                     style: TextStyle(
//                       fontSize: 10,
//                       fontWeight: FontWeight.bold,
//                       color: _kPrimaryColor,
//                     ),
//                   ),
//                 )
//               ],
//             ),
//             const SizedBox(height: 16),
//             Row(
//               children: [
//                 Expanded(
//                   child: _buildTimeStat("Start Time", formatTimestamp(sessionData.startedAt), Icons.play_circle_outline),
//                 ),
//                 Container(width: 1, height: 30, color: Colors.grey[300]),
//                 Expanded(
//                   child: _buildTimeStat("End Time", formatTimestamp(sessionData.endedAt), Icons.stop_circle_outlined),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget _buildTimeStat(String label, String value, IconData icon) {
//     return Column(
//       children: [
//         Icon(icon, size: 20, color: Colors.grey[400]),
//         const SizedBox(height: 4),
//         Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
//         Text(label, style: TextStyle(color: Colors.grey[500], fontSize: 11)),
//       ],
//     );
//   }
//
//   // 🎯 Enhanced Empty State Card
//   Widget _buildEmptyStateCard() {
//     return Positioned(
//       bottom: 30,
//       left: 16,
//       right: 16,
//       child: Container(
//         padding: const EdgeInsets.all(24),
//         decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(24),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.black.withOpacity(0.1),
//               blurRadius: 20,
//               offset: const Offset(0, 10),
//             ),
//           ],
//         ),
//         child: Column(
//           mainAxisSize: MainAxisSize.min,
//           children: [
//             Icon(Icons.directions_off_rounded, size: 48, color: Colors.grey[300]),
//             const SizedBox(height: 16),
//             const Text(
//               "No Path Found",
//               style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87),
//             ),
//             const SizedBox(height: 8),
//             Text(
//               "There is no location history available for ${_currentDate == null ? 'the latest session' : DateFormat('MMM d').format(_currentDate!)}.",
//               textAlign: TextAlign.center,
//               style: TextStyle(color: Colors.grey[600], fontSize: 14),
//             ),
//             const SizedBox(height: 20),
//             SizedBox(
//               width: double.infinity,
//               child: ElevatedButton(
//                 onPressed: _pickDate,
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: _kPrimaryColor,
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                   padding: const EdgeInsets.symmetric(vertical: 12),
//                 ),
//                 child: const Text("Select Another Date", style: TextStyle(color: Colors.white)),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final title = _currentDate == null
//         ? "Latest Path"
//         : DateFormat('MMM d, y').format(_currentDate!);
//
//     return Scaffold(
//       extendBodyBehindAppBar: true, // Map fills screen
//       appBar: AppBar(
//         title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
//         backgroundColor: Colors.transparent,
//         elevation: 0,
//         centerTitle: true,
//         flexibleSpace: Container(
//           decoration: BoxDecoration(
//             gradient: LinearGradient(
//               colors: [_kPrimaryColor.withOpacity(0.9), _kSecondaryColor.withOpacity(0.9)],
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//             ),
//           ),
//         ),
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
//           onPressed: () => Navigator.pop(context),
//         ),
//         actions: [
//           IconButton(
//             icon: const Icon(Icons.calendar_month_rounded, color: Colors.white),
//             onPressed: _pickDate,
//           ),
//         ],
//       ),
//       body: FutureBuilder<SessionPathResponse>(
//         future: _pathFuture,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           }
//
//           // 1. Error State - Styled View
//           if (snapshot.hasError) {
//             return Center(
//               child: Padding(
//                 padding: const EdgeInsets.all(32.0),
//                 child: Column(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     Icon(Icons.error_outline_rounded, size: 64, color: Colors.red[200]),
//                     const SizedBox(height: 16),
//                     Text(
//                       "Unable to Load Map",
//                       style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.grey[800]),
//                     ),
//                     const SizedBox(height: 8),
//                     Text(
//                       "We couldn't fetch the location data.\nPlease check your connection.",
//                       textAlign: TextAlign.center,
//                       style: TextStyle(color: Colors.grey[600]),
//                     ),
//                     const SizedBox(height: 24),
//                     ElevatedButton.icon(
//                       onPressed: _loadPathData,
//                       icon: const Icon(Icons.refresh_rounded, color: Colors.white),
//                       label: const Text("Retry", style: TextStyle(color: Colors.white)),
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: _kPrimaryColor,
//                         padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
//                         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           }
//
//           final sessionData = snapshot.data;
//           final path = sessionData?.path ?? [];
//
//           // 2. Empty State - Show Map + Floating "No Data" Card
//           if (path.isEmpty) {
//             return Stack(
//               children: [
//                 MapLibreMap(
//                   styleString: MAPTILER_STYLE_URL,
//                   onMapCreated: _onMapCreated,
//                   initialCameraPosition: const CameraPosition(
//                     target: LatLng(26.4499, 80.3319),
//                     zoom: 12.0,
//                   ),
//                 ),
//                 _buildEmptyStateCard(),
//               ],
//             );
//           }
//
//           // 3. Success State - Map + Data Card
//           return Stack(
//             children: [
//               MapLibreMap(
//                 styleString: MAPTILER_STYLE_URL,
//                 onMapCreated: _onMapCreated,
//                 onStyleLoadedCallback: () async {
//                   await _loadImages();
//                   _drawPathOnMap(path);
//                 },
//                 initialCameraPosition: const CameraPosition(
//                   target: LatLng(26.4499, 80.3319),
//                   zoom: 14.0,
//                 ),
//               ),
//               _buildInfoCard(sessionData!),
//             ],
//           );
//         },
//       ),
//     );
//   }
// }
// import 'dart:typed_data';
// import 'package:flutter/services.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:maplibre_gl/maplibre_gl.dart';
// import '../../data/models/reportee_model.dart';
// import '../../data/services/employee_service.dart';
// import '../../shared/widgets/layouts.dart';
//
// class ReporteeMapViewScreen extends StatefulWidget {
//   final ReporteeModel reportee;
//   final DateTime? date; // Initial date (null = latest)
//
//   const ReporteeMapViewScreen({
//     Key? key,
//     required this.reportee,
//     this.date,
//   }) : super(key: key);
//
//   @override
//   _ReporteeMapViewScreenState createState() => _ReporteeMapViewScreenState();
// }
//
// class _ReporteeMapViewScreenState extends State<ReporteeMapViewScreen> {
//   // ⚠️ PASTE YOUR MapTiler API KEY HERE
//   static const String MAPTILER_STYLE_URL =
//       "https://api.maptiler.com/maps/streets-v2/style.json?key=VMVIqNS4SYJhP8t1oDng";
//
//   MapLibreMapController? _mapController;
//
//   // State to track the currently viewed date (null means Latest)
//   DateTime? _currentDate;
//
//   late Future<SessionPathResponse> _pathFuture;
//   bool _pathDrawn = false;
//
//   @override
//   void initState() {
//     super.initState();
//     _currentDate = widget.date; // Initialize with passed date
//     _loadPathData();
//   }
//
//   // 🎯 NEW: Centralized method to load data based on _currentDate
//   void _loadPathData() {
//     setState(() {
//       // Reset drawing flag so map redraws when data arrives
//       _pathDrawn = false;
//
//       // If controller exists, clear old lines/symbols immediately
//       if (_mapController != null) {
//         _mapController!.clearLines();
//         _mapController!.clearSymbols();
//       }
//
//       if (_currentDate != null) {
//         // Fetch for specific date
//         _pathFuture = EmployeeService.instance.getReporteePathForDate(
//           widget.reportee.employeeId,
//           _currentDate!,
//         );
//       } else {
//         // Fetch latest
//         _pathFuture = EmployeeService.instance.getLatestReporteePath(
//           widget.reportee.employeeId,
//         );
//       }
//     });
//   }
//
//   // 🎯 NEW: Date Picker Handler
//   Future<void> _pickDate() async {
//     final DateTime now = DateTime.now();
//     final DateTime? picked = await showDatePicker(
//       context: context,
//       initialDate: _currentDate ?? now,
//       firstDate: DateTime(2023),
//       lastDate: now,
//       helpText: 'SELECT DATE FOR PATH',
//     );
//
//     if (picked != null) {
//       setState(() {
//         _currentDate = picked;
//       });
//       _loadPathData(); // Reload data for the new date
//     }
//   }
//
//   Future<void> _loadImages() async {
//     if (_mapController == null) return;
//
//     try {
//       final ByteData start = await rootBundle.load('assets/icons/start_marker.png');
//       final ByteData end = await rootBundle.load('assets/icons/end_marker.png');
//
//       await _mapController!.addImage('start-icon', start.buffer.asUint8List());
//       await _mapController!.addImage('end-icon', end.buffer.asUint8List());
//     } catch (e) {
//       debugPrint("Warning: Could not load custom map icons. Using default. Error: $e");
//     }
//   }
//
//   void _onMapCreated(MapLibreMapController controller) {
//     _mapController = controller;
//   }
//
//   void _drawPathOnMap(List<LatLng> path) async {
//     // If already drawn or empty, skip
//     if (_mapController == null || path.isEmpty || _pathDrawn) return;
//
//     // Double check to clear artifacts before drawing (safety)
//     await _mapController!.clearLines();
//     await _mapController!.clearSymbols();
//
//     await _mapController!.addLine(
//       LineOptions(
//         geometry: path,
//         lineColor: "#3F51B5",
//         lineWidth: 5.0,
//         lineOpacity: 0.8,
//       ),
//     );
//
//     // 1. Add START Icon
//     await _mapController!.addSymbol(SymbolOptions(
//       geometry: path.first,
//       iconImage: 'start-icon',
//       iconSize: 3,
//     ));
//     // 2. Add START Text
//     await _mapController!.addSymbol(SymbolOptions(
//       geometry: path.first,
//       textField: 'START',
//       textSize: 14.0,
//       textColor: '#000000',
//       textOffset: const Offset(0, -2.5),
//       textHaloColor: '#FFFFFF',
//       textHaloWidth: 1.0,
//     ));
//     // 3. Add END Icon
//     await _mapController!.addSymbol(SymbolOptions(
//       geometry: path.last,
//       iconImage: 'end-icon',
//       iconSize: 3,
//     ));
//     // 4. Add END Text
//     await _mapController!.addSymbol(SymbolOptions(
//       geometry: path.last,
//       textField: 'END',
//       textSize: 14.0,
//       textColor: '#000000',
//       textOffset: const Offset(0, -2.5),
//       textHaloColor: '#FFFFFF',
//       textHaloWidth: 1.0,
//     ));
//
//     final LatLngBounds bounds = _calculateBounds(path);
//     _mapController!.animateCamera(
//       CameraUpdate.newLatLngBounds(
//         bounds,
//         left: 50.0, top: 50.0, right: 50.0, bottom: 50.0,
//       ),
//     );
//
//     _pathDrawn = true;
//   }
//
//   LatLngBounds _calculateBounds(List<LatLng> points) {
//     double minLat = points.first.latitude, minLng = points.first.longitude;
//     double maxLat = points.first.latitude, maxLng = points.first.longitude;
//     for (var point in points) {
//       if (point.latitude < minLat) minLat = point.latitude;
//       if (point.longitude < minLng) minLng = point.longitude;
//       if (point.latitude > maxLat) maxLat = point.latitude;
//       if (point.longitude > maxLng) maxLng = point.longitude;
//     }
//     return LatLngBounds(
//       southwest: LatLng(minLat, minLng),
//       northeast: LatLng(maxLat, maxLng),
//     );
//   }
//
//   Widget _buildInfoCard(SessionPathResponse sessionData) {
//     String formatTimestamp(String ts) {
//       if (ts.isEmpty) return "N/A";
//       try {
//         return DateFormat.yMd().add_jms().format(DateTime.parse(ts));
//       } catch (e) {
//         return ts;
//       }
//     }
//
//     return Positioned(
//       bottom: 20,
//       left: 20,
//       right: 20,
//       child: Card(
//         elevation: 4,
//         child: Padding(
//           padding: const EdgeInsets.all(12.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     widget.reportee.fullName,
//                     style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
//                   ),
//                   // Small badge showing what we are looking at
//                   Container(
//                     padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
//                     decoration: BoxDecoration(
//                       color: _currentDate == null ? Colors.green[100] : Colors.blue[100],
//                       borderRadius: BorderRadius.circular(8),
//                     ),
//                     child: Text(
//                       _currentDate == null ? "LATEST" : "HISTORY",
//                       style: TextStyle(
//                         fontSize: 10,
//                         fontWeight: FontWeight.bold,
//                         color: _currentDate == null ? Colors.green[800] : Colors.blue[800],
//                       ),
//                     ),
//                   )
//                 ],
//               ),
//               const SizedBox(height: 8),
//               Text(
//                 "Started: ${formatTimestamp(sessionData.startedAt)}",
//                 style: TextStyle(fontSize: 14, color: Colors.grey[700]),
//               ),
//               const SizedBox(height: 4),
//               Text(
//                 "Ended: ${formatTimestamp(sessionData.endedAt)}",
//                 style: TextStyle(fontSize: 14, color: Colors.grey[700]),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // 🎯 Dynamic Title based on state
//     final title = _currentDate == null
//         ? "${widget.reportee.fullName}'s Latest Path"
//         : "${widget.reportee.fullName} - ${DateFormat('MMM d, y').format(_currentDate!)}";
//
//     return GradientScaffold(
//       title: title,
//       // 🎯 ADD CALENDAR ICON HERE
//       trailing: IconButton(
//         icon: const Icon(Icons.calendar_month_rounded, color: Colors.white),
//         tooltip: 'Select Date',
//         onPressed: _pickDate,
//       ),
//       child: FutureBuilder<SessionPathResponse>(
//         future: _pathFuture,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           }
//           if (snapshot.hasError) {
//             return Center(
//               child: Padding(
//                 padding: const EdgeInsets.all(24.0),
//                 child: Column(
//                   mainAxisSize: MainAxisSize.min,
//                   children: [
//                     const Icon(Icons.error_outline, size: 48, color: Colors.redAccent),
//                     const SizedBox(height: 16),
//                     Text(
//                       "Could not load path.",
//                       style: Theme.of(context).textTheme.titleMedium,
//                     ),
//                     const SizedBox(height: 8),
//                     Text(
//                       "${snapshot.error}".replaceAll("Exception: ", ""),
//                       textAlign: TextAlign.center,
//                       style: const TextStyle(color: Colors.grey),
//                     ),
//                     const SizedBox(height: 16),
//                     ElevatedButton.icon(
//                       onPressed: _loadPathData,
//                       icon: const Icon(Icons.refresh),
//                       label: const Text("Retry"),
//                     )
//                   ],
//                 ),
//               ),
//             );
//           }
//
//           // Handle empty data or success
//           final sessionData = snapshot.data;
//           final path = sessionData?.path ?? [];
//
//           if (path.isEmpty) {
//             return Stack(
//               children: [
//                 // Still show the map background even if no path
//                 MapLibreMap(
//                   styleString: MAPTILER_STYLE_URL,
//                   onMapCreated: _onMapCreated,
//                   initialCameraPosition: const CameraPosition(
//                     target: LatLng(26.4499, 80.3319),
//                     zoom: 12.0,
//                   ),
//                 ),
//                 Center(
//                   child: Container(
//                     padding: const EdgeInsets.all(16),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.9),
//                       borderRadius: BorderRadius.circular(12),
//                     ),
//                     child: const Text(
//                       "No path data available for this selection.",
//                       style: TextStyle(fontWeight: FontWeight.bold),
//                     ),
//                   ),
//                 ),
//               ],
//             );
//           }
//
//           // Success case with data
//           return Stack(
//             children: [
//               MapLibreMap(
//                 styleString: MAPTILER_STYLE_URL,
//                 onMapCreated: _onMapCreated,
//                 onStyleLoadedCallback: () async {
//                   await _loadImages();
//                   _drawPathOnMap(path);
//                 },
//                 initialCameraPosition: const CameraPosition(
//                   target: LatLng(26.4499, 80.3319),
//                   zoom: 14.0,
//                 ),
//               ),
//               _buildInfoCard(sessionData!),
//             ],
//           );
//         },
//       ),
//     );
//   }
// }

// import 'package:flutter/material.dart';
// import 'package:maplibre_gl/maplibre_gl.dart';
// import '../../data/models/reportee_model.dart';
// import '../../data/services/employee_service.dart';
// import '../../shared/widgets/layouts.dart';
//
// class ReporteeMapViewScreen extends StatefulWidget {
//   final ReporteeModel reportee;
//
//   const ReporteeMapViewScreen({
//     Key? key,
//     required this.reportee,
//   }) : super(key: key);
//
//   @override
//   _ReporteeMapViewScreenState createState() => _ReporteeMapViewScreenState();
// }
//
// class _ReporteeMapViewScreenState extends State<ReporteeMapViewScreen> {
//   // ⚠️ PASTE YOUR MapTiler API KEY HERE
//   static const String MAPTILER_STYLE_URL =
//       "https://api.maptiler.com/maps/satellite/style.json?key=VMVIqNS4SYJhP8t1oDng";
//
//   MapLibreMapController? _mapController;
//   late Future<SessionPathResponse> _pathFuture;
//   bool _pathDrawn = false; // Add a flag to prevent drawing multiple times
//
//   @override
//   void initState() {
//     super.initState();
//     _pathFuture = EmployeeService.instance.getLatestReporteePath(widget.reportee.employeeId);
//   }
//
//   void _onMapCreated(MapLibreMapController controller) {
//     _mapController = controller;
//     // We don't draw here immediately; we wait for the style to be loaded.
//   }
//
//   void _drawPathOnMap(List<LatLng> path) {
//     // Check if map is ready and path hasn't been drawn yet
//     if (_mapController == null || path.isEmpty || _pathDrawn) return;
//
//     _mapController!.addLine(
//       LineOptions(
//         geometry: path,
//         lineColor: "#FF0000", // Red
//         lineWidth: 4.0,
//         lineOpacity: 0.8,
//       ),
//     );
//     _mapController!.addSymbol(SymbolOptions(geometry: path.first, iconImage: 'marker-15'));
//     _mapController!.addSymbol(SymbolOptions(geometry: path.last, iconImage: 'marker-15'));
//
//     final LatLngBounds bounds = _calculateBounds(path);
//     _mapController!.animateCamera(
//       CameraUpdate.newLatLngBounds(
//         bounds,
//         left: 50.0, top: 50.0, right: 50.0, bottom: 50.0,
//       ),
//     );
//
//     // Set the flag to true
//     _pathDrawn = true;
//   }
//
//   LatLngBounds _calculateBounds(List<LatLng> points) {
//     double minLat = points.first.latitude, minLng = points.first.longitude;
//     double maxLat = points.first.latitude, maxLng = points.first.longitude;
//     for (var point in points) {
//       if (point.latitude < minLat) minLat = point.latitude;
//       if (point.longitude < minLng) minLng = point.longitude;
//       if (point.latitude > maxLat) maxLat = point.latitude;
//       if (point.longitude > maxLng) maxLng = point.longitude;
//     }
//     return LatLngBounds(
//       southwest: LatLng(minLat, minLng),
//       northeast: LatLng(maxLat, maxLng),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return GradientScaffold(
//       title: "${widget.reportee.fullName}'s Path",
//       child: FutureBuilder<SessionPathResponse>(
//         future: _pathFuture,
//         builder: (context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.waiting) {
//             return const Center(child: CircularProgressIndicator());
//           }
//           if (snapshot.hasError) {
//             return Center(
//               child: Text(
//                 "Failed to load path: ${snapshot.error}",
//                 style: const TextStyle(color: Colors.white70),
//               ),
//             );
//           }
//           if (!snapshot.hasData || snapshot.data!.path.isEmpty) {
//             return const Center(
//               child: Text(
//                 "No path data found for this employee's latest session.",
//                 style: TextStyle(color: Colors.white70),
//               ),
//             );
//           }
//
//           final path = snapshot.data!.path;
//
//           return MapLibreMap(
//             styleString: MAPTILER_STYLE_URL,
//             onMapCreated: _onMapCreated,
//
//             // --- ⛔ THIS IS THE FIX ---
//             // Replace `onMapRenderedCallback` with `onStyleLoadedCallback`
//             onStyleLoadedCallback: () {
//               _drawPathOnMap(path); // Draw the path once the style is loaded
//             },
//             // --- END OF FIX ---
//
//             initialCameraPosition: const CameraPosition(
//               target: LatLng(26.4499, 80.3319), // Default
//               zoom: 14.0,
//             ),
//           );
//         },
//       ),
//     );
//   }
// }