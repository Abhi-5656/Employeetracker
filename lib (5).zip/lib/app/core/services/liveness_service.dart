// liveness_service.dart
import 'dart:math';
import 'package:image/image.dart' as img;
import '../utils/threshold_policy.dart';

class LivenessService {
  // Keep last 2 normalized 64x64 grayscale crops to measure micro-motion
  img.Image? _prev;
  DateTime? _prevTs;

  /// Returns true if sufficient inter-frame change is observed.
  /// This is a lightweight texture/motion cue for RGB-only devices.
  bool pass(img.Image currentCrop, Lighting lighting) {
    final now = DateTime.now();
    final g = img.grayscale(img.copyResize(currentCrop, width: 64, height: 64));

    if (_prev == null || _prevTs == null) {
      _prev = g; _prevTs = now;
      return false; // need at least 2 frames
    }

    // Mean absolute difference
    double mad = 0;
    for (int y = 0; y < 64; y++) {
      for (int x = 0; x < 64; x++) {
        mad += (img.getLuminance(g.getPixel(x,y)) - img.getLuminance(_prev!.getPixel(x,y))).abs();
      }
    }
    mad /= (64.0 * 64.0);

    // Require a touch higher motion in low-light to offset noise
    final thr = (lighting == Lighting.lowLight) ? 4.5 : 3.5;

    // Also bound by time delta to avoid trivial passes
    final dtMs = now.difference(_prevTs!).inMilliseconds;
    final pass = (dtMs >= 120) && (mad >= thr);

    _prev = g; _prevTs = now;
    return pass;
  }

  void reset() { _prev = null; _prevTs = null; }
}
