// lib/app/core/config/env_config.dart
abstract class EnvConfig {
  String get baseUrl;
}
