// // import 'dart:convert';
// // import 'package:http/http.dart' as http;
// // import 'package:kiosk/app/core/config/environment.dart';
// // import 'package:kiosk/app/core/constants/api_endpoints.dart';
// // import 'package:kiosk/app/core/services/storage_service.dart';
// //
// // class ApiService {
// //   final StorageService _storageService = StorageService();
// //
// //   // Helper method to build the full URL
// //   Future<String> _buildUrl(String endpoint) async {
// //     final baseUrl = Environment().config.baseUrl;
// //     final tenantId = await _storageService.getTenantId();
// //
// //     // Only add the tenantId to the path if it's not null and not empty
// //     if (tenantId != null && tenantId.isNotEmpty) {
// //       return '$baseUrl/$tenantId/$endpoint';
// //     }
// //
// //     // Otherwise, construct the URL without the tenantId
// //     return '$baseUrl/$endpoint';
// //   }
// //
// //   /// Logs in the admin, saves the JWT, and returns it.
// //   Future<String?> login(String email, String password) async {
// //     try {
// //       final url = await _buildUrl(ApiEndpoints.login);
// //
// //       final response = await http.post(
// //         Uri.parse(url),
// //         headers: {'Content-Type': 'application/json'},
// //         body: jsonEncode({
// //           'email': email,
// //           'password': password,
// //         }),
// //       );
// //
// //       print('Login Request URL: $url');
// //       print('Login Response Status: ${response.statusCode}');
// //       print('Login Response Body: ${response.body}');
// //
// //       if (response.statusCode == 200) {
// //         final data = jsonDecode(response.body);
// //         final token = data['token'] as String?;
// //         if (token != null) {
// //           // Save the token for future authenticated requests
// //           await _storageService.saveToken(token);
// //           return token;
// //         }
// //       }
// //       // If login fails or token is missing, return null
// //       return null;
// //     } catch (e) {
// //       print('An error occurred during login: $e');
// //       return null;
// //     }
// //   }
// //
// //   /// Fetches a list of all valid employee IDs from the server.
// //   /// Requires a valid JWT token for authorization.
// //   Future<List<String>?> fetchEmployeeIds() async {
// //     final token = await _storageService.getToken();
// //     if (token == null) {
// //       print('Authorization token not found. Please login first.');
// //       return null;
// //     }
// //
// //     final url = await _buildUrl(ApiEndpoints.employeeIds);
// //
// //     try {
// //       final response = await http.get(
// //         Uri.parse(url),
// //         headers: {
// //           'Content-Type': 'application/json',
// //           'Authorization': 'Bearer $token',
// //         },
// //       );
// //
// //       if (response.statusCode == 200) {
// //         final List<dynamic> idList = jsonDecode(response.body);
// //         return idList.map((id) => id.toString()).toList();
// //       } else {
// //         print('Failed to fetch employee IDs. Status: ${response.statusCode}');
// //         return null;
// //       }
// //     } catch (e) {
// //       print('Error fetching employee IDs: $e');
// //       return null;
// //     }
// //   }
// //
// //   /// Sends a batch of registered employee profiles to the server.
// //   Future<bool> sendBulkProfileData(List<Map<String, dynamic>> profiles) async {
// //     final token = await _storageService.getToken();
// //     if (token == null) {
// //       print('Authorization token not found. Please login first.');
// //       return false;
// //     }
// //
// //     final url = await _buildUrl(ApiEndpoints.bulkProfileRegistration);
// //
// //     try {
// //       final response = await http.post(
// //         Uri.parse(url),
// //         headers: {
// //           'Content-Type': 'application/json',
// //           'Authorization': 'Bearer $token',
// //         },
// //         body: jsonEncode(profiles),
// //       );
// //
// //       print('Bulk Profile Upload Status: ${response.statusCode}');
// //       print('Bulk Profile Upload Response: ${response.body}');
// //
// //       return response.statusCode == 200 || response.statusCode == 201;
// //     } catch (e) {
// //       print('Error sending bulk profile data: $e');
// //       return false;
// //     }
// //   }
// // }
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:kiosk/app/core/config/environment.dart';
// import 'package:kiosk/app/core/constants/api_endpoints.dart';
// import 'package:kiosk/app/core/services/storage_service.dart';
//
// import '../models /timesheet.dart';
//
// class ApiService {
//   final StorageService _storageService = StorageService();
//
//   // Helper method to build the full URL
//   Future<String> _buildUrl(String endpoint) async {
//     final baseUrl = Environment().config.baseUrl;
//     final tenantId = await _storageService.getTenantId();
//
//     // Only add the tenantId to the path if it's not null and not empty
//     if (tenantId != null && tenantId.isNotEmpty) {
//       return '$baseUrl/$tenantId/$endpoint';
//     }
//
//     // Otherwise, construct the URL without the tenantId
//     return '$baseUrl/$endpoint';
//   }
//
//   /// Logs in the admin, saves the JWT, and returns it.
//   Future<String?> login(String email, String password) async {
//     try {
//       final url = await _buildUrl(ApiEndpoints.login);
//
//       final response = await http.post(
//         Uri.parse(url),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({
//           'email': email,
//           'password': password,
//         }),
//       );
//
//       print('Login Request URL: $url');
//       print('Login Response Status: ${response.statusCode}');
//       print('Login Response Body: ${response.body}');
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         final token = data['token'] as String?;
//         if (token != null) {
//           // Save the token for future authenticated requests
//           await _storageService.saveToken(token);
//           return token;
//         }
//       }
//       // If login fails or token is missing, return null
//       return null;
//     } catch (e) {
//       print('An error occurred during login: $e');
//       return null;
//     }
//   }
//
//   /// Fetches a list of all valid employee IDs from the server.
//   /// Requires a valid JWT token for authorization.
//   Future<List<String>?> fetchEmployeeIds() async {
//     final token = await _storageService.getToken();
//     if (token == null) {
//       print('Authorization token not found. Please login first.');
//       return null;
//     }
//
//     final url = await _buildUrl(ApiEndpoints.employeeIds);
//
//     try {
//       final response = await http.get(
//         Uri.parse(url),
//         headers: {
//           'Content-Type': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//       );
//
//       if (response.statusCode == 200) {
//         final List<dynamic> idList = jsonDecode(response.body);
//         return idList.map((id) => id.toString()).toList();
//       } else {
//         print('Failed to fetch employee IDs. Status: ${response.statusCode}');
//         return null;
//       }
//     } catch (e) {
//       print('Error fetching employee IDs: $e');
//       return null;
//     }
//   }
//
//   /// Sends a batch of registered employee profiles to the server.
//   Future<bool> sendBulkProfileData(List<Map<String, dynamic>> profiles) async {
//     final token = await _storageService.getToken();
//     if (token == null) {
//       print('Authorization token not found. Please login first.');
//       return false;
//     }
//
//     final url = await _buildUrl(ApiEndpoints.bulkProfileRegistration);
//
//     try {
//       final response = await http.post(
//         Uri.parse(url),
//         headers: {
//           'Content-Type': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//         body: jsonEncode(profiles),
//       );
//
//       print('Bulk Profile Upload Status: ${response.statusCode}');
//       print('Bulk Profile Upload Response: ${response.body}');
//
//       return response.statusCode == 200 || response.statusCode == 201;
//     } catch (e) {
//       print('Error sending bulk profile data: $e');
//       return false;
//     }
//   }
//
//   /// --- NEW METHOD ---
//   /// Sends a batch of timesheets (grouped punch events) to the server.
//   Future<bool> sendBulkTimsheets(List<Timesheet> timesheets) async {
//     final token = await _storageService.getToken();
//     if (token == null) {
//       print('Authorization token not found for timesheet sync.');
//       return false;
//     }
//
//     final url = await _buildUrl(ApiEndpoints.bulkTimesheet);
//     final payload = timesheets.map((ts) => ts.toMap()).toList();
//
//     try {
//       final response = await http.post(
//         Uri.parse(url),
//         headers: {
//           'Content-Type': 'application/json',
//           'Authorization': 'Bearer $token',
//         },
//         body: jsonEncode(payload),
//       );
//
//       print('Bulk Timesheet Upload Status: ${response.statusCode}');
//       print('Bulk Timesheet Upload Response: ${response.body}');
//
//       return response.statusCode == 200 || response.statusCode == 201;
//     } catch (e) {
//       print('Error sending bulk timesheet data: $e');
//       return false;
//     }
//   }
// }
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:kiosk/app/core/config/environment.dart';
import 'package:kiosk/app/core/constants/api_endpoints.dart';
import 'package:kiosk/app/core/services/storage_service.dart';

import '../models/timesheet.dart';

class ApiService {
  final StorageService _storageService = StorageService();

  // Helper method to build the full URL, now with a flag for tenant-specificity
  Future<String> _buildUrl(String endpoint, {bool isTenantSpecific = true}) async {
    final baseUrl = Environment().config.baseUrl;

    if (isTenantSpecific) {
      final tenantId = await _storageService.getTenantId();
      if (tenantId != null && tenantId.isNotEmpty) {
        return '$baseUrl/$tenantId/$endpoint';
      }
    }

    // For global endpoints or if tenantId is not found, return base URL + endpoint
    return '$baseUrl/$endpoint';
  }

  /// --- UPDATED: Logs in the admin, saves both access and refresh tokens. ---
  Future<String?> login(String email, String password) async {
    try {
      // Login is tenant-specific as per the requirement
      final url = await _buildUrl(ApiEndpoints.login);
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final token = data['token'] as String?;
        final refreshToken = data['refreshToken'] as String?;

        if (token != null && refreshToken != null) {
          await _storageService.saveToken(token);
          await _storageService.saveRefreshToken(refreshToken);
          return token;
        }
      }
      return null;
    } catch (e) {
      print('An error occurred during login: $e');
      return null;
    }
  }

  /// --- NEW: Method to refresh the access token ---
  Future<String?> refreshToken() async {
    final savedRefreshToken = await _storageService.getRefreshToken();
    if (savedRefreshToken == null) {
      print("No refresh token available. Can't refresh.");
      return null;
    }

    try {
      // Refresh is tenant-specific as per the requirement
      final url = await _buildUrl(ApiEndpoints.refreshToken);
      final response = await http.post(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refreshToken': savedRefreshToken}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final newAccessToken = data['token'] as String?;
        final newRefreshToken = data['refreshToken'] as String?;

        if (newAccessToken != null) {
          await _storageService.saveToken(newAccessToken);
          if (newRefreshToken != null) {
            await _storageService.saveRefreshToken(newRefreshToken);
          }
          print("Token refreshed successfully.");
          return newAccessToken;
        }
      } else {
        print("Failed to refresh token. Status: ${response.statusCode}. Logging out.");
        await _storageService.clearTokens();
        return null;
      }
    } catch (e) {
      print("An error occurred during token refresh: $e");
      return null;
    }
    return null;
  }

  /// --- NEW: Generic request wrapper with auto-refresh logic ---
  Future<http.Response> _requestWrapper(
      Future<http.Response> Function(Map<String, String> headers) request,
      ) async {
    String? token = await _storageService.getToken();
    if (token == null) {
      token = await refreshToken();
      if (token == null) {
        throw Exception('No authentication token found and refresh failed.');
      }
    }

    var headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };

    http.Response response = await request(headers);

    if (response.statusCode == 401) {
      print("Access token expired. Attempting to refresh...");
      final newAccessToken = await refreshToken();

      if (newAccessToken != null) {
        print("Retrying original request with new token.");
        headers['Authorization'] = 'Bearer $newAccessToken';
        response = await request(headers);
      }
    }
    return response;
  }

  /// --- REFACTORED: Now uses the request wrapper ---
  Future<List<String>?> fetchEmployeeIds() async {
    try {
      final url = await _buildUrl(ApiEndpoints.employeeIds);
      final response = await _requestWrapper(
            (headers) => http.get(Uri.parse(url), headers: headers),
      );

      if (response.statusCode == 200) {
        final List<dynamic> idList = jsonDecode(response.body);
        return idList.map((id) => id.toString()).toList();
      } else {
        print('Failed to fetch employee IDs. Status: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('Error fetching employee IDs: $e');
      return null;
    }
  }

  /// --- NEW: Fetches all registered employee profiles from the server. ---
  Future<List<Map<String, dynamic>>?> fetchAllRegisteredProfiles() async {
    try {
      final url = await _buildUrl(ApiEndpoints.employeeProfileRegistration);
      print('Fetching all profiles from: $url');
      final response = await _requestWrapper(
            (headers) => http.get(Uri.parse(url), headers: headers),
      );

      if (response.statusCode == 200) {
        final List<dynamic> profileList = jsonDecode(response.body);
        return profileList.cast<Map<String, dynamic>>();
      } else {
        print('Failed to fetch employee profiles. Status: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      print('Error fetching all employee profiles: $e');
      return null;
    }
  }

  /// --- REFACTORED: Now uses the request wrapper ---
  Future<bool> sendBulkProfileData(List<Map<String, dynamic>> profiles) async {
    try {
      final url = await _buildUrl(ApiEndpoints.bulkProfileRegistration);
      final response = await _requestWrapper(
            (headers) => http.post(
          Uri.parse(url),
          headers: headers,
          body: jsonEncode(profiles),
        ),
      );
      print('Bulk Profile Upload Status: ${response.statusCode}');
      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print('Error sending bulk profile data: $e');
      return false;
    }
  }

  /// --- REFACTORED: Now uses the request wrapper ---
  Future<bool> sendBulkTimsheets(List<Timesheet> timesheets) async {
    try {
      final url = await _buildUrl(ApiEndpoints.bulkTimesheet);
      final payload = timesheets.map((ts) => ts.toMap()).toList();
      final response = await _requestWrapper(
            (headers) => http.post(
          Uri.parse(url),
          headers: headers,
          body: jsonEncode(payload),
        ),
      );
      print('Bulk Timesheet Upload Status: ${response.statusCode}');
      return response.statusCode == 200 || response.statusCode == 201;
    } catch (e) {
      print('Error sending bulk timesheet data: $e');
      return false;
    }
  }
}



//older
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:kiosk/app/core/config/environment.dart';
// import 'package:kiosk/app/core/constants/api_endpoints.dart';
// import 'package:kiosk/app/core/services/storage_service.dart';
//
// import '../models/timesheet.dart';
//
// class ApiService {
//   final StorageService _storageService = StorageService();
//
//   // Helper method to build the full URL, now with a flag for tenant-specificity
//   Future<String> _buildUrl(String endpoint, {bool isTenantSpecific = true}) async {
//     final baseUrl = Environment().config.baseUrl;
//
//     if (isTenantSpecific) {
//       final tenantId = await _storageService.getTenantId();
//       if (tenantId != null && tenantId.isNotEmpty) {
//         return '$baseUrl/$tenantId/$endpoint';
//       }
//     }
//
//     // For global endpoints or if tenantId is not found, return base URL + endpoint
//     return '$baseUrl/$endpoint';
//   }
//
//   /// --- UPDATED: Logs in the admin, saves both access and refresh tokens. ---
//   Future<String?> login(String email, String password) async {
//     try {
//       // Login is tenant-specific as per the requirement
//       final url = await _buildUrl(ApiEndpoints.login);
//       final response = await http.post(
//         Uri.parse(url),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({'email': email, 'password': password}),
//       );
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         final token = data['token'] as String?;
//         final refreshToken = data['refreshToken'] as String?;
//
//         if (token != null && refreshToken != null) {
//           await _storageService.saveToken(token);
//           await _storageService.saveRefreshToken(refreshToken);
//           return token;
//         }
//       }
//       return null;
//     } catch (e) {
//       print('An error occurred during login: $e');
//       return null;
//     }
//   }
//
//   /// --- NEW: Method to refresh the access token ---
//   Future<String?> refreshToken() async {
//     final savedRefreshToken = await _storageService.getRefreshToken();
//     if (savedRefreshToken == null) {
//       print("No refresh token available. Can't refresh.");
//       return null;
//     }
//
//     try {
//       // Refresh is tenant-specific as per the requirement
//       final url = await _buildUrl(ApiEndpoints.refreshToken);
//       final response = await http.post(
//         Uri.parse(url),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode({'refreshToken': savedRefreshToken}),
//       );
//
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         final newAccessToken = data['token'] as String?;
//         final newRefreshToken = data['refreshToken'] as String?;
//
//         if (newAccessToken != null) {
//           await _storageService.saveToken(newAccessToken);
//           if (newRefreshToken != null) {
//             await _storageService.saveRefreshToken(newRefreshToken);
//           }
//           print("Token refreshed successfully.");
//           return newAccessToken;
//         }
//       } else {
//         print("Failed to refresh token. Status: ${response.statusCode}. Logging out.");
//         await _storageService.clearTokens();
//         return null;
//       }
//     } catch (e) {
//       print("An error occurred during token refresh: $e");
//       return null;
//     }
//     return null;
//   }
//
//   /// --- NEW: Generic request wrapper with auto-refresh logic ---
//   Future<http.Response> _requestWrapper(
//       Future<http.Response> Function(Map<String, String> headers) request,
//       ) async {
//     String? token = await _storageService.getToken();
//     if (token == null) {
//       token = await refreshToken();
//       if (token == null) {
//         throw Exception('No authentication token found and refresh failed.');
//       }
//     }
//
//     var headers = {
//       'Content-Type': 'application/json',
//       'Authorization': 'Bearer $token',
//     };
//
//     http.Response response = await request(headers);
//
//     if (response.statusCode == 401) {
//       print("Access token expired. Attempting to refresh...");
//       final newAccessToken = await refreshToken();
//
//       if (newAccessToken != null) {
//         print("Retrying original request with new token.");
//         headers['Authorization'] = 'Bearer $newAccessToken';
//         response = await request(headers);
//       }
//     }
//     return response;
//   }
//
//   /// --- REFACTORED: Now uses the request wrapper ---
//   Future<List<String>?> fetchEmployeeIds() async {
//     try {
//       final url = await _buildUrl(ApiEndpoints.employeeIds);
//       final response = await _requestWrapper(
//             (headers) => http.get(Uri.parse(url), headers: headers),
//       );
//
//       if (response.statusCode == 200) {
//         final List<dynamic> idList = jsonDecode(response.body);
//         return idList.map((id) => id.toString()).toList();
//       } else {
//         print('Failed to fetch employee IDs. Status: ${response.statusCode}');
//         return null;
//       }
//     } catch (e) {
//       print('Error fetching employee IDs: $e');
//       return null;
//     }
//   }
//
//   /// --- NEW: Fetches all registered employee profiles from the server. ---
//   Future<List<Map<String, dynamic>>?> fetchAllRegisteredProfiles() async {
//     try {
//       final url = await _buildUrl(ApiEndpoints.employeeProfileRegistration);
//       print('Fetching all profiles from: $url');
//       final response = await _requestWrapper(
//             (headers) => http.get(Uri.parse(url), headers: headers),
//       );
//
//       if (response.statusCode == 200) {
//         final List<dynamic> profileList = jsonDecode(response.body);
//         return profileList.cast<Map<String, dynamic>>();
//       } else {
//         print('Failed to fetch employee profiles. Status: ${response.statusCode}');
//         return null;
//       }
//     } catch (e) {
//       print('Error fetching all employee profiles: $e');
//       return null;
//     }
//   }
//
//   /// --- REFACTORED: Now uses the request wrapper ---
//   Future<bool> sendBulkProfileData(List<Map<String, dynamic>> profiles) async {
//     try {
//       final url = await _buildUrl(ApiEndpoints.bulkProfileRegistration);
//       final response = await _requestWrapper(
//             (headers) => http.post(
//           Uri.parse(url),
//           headers: headers,
//           body: jsonEncode(profiles),
//         ),
//       );
//       print('Bulk Profile Upload Status: ${response.statusCode}');
//       return response.statusCode == 200 || response.statusCode == 201;
//     } catch (e) {
//       print('Error sending bulk profile data: $e');
//       return false;
//     }
//   }
//
//   /// --- REFACTORED: Now uses the request wrapper ---
//   Future<bool> sendBulkTimsheets(List<Timesheet> timesheets) async {
//     try {
//       final url = await _buildUrl(ApiEndpoints.bulkTimesheet);
//       final payload = timesheets.map((ts) => ts.toMap()).toList();
//       final response = await _requestWrapper(
//             (headers) => http.post(
//           Uri.parse(url),
//           headers: headers,
//           body: jsonEncode(payload),
//         ),
//       );
//       print('Bulk Timesheet Upload Status: ${response.statusCode}');
//       return response.statusCode == 200 || response.statusCode == 201;
//     } catch (e) {
//       print('Error sending bulk timesheet data: $e');
//       return false;
//     }
//   }
// }