// // lib/app/core/services/sync_service.dart
//
// import 'dart:async';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
//
// class SyncService {
//   final ApiService _apiService = ApiService();
//   final DatabaseService _dbService = DatabaseService.instance;
//   StreamSubscription? _connectivitySubscription;
//   bool _isSyncing = false;
//
//   void start() {
//     // Listen for connectivity changes
//     _connectivitySubscription = Connectivity().onConnectivityChanged.listen((result) {
//       if (result.contains(ConnectivityResult.mobile) || result.contains(ConnectivityResult.wifi)) {
//         print("Device is online. Checking for queued data...");
//         triggerSync();
//       } else {
//         print("Device is offline.");
//       }
//     });
//     // Also check immediately on app start
//     triggerSync();
//   }
//
//   Future<void> triggerSync() async {
//     if (_isSyncing) {
//       print("Sync already in progress.");
//       return;
//     }
//
//     _isSyncing = true;
//
//     try {
//       final queuedProfiles = await _dbService.getQueuedProfiles();
//       if (queuedProfiles.isNotEmpty) {
//         print("Found ${queuedProfiles.length} profiles to sync.");
//
//         // Send data to the server
//         final success = await _apiService.sendBulkProfileData(queuedProfiles);
//
//         if (success) {
//           // If successful, clear the queue
//           final syncedIds = queuedProfiles.map((p) => p['employee_id'] as String).toList();
//           await _dbService.clearSyncedProfiles(syncedIds);
//           print("Successfully synced and cleared queue.");
//         } else {
//           print("Failed to sync profiles. They will be retried later.");
//         }
//       } else {
//         print("No profiles in the sync queue.");
//       }
//     } catch (e) {
//       print("An error occurred during sync: $e");
//     } finally {
//       _isSyncing = false;
//     }
//   }
//
//   void dispose() {
//     _connectivitySubscription?.cancel();
//   }
// }
// lib/app/core/services/sync_service.dart

// import 'dart:async';
// import 'package:collection/collection.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:intl/intl.dart';
//
// import 'package:kiosk/app/core/services/api_service.dart';
// import 'package:kiosk/app/core/services/database_service.dart';
//
// import '../models /punch_event.dart';
// import '../models /timesheet.dart';
//
// /// A dedicated service to handle offline data synchronization for both
// /// employee profiles and punch events.
// class SyncService {
//   final ApiService _apiService = ApiService();
//   final DatabaseService _dbService = DatabaseService.instance;
//
//   bool _isSyncing = false;
//   Timer? _periodicSyncTimer;
//   StreamSubscription? _connectivitySubscription;
//
//   // Singleton pattern for easy access throughout the app
//   static final SyncService _instance = SyncService._internal();
//   factory SyncService() {
//     return _instance;
//   }
//
//   /// Private constructor to initialize listeners.
//   SyncService._internal() {
//     // Listen for connectivity changes to trigger sync automatically.
//     _connectivitySubscription =
//         Connectivity().onConnectivityChanged.listen((result) {
//           final isOnline = result.contains(ConnectivityResult.mobile) ||
//               result.contains(ConnectivityResult.wifi);
//           if (isOnline) {
//             print("✅ Connectivity restored. Triggering sync.");
//             triggerSync();
//           } else {
//             print("🔌 Device is offline.");
//           }
//         });
//
//     // As a fallback, attempt to sync periodically (e.g., every 15 minutes).
//     _periodicSyncTimer = Timer.periodic(const Duration(minutes: 15), (timer) {
//       print("⏰ Periodic sync check...");
//       triggerSync();
//     });
//
//     // Initial sync check when the service is first initialized.
//     triggerSync();
//   }
//
//   /// Disposes of the listeners when the service is no longer needed.
//   void dispose() {
//     _connectivitySubscription?.cancel();
//     _periodicSyncTimer?.cancel();
//   }
//
//   /// Manually triggers the synchronization process for all queued data.
//   Future<void> triggerSync() async {
//     if (_isSyncing) {
//       print("Sync process is already running. Skipping trigger.");
//       return;
//     }
//
//     final connectivityResult = await Connectivity().checkConnectivity();
//     if (!connectivityResult.contains(ConnectivityResult.mobile) && !connectivityResult.contains(ConnectivityResult.wifi)) {
//       print("🔌 Device is offline. Skipping sync.");
//       return;
//     }
//
//     print("🚀 Starting sync process...");
//     _isSyncing = true;
//
//     try {
//       // Sequentially sync profiles and then punch events.
//       await _syncEmployeeProfiles();
//       await _syncPunchEvents();
//     } catch (e) {
//       print("An error occurred during the sync process: $e");
//     } finally {
//       print("Sync process finished.");
//       _isSyncing = false;
//     }
//   }
//
//   /// Syncs queued employee profile registrations.
//   Future<void> _syncEmployeeProfiles() async {
//     final queuedProfiles = await _dbService.getQueuedProfiles();
//     if (queuedProfiles.isEmpty) {
//       print("No profiles in the sync queue.");
//       return;
//     }
//
//     print("Found ${queuedProfiles.length} profiles to sync.");
//     // NOTE: Assumes your ApiService has a method `sendBulkProfileData`
//     // that accepts `List<Map<String, dynamic>>`.
//     final success = await _apiService.sendBulkProfileData(queuedProfiles);
//
//     if (success) {
//       final syncedIds =
//       queuedProfiles.map((p) => p['employeeId'] as String).toList();
//       await _dbService.clearSyncedProfiles(syncedIds);
//       print("Successfully synced and cleared ${syncedIds.length} profiles from the queue.");
//     } else {
//       print("Failed to sync profiles. They will be retried later.");
//     }
//   }
//
//
//   /// Fetches queued punch events, groups them into timesheets, and sends them to the server.
//   Future<void> _syncPunchEvents() async {
//     final queuedEvents = await _dbService.getQueuedPunchEvents();
//     if (queuedEvents.isEmpty) {
//       print("No punch events in the sync queue.");
//       return;
//     }
//
//     print("Found ${queuedEvents.length} punch events to sync.");
//     final timesheets = _groupEventsIntoTimesheets(queuedEvents);
//     final success = await _apiService.sendBulkTimsheets(timesheets);
//
//     if (success) {
//       // Ensure event.id is not null before mapping.
//       final eventIds = queuedEvents.map((event) => event.id!).where((id) => id != null).toList();
//       if (eventIds.isNotEmpty) {
//         await _dbService.clearSyncedPunchEvents(eventIds);
//         print("Successfully synced and cleared ${eventIds.length} punch events from the queue.");
//       }
//     } else {
//       print("Failed to sync punch events. They will remain in the queue for the next attempt.");
//     }
//   }
//
//   /// Helper method to group a flat list of PunchEvents into Timesheets,
//   /// as required by the bulk API endpoint.
//   List<Timesheet> _groupEventsIntoTimesheets(List<PunchEvent> events) {
//     // Group events by a composite key of "employeeId|workDate"
//     final groupedByEmployeeAndDate = groupBy(
//       events,
//           (PunchEvent event) {
//         final workDate = DateFormat('yyyy-MM-dd').format(event.eventTime);
//         return '${event.employeeId}|$workDate';
//       },
//     );
//
//     // Transform the grouped map into a list of Timesheet objects
//     return groupedByEmployeeAndDate.entries.map((entry) {
//       final firstEvent = entry.value.first;
//       final punchPayloads = entry.value
//           .map((event) => PunchEventPayload.fromPunchEvent(
//           event, event.deviceId ?? 'UNKNOWN_DEVICE'))
//           .toList();
//
//       return Timesheet(
//         employeeId: firstEvent.employeeId,
//         workDate: DateFormat('yyyy-MM-dd').format(firstEvent.eventTime),
//         punchEvents: punchPayloads,
//       );
//     }).toList();
//   }
// }
import 'dart:async';
import 'package:collection/collection.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:intl/intl.dart';
import 'package:kiosk/app/core/services/api_service.dart';
import 'package:kiosk/app/core/services/database_service.dart';

import '../models/punch_event.dart';
import '../models/timesheet.dart';

/// A dedicated service to handle offline data synchronization for both
/// employee profiles and punch events.
class SyncService {
  final ApiService _apiService = ApiService();
  final DatabaseService _dbService = DatabaseService.instance;

  bool _isSyncing = false;
  Timer? _periodicSyncTimer;
  StreamSubscription? _connectivitySubscription;

  // Singleton pattern for easy access throughout the app
  static final SyncService _instance = SyncService._internal();
  factory SyncService() {
    return _instance;
  }

  /// Private constructor to initialize listeners.
  SyncService._internal() {
    // Listen for connectivity changes to trigger sync automatically.
    _connectivitySubscription =
        Connectivity().onConnectivityChanged.listen((result) {
          final isOnline = result.contains(ConnectivityResult.mobile) ||
              result.contains(ConnectivityResult.wifi);
          if (isOnline) {
            print("✅ Connectivity restored. Triggering sync.");
            triggerSync();
          } else {
            print("🔌 Device is offline.");
          }
        });

    // As a fallback, attempt to sync periodically (e.g., every 15 minutes).
    _periodicSyncTimer = Timer.periodic(const Duration(minutes: 15), (timer) {
      print("⏰ Periodic sync check...");
      triggerSync();
    });

    // Initial sync check when the service is first initialized.
    triggerSync();
  }

  /// Disposes of the listeners when the service is no longer needed.
  void dispose() {
    _connectivitySubscription?.cancel();
    _periodicSyncTimer?.cancel();
  }

  /// --- NEW: Fetches all data from the server and syncs it to the local DB. ---
  /// This is ideal for restoring data after a fresh app install.
  Future<bool> restoreDataFromServer() async {
    print('🚀 Starting data restoration from server...');
    try {
      final profiles = await _apiService.fetchAllRegisteredProfiles();

      if (profiles != null && profiles.isNotEmpty) {
        await _dbService.syncProfilesFromServer(profiles);
        print('Data restoration successful.');
        return true;
      } else if (profiles != null && profiles.isEmpty) {
        print('No registered profiles found on the server to restore.');
        return true; // Technically successful, just nothing to do.
      } else {
        print('Failed to fetch profiles from server for restoration.');
        return false;
      }
    } catch (e) {
      print('An error occurred during data restoration: $e');
      return false;
    }
  }

  /// Manually triggers the synchronization process for all queued data.
  Future<void> triggerSync() async {
    if (_isSyncing) {
      print("Sync process is already running. Skipping trigger.");
      return;
    }

    final connectivityResult = await Connectivity().checkConnectivity();
    if (!connectivityResult.contains(ConnectivityResult.mobile) &&
        !connectivityResult.contains(ConnectivityResult.wifi)) {
      print("🔌 Device is offline. Skipping sync.");
      return;
    }

    print("🚀 Starting sync process...");
    _isSyncing = true;

    try {
      // Sequentially sync profiles and then punch events.
      await _syncEmployeeProfiles();
      await _syncPunchEvents();
    } catch (e) {
      print("An error occurred during the sync process: $e");
    } finally {
      print("Sync process finished.");
      _isSyncing = false;
    }
  }

  /// Syncs queued employee profile registrations.
  Future<void> _syncEmployeeProfiles() async {
    final queuedProfiles = await _dbService.getQueuedProfiles();
    if (queuedProfiles.isEmpty) {
      print("No profiles in the sync queue.");
      return;
    }

    print("Found ${queuedProfiles.length} profiles to sync.");
    final success = await _apiService.sendBulkProfileData(queuedProfiles);

    if (success) {
      final syncedIds =
      queuedProfiles.map((p) => p['employeeId'] as String).toList();
      await _dbService.clearSyncedProfiles(syncedIds);
      print(
          "Successfully synced and cleared ${syncedIds.length} profiles from the queue.");
    } else {
      print("Failed to sync profiles. They will be retried later.");
    }
  }

  /// Fetches queued punch events, groups them into timesheets, and sends them to the server.
  Future<void> _syncPunchEvents() async {
    final queuedEvents = await _dbService.getQueuedPunchEvents();
    if (queuedEvents.isEmpty) {
      print("No punch events in the sync queue.");
      return;
    }

    print("Found ${queuedEvents.length} punch events to sync.");
    final timesheets = _groupEventsIntoTimesheets(queuedEvents);
    final success = await _apiService.sendBulkTimsheets(timesheets);

    if (success) {
      final eventIds =
      queuedEvents.map((event) => event.id!).where((id) => id != null).toList();
      if (eventIds.isNotEmpty) {
        await _dbService.clearSyncedPunchEvents(eventIds);
        print(
            "Successfully synced and cleared ${eventIds.length} punch events from the queue.");
      }
    } else {
      print(
          "Failed to sync punch events. They will remain in the queue for the next attempt.");
    }
  }

  /// Helper method to group a flat list of PunchEvents into Timesheets,
  /// as required by the bulk API endpoint.
  List<Timesheet> _groupEventsIntoTimesheets(List<PunchEvent> events) {
    // Group events by a composite key of "employeeId|workDate"
    final groupedByEmployeeAndDate = groupBy(
      events,
          (PunchEvent event) {
        final workDate = DateFormat('yyyy-MM-dd').format(event.eventTime);
        return '${event.employeeId}|$workDate';
      },
    );

    // Transform the grouped map into a list of Timesheet objects
    return groupedByEmployeeAndDate.entries.map((entry) {
      final firstEvent = entry.value.first;
      final punchPayloads = entry.value
          .map((event) => PunchEventPayload.fromPunchEvent(
          event, event.deviceId ?? 'UNKNOWN_DEVICE'))
          .toList();

      return Timesheet(
        employeeId: firstEvent.employeeId,
        workDate: DateFormat('yyyy-MM-dd').format(firstEvent.eventTime),
        punchEvents: punchPayloads,
      );
    }).toList();
  }
}
