// lib/app/core/models/punch_event.dart

enum PunchType { IN, OUT, inPunch }

class PunchEvent {
  final int? id;
  final String employeeId;
  final DateTime eventTime;
  final PunchType punchType;
  final String? status;
  final String? deviceId;
  final double? latitude;
  final double? longitude;

  PunchEvent({
    this.id,
    required this.employeeId,
    required this.eventTime,
    required this.punchType,
    this.status,
    this.deviceId,
    this.latitude,
    this.longitude,
  });

  /// --- FIX APPLIED ---
  /// Converts the object to a Map for database storage.
  /// The 'id' field is intentionally omitted to allow SQLite's
  /// AUTOINCREMENT to function correctly.
  Map<String, dynamic> toMap() {
    return {
      // 'id' is NOT included here. The database will generate it.
      'employee_id': employeeId,
      'event_time': eventTime.toIso8601String(),
      'punch_type': punchType.toString().split('.').last,
      'status': status,
      'deviceId': deviceId,
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  /// Creates a PunchEvent instance from a map (e.g., from the database).
  factory PunchEvent.fromMap(Map<String, dynamic> map) {
    return PunchEvent(
      id: map['id'],
      employeeId: map['employee_id'],
      eventTime: DateTime.parse(map['event_time']),
      punchType: (map['punch_type'] == 'IN') ? PunchType.IN : PunchType.OUT,
      status: map['status'],
      deviceId: map['deviceId'],
      latitude: map['latitude'],
      longitude: map['longitude'],
    );
  }
}