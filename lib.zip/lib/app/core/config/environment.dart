// lib/app/core/config/environment.dart
import 'package:kiosk/app/core/config/dev_config.dart';
import 'package:kiosk/app/core/config/env_config.dart';
import 'package:kiosk/app/core/config/prod_config.dart';
import 'package:kiosk/app/core/config/staging_config.dart';

class Environment {
  factory Environment() {
    return _singleton;
  }

  Environment._internal();

  static final Environment _singleton = Environment._internal();

  static const String dev = 'dev';
  static const String staging = 'staging';
  static const String prod = 'prod';

  late EnvConfig config;

  void init(String environment) {
    config = _getConfig(environment);
  }

  EnvConfig _getConfig(String environment) {
    switch (environment) {
      case dev:
        return DevConfig();
      case staging:
        return StagingConfig();
      default:
        return ProdConfig();
    }
  }
}
