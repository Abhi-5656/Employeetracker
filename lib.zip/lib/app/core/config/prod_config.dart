// lib/app/core/config/prod_config.dart
import 'package:kiosk/app/core/config/env_config.dart';

class ProdConfig implements EnvConfig {
  @override
  String get baseUrl => 'https://api.yourapi.com'; // Your production API URL
}
