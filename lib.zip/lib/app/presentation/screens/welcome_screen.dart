// import 'package:flutter/material.dart';
// import 'package:kiosk/app/core/services/storage_service.dart';
// import 'package:kiosk/app/presentation/screens/login_screen.dart';
//
// class WelcomeScreen extends StatelessWidget {
//   const WelcomeScreen({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     final TextEditingController tenantIdController = TextEditingController();
//     final StorageService storageService = StorageService();
//     final _formKey = GlobalKey<FormState>();
//
//     return Scaffold(
//       backgroundColor: const Color(0xFFF0F2F5),
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24.0),
//           child: SizedBox(
//             width: 500,
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 const Text(
//                   'Enter your Tenant ID to begin.',
//                   textAlign: TextAlign.center,
//                   style: TextStyle(
//                     fontSize: 20.0,
//                     color: Color(0xFF6C757D),
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ),
//                 const SizedBox(height: 24.0),
//                 Form(
//                   key: _formKey,
//                   child: Column(
//                     children: [
//                       SizedBox(
//                         height: 70,
//                         child: TextFormField(
//                           controller: tenantIdController,
//                           autofocus: true,
//                           textAlignVertical: TextAlignVertical.center,
//                           style: const TextStyle(
//                             fontSize: 24.0,
//                             fontWeight: FontWeight.w500,
//                           ),
//                           decoration: InputDecoration(
//                             hintText: 'Tenant ID',
//                             filled: true,
//                             fillColor: Colors.white,
//                             border: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                               borderSide: const BorderSide(
//                                 color: Color(0xFFCED4DA),
//                                 width: 2.0,
//                               ),
//                             ),
//                             enabledBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                               borderSide: const BorderSide(
//                                 color: Color(0xFFCED4DA),
//                                 width: 2.0,
//                               ),
//                             ),
//                             focusedBorder: OutlineInputBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                               borderSide: BorderSide(
//                                 color: Theme.of(context).primaryColor,
//                                 width: 2.0,
//                               ),
//                             ),
//                           ),
//                           validator: (value) {
//                             if (value == null || value.isEmpty) {
//                               return 'Please enter a Tenant ID';
//                             }
//                             return null;
//                           },
//                         ),
//                       ),
//                       const SizedBox(height: 16.0),
//                       SizedBox(
//                         height: 70,
//                         width: double.infinity,
//                         child: ElevatedButton(
//                           onPressed: () async {
//                             if (_formKey.currentState!.validate()) {
//                               final tenantId = tenantIdController.text;
//                               await storageService.saveTenantId(tenantId);
//                               print('Tenant ID saved: $tenantId');
//
//                               Navigator.of(context).push(
//                                 MaterialPageRoute(
//                                   builder: (context) => const LoginScreen(),
//                                 ),
//                               );
//                             }
//                           },
//                           style: ElevatedButton.styleFrom(
//                             backgroundColor: Theme.of(context).primaryColor,
//                             foregroundColor: Colors.white,
//                             shape: RoundedRectangleBorder(
//                               borderRadius: BorderRadius.circular(12.0),
//                             ),
//                             padding: EdgeInsets.zero,
//                           ),
//                           child: const Icon(
//                             Icons.arrow_forward,
//                             size: 35.0,
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:kiosk/app/core/services/storage_service.dart';
import 'package:kiosk/app/presentation/screens/login_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController tenantIdController = TextEditingController();
    final StorageService storageService = StorageService();
    final formKey = GlobalKey<FormState>();

    return Scaffold(
      backgroundColor: const Color(0xFFF0F2F5),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: SizedBox(
            width: 500,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  'Enter your Tenant ID to begin.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Color(0xFF6C757D),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 24.0),
                Form(
                  key: formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 70,
                        child: TextFormField(
                          controller: tenantIdController,
                          autofocus: true,
                          textAlignVertical: TextAlignVertical.center,
                          style: const TextStyle(
                            fontSize: 24.0,
                            fontWeight: FontWeight.w500,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Tenant ID',
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: const BorderSide(
                                color: Color(0xFFCED4DA),
                                width: 2.0,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: const BorderSide(
                                color: Color(0xFFCED4DA),
                                width: 2.0,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              borderSide: BorderSide(
                                color: Theme.of(context).primaryColor,
                                width: 2.0,
                              ),
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter a Tenant ID';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(height: 16.0),
                      SizedBox(
                        height: 70,
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (formKey.currentState!.validate()) {
                              final tenantId = tenantIdController.text;
                              await storageService.saveTenantId(tenantId);
                              print('Tenant ID saved: $tenantId');

                              // --- KEY CHANGE: Replaced push with pushReplacement ---
                              // This removes the WelcomeScreen from the navigation stack.
                              Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                  builder: (context) => const LoginScreen(),
                                ),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).primaryColor,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                            ),
                            padding: EdgeInsets.zero,
                          ),
                          child: const Icon(
                            Icons.arrow_forward,
                            size: 35.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}